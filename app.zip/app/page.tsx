"use client";
import React from 'react'
import Image from 'next/image'
import Hero from '@/components/Hero';
import WorkingProcess from '@/components/WorkingProcess';
import Slider from '@/components/Slider'
import { BsArrowRight } from "react-icons/bs";
import TestimonialSlider from '@/components/TestimonialSlide';
import BlogPostsSection from '@/components/BlogPostsSection';
import OfferSection from '@/components/offer';
export default function Home() {
  return (
    <main>
      {/* hero component */}
      <Hero />
      {/* hero component end */}
      {/* about us section */}
      <section className="flex flex-wrap gap-8 xl:gap-20 container max-w-[1310px] py-12 px-2.5 mx-auto">
        <div className="mx-auto flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 relative mb-10 lg:mb-0">
          {/* image */}
            <div className="relative z-10">
              <Image
                src="/assets/about-section.png"
                alt="Woman using tablet"
                width={550}
                height={665}
              />
            </div>
            {/* text box */}
          </div>
          <div className="lg:w-1/2 lg:pl-12 lg:pr-3">
            <h3 className="text-sm uppercase tracking-wider mb-2 flex gap-4 font-semibold items-center"><span className='text-4xl mb-4 text-primary'>...</span>About Pixelizio (Pvt) Ltd</h3>
            <h2 className="xl:text-3xl text-2xl font-bold xl:mb-16 mb-12">End-to-End Digital Marketing: From Design to Conversion</h2>
            {/* icon box below */}
            <div className="flex flex-col xl:gap-12 gap-8">
              {/* box 1 */}
              <div className="flex items-start border-b pb-6 border-border">
                <div className="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div className="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Our Vision</h3>
                  <p className="text-gray-400">We aim to empower businesses through innovative and impactful digital solutions.</p>
                </div>
              </div>
               {/* box 2 */}
              <div className="flex items-start border-b pb-6 border-border">
              <div className="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div className="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Our Mission</h3>
                  <p className="text-gray-400">We strive to enhance online visibility, engage audiences, and drive business success with tailored digital marketing strategies.</p>
                </div>
              </div>
              {/* box 3 */}
              <div className="flex items-start  pb-6">
              <div className="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div className="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Our Values</h3>
                  <p className="text-gray-400">Transparency, Communication, and Dedication— our three guiding principles in every digital endeavour.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* about section end */}
      {/* services section start */}
       <Slider />
      {/* services section end */}
      {/* Call the OfferSection component */}
      <OfferSection />
    {/* WorkingProcess section Start */}
     <WorkingProcess />
    {/* WorkingProcess section End */}
    {/* review slider section Start */}
    <TestimonialSlider />
    {/* review slider section end */}
    {/* Blog Post section Start */}
    <BlogPostsSection />
    {/* review slider section end */}
   </main>
  )
}