import Image from 'next/image'
import Link from 'next/link'
import Button from '@/components/Button';
import { IoMdCheckmarkCircle } from "react-icons/io";

export default function Home() {
  return (
    <div className="bg-secondery text-white xl:py-20 py-10">
      <div className="max-w-[1310px] px-2.5 mx-auto gap-y-12">
          <div className="flex flex-col xl:h-[660px] lg:flex-row items-start xl:gap-40 gap-5 ">
            <div className="lg:w-1/2 w-full mb-8 lg:mb-0">
            <div className="flex items-end space-x-2 mb-8 text-primary">
          {/* SVG line*/}
           <svg xmlnsXlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4.15 1.83" className="w-24 h-10 fill-current">
           <path d="M0.1,0.57C0.25,0.5,0.39,0.4,0.54,0.32C0.69,0.25,0.85,0.2,1.01,0.19c0.3-0.02,0.57,0.11,0.69,0.39 c0.12,0.27,0.14,0.57,0.39,0.76c0.22,0.17,0.5,0.21,0.77,0.22c0.16,0,0.33-0.01,0.49-0.03C3.43,1.51,3.52,1.5,3.61,1.48 c0.08-0.01,0.17-0.02,0.24-0.06c0.04-0.02,0.02-0.07-0.02-0.07C3.75,1.34,3.68,1.37,3.61,1.38C3.53,1.4,3.46,1.42,3.38,1.43 C3.23,1.46,3.07,1.47,2.91,1.47c-0.29,0-0.63-0.04-0.84-0.26c-0.23-0.23-0.2-0.59-0.39-0.84C1.52,0.18,1.26,0.1,1.01,0.11 C0.85,0.12,0.69,0.17,0.54,0.24c-0.16,0.08-0.34,0.17-0.47,0.3C0.06,0.55,0.08,0.58,0.1,0.57L0.1,0.57z"></path>
           <polygon points="4.06,1.39 3.81,1.24 3.55,1.09 3.78,1.41 3.61,1.76 3.84,1.57"></polygon>
           </svg>
           {/* Text */}
            <span> Who We Are</span>
            </div>
              <h1 className="text-3xl font-bold mb-6">Leading Digital Marketing Solutions</h1>
              <p className="mb-8 text-lightGrey">
                We as a digital marketing agency stand at the forefront of digital innovation, offering a range of services including Web Design & Development, Search Engine Optimization (SEO), Search Engine Advertising (SEA), Social Media Marketing (SMM), Content Marketing, and Email Marketing to boost your online success.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:gap-6 gap-0">

                {/* col 1 */}
                <div className="p-4 pl-0 justify-start items-start flex flex-col gap-4 border-border border-b sm:border-b-0 sm:border-r">
                  {/* icon */}
                <IoMdCheckmarkCircle className='text-3xl rounded-full bg-white text-primary' />
                {/* text */}
                  <h3 className="text-xl font-semibold">Website Creation</h3>
                  <p className="text-lightGrey">Turn your vision into a captivating reality with our expert website services.</p>
                </div>
                {/* col 2 */}
                <div className="p-4 xl:pl-4 pl-0 flex flex-col gap-4 rounded-lg">
                   {/* icon */}
                  <IoMdCheckmarkCircle className='text-3xl rounded-full bg-white text-primary' />
                  <h3 className="text-xl font-semibold">Digital Marketing</h3>
                  <p className="text-lightGrey">Ignite online success with our comprehensive digital strategies.</p>
                </div>
                <Button variant="BtnOutline" size="normal" className='w-52'>
                    Create Your Website »
                </Button>
              </div>
            </div>
            <div className="flex flex-col w-full justify-end gap-4 mt-0 xl:mt-8 lg:mt-0 xl:w-[760px]">
              <Image src="/assets/about-gallery-01.jpg" alt="Woman using Microsoft Surface laptop" width={365} height={507} className="col-span-2 xl:mt-20 mt-0 " />
              <Image src="/assets/about-gallery-02.jpg" alt="Man working on MacBook" width={230} height={285} className='xl:relative bottom-[350px] left-[380px] md:inline xl:inline hidden'/>
              <Image src="/assets/about-gallery-03.jpg" alt="Business people looking at tablet" width={230} height={200} className='xl:relative bottom-[900px] left-[380px] xl:inline hidden' />
            </div>
          </div>
          <div>
             {/* Crafting Experiences Section */}
        <div className="text-center py-20">
          <h2 className="text-3xl font-bold mb-6">Crafting Experiences Across Development, Design, and Marketing</h2>
          <p className="text-gray-400 max-w-3xl mx-auto">
            Not only do we provide answers, but we also make dreams a reality. We equip companies to succeed in today cutthroat digital market by maintaining a laser-like focus on innovation and outcomes.
          </p>
        </div>
    {/* Mission and Vision Section */}
      <div className="grid md:grid-cols-2 gap-8 mb-8">
          <div className="bg-[#1E1F23] p-8 rounded-lg">
            <div className="flex items-center gap-4 mb-4">
              <div className="bg-primary p-3 rounded-lg">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold">Our Mission</h3>
            </div>
            <p className="text-gray-400">
              Our mission at Pixelizio is to provide innovative solutions that boost growth and ensure long-term success thus changing the digital landscape.
            </p>
          </div>
          <div className="bg-[#1E1F23] p-8 rounded-lg">
            <div className="flex items-center gap-4 mb-4">
              <div className="bg-primary p-3 rounded-lg">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold">Our Vision</h3>
            </div>
            <p className="text-gray-400">
              In our ideal world, companies of all sizes can utilize digital transformation. With our innovative, inspiring, and value-delivering solutions.
            </p>
          </div>
        </div>

        {/* Solutions Section */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          <div className="bg-[#1E1F23] p-8 rounded-lg">
            <div className="text-primary mb-4">
              <svg className="w-12 h-12" viewBox="0 0 48 48" fill="none">
                <rect width="48" height="48" rx="8" fill="currentColor" fillOpacity="0.1"/>
                <path d="M24 16v16M20 20v8M28 20v8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Creative</h3>
            <p className="text-gray-400">
              Explore Pixelizio inventiveness with aesthetically striking designs, user-friendly development, and forward-looking marketing ideas.
            </p>
          </div>
          <div className="bg-[#1E1F23] p-8 rounded-lg">
            <div className="text-primary mb-4">
              <svg className="w-12 h-12" viewBox="0 0 48 48" fill="none">
                <rect width="48" height="48" rx="8" fill="currentColor" fillOpacity="0.1"/>
                <path d="M24 16v16M20 20v8M28 20v8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Innovative</h3>
            <p className="text-gray-400">
              Making use of the newest technologies, we challenge limits to offer creative ideas that enable companies to shine online.
            </p>
          </div>
          <div className="bg-[#1E1F23] p-8 rounded-lg">
            <div className="text-primary mb-4">
              <svg className="w-12 h-12" viewBox="0 0 48 48" fill="none">
                <rect width="48" height="48" rx="8" fill="currentColor" fillOpacity="0.1"/>
                <path d="M24 16v16M20 20v8M28 20v8" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Reliable</h3>
            <p className="text-gray-400">
              Your digital journey will be seamless, successful, and long-lasting with Pixelizio because we consistently deliver high-quality work.
            </p>
          </div>
        </div>
     
        {/* below seamless Section */}
          <div className="flex flex-col lg:flex-row items-center max-w-[1310px]">
            <div className="lg:w-1/2 mb-8 lg:mb-0">
              <Image src="/assets/about us 4.jpg" alt="Business people looking at tablet" width={581} height={387} className="rounded-lg transition-transform transform hover:-translate-y-2 hover:brightness-75 duration-300" />
            </div>
            <div className="lg:w-1/2 lg:pl-12">
              <h2 className="text-2xl font-bold mb-6">Seamless Digital Marketing Access is Just a Click Away</h2>
              <ul className="space-y-4">
                {["Mobile View Customisation", "Optimal Website Development", "Supportive Services", "Advanced Digital Strategies", "Search Engine Optimization", "Latest Features"].map((item, index) => (
                  <li key={index} className="flex items-center">
                    <svg className="w-6 h-6 mr-2 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
      </div>
    </div>
    </div>
  )
}