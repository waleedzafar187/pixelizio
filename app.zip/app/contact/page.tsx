import React from 'react'
import { BsFacebook, BsInstagram, BsLinkedin, BsPinterest } from 'react-icons/bs'
import { HiOutlineMailOpen } from "react-icons/hi";

const Contact = () => {
  return (
    <div className="bg-secondery text-white py-20">
      {/* Container */}
      <div className="max-w-[1310px] px-2.5 mx-auto grid grid-cols-1 lg:grid-cols-[600px_minmax(406px,_1fr)_506px] gap-x-[280px] gap-y-12">
        {/* First Column */}
        <div className="space-y-6">
        <div className="flex items-end space-x-2 text-primary">
        {/* SVG icon*/}
        <svg xmlnsXlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4.15 1.83" className="w-24 h-10 fill-current">
        <path d="M0.1,0.57C0.25,0.5,0.39,0.4,0.54,0.32C0.69,0.25,0.85,0.2,1.01,0.19c0.3-0.02,0.57,0.11,0.69,0.39 c0.12,0.27,0.14,0.57,0.39,0.76c0.22,0.17,0.5,0.21,0.77,0.22c0.16,0,0.33-0.01,0.49-0.03C3.43,1.51,3.52,1.5,3.61,1.48 c0.08-0.01,0.17-0.02,0.24-0.06c0.04-0.02,0.02-0.07-0.02-0.07C3.75,1.34,3.68,1.37,3.61,1.38C3.53,1.4,3.46,1.42,3.38,1.43 C3.23,1.46,3.07,1.47,2.91,1.47c-0.29,0-0.63-0.04-0.84-0.26c-0.23-0.23-0.2-0.59-0.39-0.84C1.52,0.18,1.26,0.1,1.01,0.11 C0.85,0.12,0.69,0.17,0.54,0.24c-0.16,0.08-0.34,0.17-0.47,0.3C0.06,0.55,0.08,0.58,0.1,0.57L0.1,0.57z"></path>
        <polygon points="4.06,1.39 3.81,1.24 3.55,1.09 3.78,1.41 3.61,1.76 3.84,1.57"></polygon>
        </svg>
        {/* Text */}
        <span>Get In Touch</span>
      </div>
          <h1 className="xl:text-3xl text-2xl font-bold">Let’s Start New Project or work Together! Contact With us</h1>
          <p>
            Contact Pixelizio (Pvt) Ltd and kickstart your next project or explore collaboration opportunities. We’re
            excited to hear from you and discuss how our{" "}
            <span className="text-primary">digital marketing expertise</span>, innovative website design, and social
            media management services can elevate your brand.
          </p>
          <p>
            For inquiries, partnerships, or to simply say hello, feel free to contact us through the information
            provided or fill in the form so our team can reach out to you!
          </p>
          <form className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Full Name"
                className="w-full p-2 bg-input border border-border rounded"
              />
              <input type="email" placeholder="Email" className="w-full p-2 bg-input border border-border rounded" />
            </div>
            <input
              type="number"
              placeholder="Phone Number"
              className="w-full p-2 bg-input border border-border rounded"
            />
            <textarea
              placeholder="Message"
              className="w-full p-2 bg-input border border-border rounded min-h-[100px]"
            />
            <button type="submit" className="px-8 border border-border py-2 bg-input text-white rounded hover:bg-white hover:text-black">
              Send
            </button>
          </form>
        </div>
        {/* space */}
        {/* Second Column */}
        <div className="space-y-6 self-center">
          <div className="p-6 bg-transparent border border-border rounded">
            <div className="flex items-center space-x-4">
              <div className="p-4 bg-white rounded-full">
                <HiOutlineMailOpen className="text-primary w-7 h-7" />
              </div>
              <div>
                <div className="text-lg font-bold">Email Address</div>
                <div><a href="mailto:info@pixelizio.com">info@pixelizio.com</a></div>
              </div>
            </div>
          </div>
          <div className="p-6 bg-transparent flex flex-col justify-center items-center border border-border rounded">
            <div className="text-2xl font-bold mb-4">Follow Us</div>
            <div className="flex space-x-4">
              <a href="https://www.facebook.com/pixelizio" target="_blank" rel="noopener noreferrer" className="text-primary bg-white p-4 rounded-full hover:bg-accent hover:p-3.5 hover:text-white transition-all duration-200 ease-in-out w-[45px] h-[45px] flex justify-center items-center">
                <BsFacebook className="w-9 h-9" />
              </a>
              <a href="https://www.pinterest.ca/pixelizioltd/" target="_blank" rel="noopener noreferrer" className="text-primary bg-white p-4 rounded-full hover:bg-accent hover:p-3.5 hover:text-white transition-all duration-200 ease-in-out w-[45px] h-[45px] flex justify-center items-center">
                <BsPinterest className="w-9 h-9" />
              </a>
              <a href="https://www.linkedin.com/company/pixelizio-ltd/" target="_blank" rel="noopener noreferrer" className="text-primary bg-white p-4 rounded-full hover:bg-accent hover:p-3.5 hover:text-white transition-all duration-200 ease-in-out w-[45px] h-[45px] flex justify-center items-center">
                <BsLinkedin className="w-9 h-9" />
              </a>
              <a href="https://www.instagram.com/pixelizio/" target="_blank" rel="noopener noreferrer" className="text-primary bg-white p-4 rounded-full hover:bg-accent hover:p-3.5 hover:text-white transition-all duration-200 ease-in-out w-[45px] h-[45px] flex justify-center items-center">
                <BsInstagram className="w-9 h-9" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Contact
