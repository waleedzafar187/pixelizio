interface Service {
    title: string
    description: string
    icon: string
  }
  
  const services: Service[] = [
    {
      title: "Logo Design",
      description:
        "Your logo is the face of your brand. You and our designers will create a unique and fitting logo for your business.",
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>`,
    },
    {
      title: "Branding & Identity",
      description:
        "Building a strong brand consistently requires consistent branding. From color palette to typeface, we design complete branding packages that cover all facets of your brand, making it look polished and professional anywhere it is used.",
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
      </svg>`,
    },
    {
      title: "Marketing Materials",
      description:
        "Need flyers, brochures, business cards, or banners? We ensure your marketing materials stand out from the competition, clearly express your point of view, and look appealing.",
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9.5a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
      </svg>`,
    },
    {
      title: "Digital Graphics",
      description:
        "We can create exciting and successful digital images for a website or a social media post. We ensure that our designs are best for online platforms so that you may reach your audience anywhere.",
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>`,
    },
  ]
  
  const GraphicDesign = `
  <div class="min-h-screen text-white">
    <!-- Hero Section -->
    <section class="relative py-8">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="grid lg:grid-cols-2 gap-12 items-center">
          <div class="space-y-6">
            <div class="flex items-center gap-2">
              <div class="h-px w-12 bg-red-500"></div>
              <span class="text-red-500 font-medium">Graphic Design</span>
            </div>
            <h1 class="text-3xl lg:text-4xl font-bold leading-tight">
              Designs that Go Beyond Aesthetics
            </h1>
            <p class="text-zinc-400 text-lg leading-relaxed">
              A well-designed product can significantly influence today's visually driven society. At Pixelizio, we transform graphic design into visual storytelling that captivates viewers and gives your brand life.
            </p>
            <a href="/contact" class="inline-block">
              <button class="px-6 py-1 border border-white rounded-full text-white hover:bg-white hover:text-black transition-all duration-300">
                Get In Touch
              </button>
            </a>
          </div>
          <div class="relative">
            <img 
              src="/assets/servicesDetail/Graphic Design.jpg"
              alt="Graphic Design Services" 
              class="rounded-2xl w-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  
    <!-- Value Proposition -->
    <section class="py-8">
      <div class="container max-w-[810px] mx-auto px-4 text-center">
        <h2 class="text-2xl lg:text-3xl font-bold mb-6">
          Your brand's visuals are often the first thing your audience will notice.
        </h2>
        <p class="text-zinc-400 max-w-3xl mx-auto">
          Professionally created graphics can build credibility, grab viewers' attention, and stay in their memories. This is why investing in excellent design is so important if one wants to be observed in today's competitive market.
        </p>
      </div>
    </section>
  
    <!-- Services Section -->
    <section class="py-8">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="flex flex-col lg:flex-row gap-12">
          <div class="lg:w-1/3">
            <h2 class="text-2xl lg:text-3xl font-bold sticky top-28">
              Our Graphic Design Services
            </h2>
          </div>
          <div class="lg:w-2/3 grid gap-6">
            ${services
              .map(
                (service, index) => `
              <div class="group">
                <div class="p-6 rounded-xl bg-zinc-900/50 border border-zinc-800/50 hover:border-zinc-700 transition-all duration-300">
                  <div class="flex items-start gap-6">
                    <div class=" p-3 rounded-lg bg-zinc-800 flex items-center justify-center text-red-500">
                      ${service.icon}
                    </div>
                    <div class="space-y-3">
                      <h3 class="text-xl font-semibold">${service.title}</h3>
                      <p class="text-zinc-400">${service.description}</p>
                    </div>
                  </div>
                </div>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      </div>
    </section>
  
    <!-- Approach Section -->
    <section class="py-8">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="bg-zinc-900/50 p-8 rounded-xl border border-zinc-800/50">
          <div class="relative z-10">
            <h2 class="text-2xl lg:text-3xl font-bold mb-6 text-center">Our Approach</h2>
            <p class="text-zinc-400 text-center max-w-3xl mx-auto">
              At Pixelizio, great design goes beyond aesthetics. It's all about creating images your viewers will find meaningful. We approach things team-wise, meaning we will discuss and implement your objectives extensively.
            </p>
          </div>
        </div>
      </div>
    </section>
  
    <!-- CTA Section -->
    <section class="py-0">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="bg-zinc-900/50 rounded-xl border border-zinc-800/50">
          <div class="p-8 text-center">
            <h2 class="text-2xl lg:text-3xl font-bold mb-6">
              Ready to Elevate Your Brand with Stunning Design?
            </h2>
            <p class="text-zinc-400 text-lg mb-8 max-w-2xl mx-auto">
              Let Pixelizio help you tell your story through captivating visuals. Whether you need a single design or a complete rebranding, our graphic design services are here to help your business shine.
            </p>
            <a href="/contact" class="inline-block">
              <button class="px-6 py-1 border border-white rounded-full text-white hover:bg-white hover:text-black transition-all duration-300">
                Get In Touch
              </button>
            </a>
          </div>
        </div>
      </div>
    </section>
  </div>
  `
  
  export default GraphicDesign
  
  