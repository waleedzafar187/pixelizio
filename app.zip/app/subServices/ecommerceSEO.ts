// ecommerceSEO
const ecommerceSEO = ` 
 <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h1 class="xl:text-4xl text-3xl font-bold">Ignite eCommerce Triumph with Pixelizio's SEO Mastery</h1>
            <p class="text-md">
            Chart a course to digital success with Pixelizio’s specialized eCommerce SEO. Unleash the full potential of your online store and elevate your business.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get A Quote
            </a>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/ECOMMERCESEO.webp" alt="Seo Audit Service" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
    <!-- Why Choose Pixelizio for Your eCommerce SEO? -->
    <section class="py-6">
      <div class="max-w-[1310px] container px-0 mx-auto text-center">
      <h2 class="xl:text-3xl text-2xl font-bold xl:mb-10 mb-6">Why Choose Pixelizio for Your eCommerce SEO?</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 ">
         <div class="border border-border p-6 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">01</h2>
           <h3 class="font-semibold text-lg mb-2">Expert eCommerce Analysis</h3>
           <p class="text-sm">Leverage our seasoned team's expertise in crafting tailored digital marketing strategies for eCommerce success.</p>
         </div>
         <div class="border border-border p-6 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">02</h2>
           <h3 class="font-semibold text-lg mb-2">Holistic SEO Integration</h3>
           <p class="text-sm">Our eCommerce SEO seamlessly integrates into your overall digital marketing plan, providing a roadmap for triumph.</p>
         </div>
         <div class="border border-border p-6 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">03</h2>
           <h3 class="font-semibold text-lg mb-2">Empower Your E-Store</h3>
           <p class="text-sm">Acquire invaluable digital marketing skills with transparent reporting and personalized recommendations.</p>
         </div>
         <div class="border border-border p-6 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">04</h2>
           <h3 class="font-semibold text-lg mb-2">Outshine Competitors</h3>
           <p class="text-sm">To refine your strategies, stay ahead in the eCommerce landscape with a thorough competitor analysis.</p>
         </div>
      </div>
    </section>
    <!--  Advantage Section -->
    <section class="xl:py-8 py-8 px-0 container flex flex-col items-center justify-center">
    <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-3xl text-2xl font-bold xl:mb-12 mb-8">A Look Into Our eCommerce SEO Process</h2>
            <!-- {/* icon box below */} -->
            <div class="flex flex-col xl:gap-12 gap-6">
              <!-- {/* box 1 */} -->
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Store Analysis</h3>
                  <p class="text-md">Identify hidden opportunities and address weaknesses in your eCommerce website's structure, content, and overall performance.</p>
                </div>
              </div>
               <!-- {/* box 2 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Product Keyword Optimization</h3>
                  <p class="text-md">Harness the power of relevant keywords to drive targeted traffic and enhance your eCommerce SEO efforts.</p>
                </div>
              </div>
              <!-- {/* box 3 */} -->
              <div class="flex items-start  border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Strategic On-Site and Off-Site Optimization</h3>
                  <p class="text-md">Elevate your online store through a comprehensive on-site and off-site optimization strategy.</p>
                </div>
              </div>
              <!-- {/* box 4 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Elevate your online store through a comprehensive on-site and off-site optimization strategy.</h3>
                  <p class="text-md">Resolve technical issues hindering your online store's performance and search engine visibility.</p>
                </div>
              </div>
    </section>
    <!-- Call to Action Section -->
    <section class="xl:py-10 py-5">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Launch Your eCommerce Journey</h2>
        <p class="text-md mb-8">Ready to embark on a successful eCommerce journey? Contact Pixelizio for a free consultation. Whether you’re looking to optimize your product listings, start your eCommerce venture, or enhance your online store’s presence, we’ve got you covered.</p>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
        Get Your eCommerce SEO Now
        </a>
      </div>
    </section>
`;
export default ecommerceSEO;