// ecommerceWebsite
const ecommerceWebsite = ` 
    <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h1 class="xl:text-4xl text-3xl font-bold">Crafting eCommerce Excellence, Elevating Your Digital Success</h1>
            <p class="text-md">
             At Pixelizio, we understand the pivotal role a compelling online presence plays in the real estate industry. Your property deserves more than just a website; it deserves a captivating digital showcase that leaves a lasting impression.
            </p>
            <h2 class="xl:text-xl text font-semibold">Creating Digital Storefronts That Redefine the Norm</h2>
            <p class="text-sm leading-7">
             Step into a realm of eCommerce web design where innovation is the benchmark. Our digital storefronts set a new standard, reshaping the norm and providing your customers with a captivating and seamless online shopping experience.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get In Touch
            </a>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/ecommercewebsite.jpg" alt="Real Estate Landing Page" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>

    <section class="py-16">
      <div class="max-w-[1310px] container px-0 mx-auto text-center">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 ">
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">01</h2>
           <h3 class="font-semibold text-lg mb-2">Make Strategy</h3>
           <p class="text-sm">Define objective brand Plans, keyword research & positioning strategy.</p>
         </div>
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">02</h2>
           <h3 class="font-semibold text-lg mb-2">Website Design</h3>
           <p class="text-sm">We settle on some initial design drafts for website & choose one concept.</p>
         </div>
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">03</h2>
           <h3 class="font-semibold text-lg mb-2">Development</h3>
           <p class="text-sm">To make the content, information architecture, visual design all work.</p>
         </div>
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">04</h2>
           <h3 class="font-semibold text-lg mb-2">Project Testing</h3>
           <p class="text-sm">Our team of experts are always available for any updates you may need.</p>
         </div>
      </div>
    </section>

    <!-- Why Pixelizio Section -->
    <section class="pb-16">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="grid md:grid-cols-2 xl:gap-8 gap-6">
          <!-- Box 1 -->
          <div class="rounded-md flex flex-col xl:pr-20 pr-0 pb-4 gap-4">
            <div class="flex items-end space-x-2 text-primary">
              <svg xmlnsXlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4.15 1.83" class="w-24 h-10 fill-current">
                 <path d="M0.1,0.57C0.25,0.5,0.39,0.4,0.54,0.32C0.69,0.25,0.85,0.2,1.01,0.19c0.3-0.02,0.57,0.11,0.69,0.39 c0.12,0.27,0.14,0.57,0.39,0.76c0.22,0.17,0.5,0.21,0.77,0.22c0.16,0,0.33-0.01,0.49-0.03C3.43,1.51,3.52,1.5,3.61,1.48 c0.08-0.01,0.17-0.02,0.24-0.06c0.04-0.02,0.02-0.07-0.02-0.07C3.75,1.34,3.68,1.37,3.61,1.38C3.53,1.4,3.46,1.42,3.38,1.43 C3.23,1.46,3.07,1.47,2.91,1.47c-0.29,0-0.63-0.04-0.84-0.26c-0.23-0.23-0.2-0.59-0.39-0.84C1.52,0.18,1.26,0.1,1.01,0.11 C0.85,0.12,0.69,0.17,0.54,0.24c-0.16,0.08-0.34,0.17-0.47,0.3C0.06,0.55,0.08,0.58,0.1,0.57L0.1,0.57z"></path>
                 <polygon points="4.06,1.39 3.81,1.24 3.55,1.09 3.78,1.41 3.61,1.76 3.84,1.57"></polygon>
              </svg>
              <span>Ecommerce Website</span>
             </div>
             <h2 class="xl:text-3xl text-xl font-semibold">Elevate Your Business with Bespoke eCommerce Solutions</h2>
             <p class="text-md leading-6">At Pixelizio, we specialize in crafting eCommerce experiences that transcend the ordinary. Your online store is more than just a platform; it’s the gateway to your digital success.</p>
          </div>
          <!-- Box 2 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
           <h3 class="text-lg font-semibold">Tailored Design for Unmatched User Experience</h3>
            <p class="text-md leading-6">Immerse your customers in a visually stunning and user-friendly eCommerce website. Our bespoke designs ensure that your online store not only looks exceptional but also provides an intuitive and seamless shopping experience.</p>
          </div>
          <!-- Box 3 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Mobile-Optimized for On-the-Go Shopping</h3>
            <p class="text-md leading-6">In a mobile-centric world, your eCommerce store needs to shine on every device. Our mobile optimization ensures that your customers can shop effortlessly, whether they're using a smartphone, tablet, or desktop.</p>
          </div>
           <!-- Box 4 -->
           <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Advanced Development for Performance</h3>
            <p class="text-md leading-6">Go beyond aesthetics with our advanced development solutions. From secure payment gateways to efficient inventory management, we ensure that your eCommerce site performs flawlessly, meeting the demands of your growing business.</p>
          </div>
        </div>
      </div>
    </section>
    <!-- Call to Action Section -->
    <section class="pb-8">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Ready to Transform Your Online Presence?</h2>
        <p class="text-md mb-8">Let’s build a website that reflects the uniqueness of your brand and drives success in the digital realm.  Get in touch with Pixelizio today!</p>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
        </a>
      </div>
    </section>
`;
export default ecommerceWebsite;