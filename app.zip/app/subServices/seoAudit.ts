// seoAudit
const seoAudit = ` 
 <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h1 class="xl:text-4xl text-3xl font-bold">Charting Digital Success: Elevate Your Business with Pixelizio's SEO Audit</h1>
            <p class="text-md">
            Unlock the true potential of your website through our expert SEO Audit service. At Pixelizio, we go beyond conventional strategies, focusing on a holistic approach to optimize your digital presence.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get A Quote
            </a>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/seoaudit.jpg" alt="Seo Audit Service" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
    <!-- our audit process -->
    <section class="py-6">
      <div class="max-w-[1310px] container px-0 mx-auto text-center">
      <h2 class="xl:text-3xl text-2xl font-bold xl:mb-10 mb-6">Our SEO Audit Process</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 ">
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">01</h2>
           <h3 class="font-semibold text-lg mb-2">Website Analysis</h3>
           <p class="text-sm">Uncover hidden opportunities and address weaknesses in your website's structure, content, and overall performance.</p>
         </div>
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">02</h2>
           <h3 class="font-semibold text-lg mb-2">Keyword Optimization</h3>
           <p class="text-sm">Harness the power of relevant keywords to drive targeted traffic and strengthen your SEO digital marketing efforts.</p>
         </div>
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">03</h2>
           <h3 class="font-semibold text-lg mb-2">Strategic Optimization</h3>
           <p class="text-sm">Elevate your online presence through a comprehensive on-page and off-page optimization strategy.</p>
         </div>
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">04</h2>
           <h3 class="font-semibold text-lg mb-2">Technical SEO Excellence</h3>
           <p class="text-sm">Address technical issues that might be hindering your website's performance and search engine visibility.</p>
         </div>
      </div>
    </section>
    <!-- CRM Advantage Section -->
    <section class="xl:py-8 py-8 px-0 container flex flex-col items-center justify-center">
    <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-3xl text-2xl font-bold xl:mb-12 mb-8">Why Choose Pixelizio for Your SEO Audit?</h2>
            <!-- {/* icon box below */} -->
            <div class="flex flex-col xl:gap-12 gap-6">
              <!-- {/* box 1 */} -->
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Expert Digital Marketing Analysis</h3>
                  <p class="text-md">Leverage our seasoned team's expertise in crafting a tailored digital marketing strategy for your unique business needs.</p>
                </div>
              </div>
               <!-- {/* box 2 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Comprehensive SEO Digital Marketing Plan</h3>
                  <p class="text-md">Our SEO Audit provides a roadmap for success, integrating seamlessly into your overall digital marketing plan.</p>
                </div>
              </div>
              <!-- {/* box 3 */} -->
              <div class="flex items-start  border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Empower Yourself with Digital Marketing Skills</h3>
                  <p class="text-md">Learn the ins and outs of effective digital marketing through our transparent reporting and personalized recommendations.</p>
                </div>
              </div>
              <!-- {/* box 4 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Stay Ahead with Competitor Analysis</h3>
                  <p class="text-md">Uncover valuable insights from our thorough competitor analysis to refine your digital marketing strategies.</p>
                </div>
              </div>
    </section>
    <!-- Call to Action Section -->
    <section class="xl:py-10 py-5">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Kickstart Your Digital Marketing Journey</h2>
        <p class="text-md mb-8">Ready to embark on a successful digital marketing journey? Get in touch with Pixelizio for a free consultation. Whether you want to learn digital marketing, start your agency, or enhance your online presence, we’ve got you covered.</p>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
        </a>
      </div>
    </section>
`;
export default seoAudit;