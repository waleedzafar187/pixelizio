// softwareDevelopment.ts

const softwareDevelopmentContent =  `
      <div class="max-w-[1310px] mx-auto flex flex-col justify-center items-center">
        <!-- banner section -->
        <section class="xl:py-8 pt-8 xl:px-6 px-0 container text-center xl:max-w-3xl flex flex-col justify-center items-center">
          <div class="flex items-end mb-2 space-x-2 text-primary">
            <svg xmlnsXlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4.15 1.83" class="w-24 h-10 fill-current">
              <path d="M0.1,0.57C0.25,0.5,0.39,0.4,0.54,0.32C0.69,0.25,0.85,0.2,1.01,0.19c0.3-0.02,0.57,0.11,0.69,0.39 c0.12,0.27,0.14,0.57,0.39,0.76c0.22,0.17,0.5,0.21,0.77,0.22c0.16,0,0.33-0.01,0.49-0.03C3.43,1.51,3.52,1.5,3.61,1.48 c0.08-0.01,0.17-0.02,0.24-0.06c0.04-0.02,0.02-0.07-0.02-0.07C3.75,1.34,3.68,1.37,3.61,1.38C3.53,1.4,3.46,1.42,3.38,1.43 C3.23,1.46,3.07,1.47,2.91,1.47c-0.29,0-0.63-0.04-0.84-0.26c-0.23-0.23-0.2-0.59-0.39-0.84C1.52,0.18,1.26,0.1,1.01,0.11 C0.85,0.12,0.69,0.17,0.54,0.24c-0.16,0.08-0.34,0.17-0.47,0.3C0.06,0.55,0.08,0.58,0.1,0.57L0.1,0.57z"></path>
              <polygon points="4.06,1.39 3.81,1.24 3.55,1.09 3.78,1.41 3.61,1.76 3.84,1.57"></polygon>
            </svg>
            <span>Software Development</span>
          </div>
          <h1 class="xl:text-4xl text-2xl font-bold mb-6 mt-2 text-white leading-normal">Transforming Ideas into Reality: The Power of Tailored Software Development</h1>
          <p class="text-md text-gray-300 mb-4  mx-auto">At Pixelizio, we’re more than just a software and marketing house. We’re your partners in digital transformation, dedicated to delivering outstanding services that propel your business forward. Dive into the world of software development with us, where innovation meets expertise to create solutions tailored to your unique needs.</p>
          <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 mt-3 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">Get In Touch</a>
          </button>
        </section>
        <!-- did you know section  -->
        <section class="xl:py-6 py-8 px-0 container flex flex-col items-center justify-center">
          <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-2xl text-xl font-bold  mb-12">Did You Know?</h2>
            <div class="flex flex-col xl:gap-12 gap-6">
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                  <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-lg font-semibold mb-2">Over 80% of businesses report increased efficiency and productivity after implementing custom software solutions.</h3>
                  <p class="text-md text-gray-300">Our team of seasoned developers combines creativity, technical prowess, and industry insights to craft cutting-edge software solutions that drive tangible results for your business.</p>
                </div>
              </div>
  
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                  <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-lg font-semibold mb-2">No two businesses are alike, and neither should their software solutions be.</h3>
                  <p class="text-md text-gray-300">At Pixelizio, we understand the importance of customization. We work closely with you to understand your goals, challenges, and vision, leveraging our expertise to build bespoke software that aligns perfectly with your objectives.</p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- Enjoy Innovative Software Development -->
        <section class="xl:pt-6 py-4 xl:px-6 px-0 text-center">
          <div class="max-w-xl mx-auto">
            <h2 class="xl:text-3xl text-2xl font-semibold mb-4">Enjoy Innovative Software Development for Seamless Operations</h2>
            <p class="text-md text-gray-300 mb-4">Say goodbye to off-the-shelf solutions that barely scratch the surface of your needs. Our innovative approach to software development ensures seamless integration, intuitive user experiences, and scalable architecture that grows with your business.</p>
          </div>
        </section>
        <!-- How We Do It -->
        <section class="xl:py-0 pb-6 py-2 px-0">
          <h2 class="xl:text-3xl text-2xl font-semibold mb-8">How We Do It</h2>
          <div class="mx-auto  grid md:grid-cols-2 lg:grid-cols-2 gap-8">
            <div class="border border-primary p-6 rounded-lg">
              <h3 class="font-semibold mb-4 text-lg text-center">From Concept to Code: Building Your Digital Success Story</h3>
              <p class="text-md text-gray-300 text-center">From the initial concept to the final lines of code, we’re with you every step of the way. Our collaborative process ensures transparency, agility, and a relentless focus on delivering results. Let’s build a digital success story that sets you apart in the market.</p>
            </div>
  
            <div class="border border-border hover:border-primary p-6 rounded-lg">
              <h3 class="font-semibold mb-4 text-lg text-center">Unlocking the Potential of Your Business with Bespoke Software</h3>
              <p class="text-md text-gray-300 text-center">Your business is unique, and so should your software. Our team leverages the latest technologies and industry best practices to unlock the full potential of your business. Whether you need a custom web application, a mobile app solution, or enterprise software, we’ve got the expertise to make it happen.</p>
            </div>
  
            <div class="border border-border hover:border-primary p-6 rounded-lg">
              <h3 class="font-semibold mb-4 text-lg text-center">Drive Efficiency and Growth Through Expert Software Development</h3>
              <p class="text-md text-gray-300 text-center">Efficiency and growth go hand in hand. With our expert software development services, you can optimize processes, empower your teams, and fuel sustainable growth. Let us help you harness the power of technology to drive your business forward.</p>
            </div>
  
            <div class="border border-primary p-6 rounded-lg">
              <h3 class="font-semibold mb-4 text-lg text-center">Your Vision, Our Expertise: Crafting Intuitive Software Solutions</h3>
              <p class="text-md text-gray-300 text-center">Your vision is the driving force behind everything we do. We listen, we understand, and we execute with precision. Let’s turn your vision into reality with intuitive software solutions that empower your business and delight your customers.</p>
            </div>
          </div>
        </section>
        <!-- Ready to Take Your Business to the Next Level? -->
        <section class="xl:py-8 mt-6 py-4 xl:px-6 px-0 text-center">
          <div class="max-w-xl mx-auto">
            <h2 class="xl:text-3xl text-2xl font-semibold mb-4">Ready to Take Your Business to the Next Level?</h2>
            <p class="text-md text-gray-300 mb-8">Contact us today to learn more about our software development or other digital services and how we can help you achieve your goals. Let’s embark on a journey of innovation, collaboration, and success together.</p>
            <div class="flex xl:flex-row flex-col justify-center items-center gap-10">
              <a href="/contact" class="border border-border hover:bg-white hover:text-black text-white py-1 px-4 rounded-full hover:bg-blue-700 transition duration-300">
                Contact Us Today
              </a>
            </div>
          </div>
        </section>
      </div>
    `;
  
  export default softwareDevelopmentContent;
  