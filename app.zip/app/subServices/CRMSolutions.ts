// CRM Solutions 
const CRMSolutions = ` 
 <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h1 class="xl:text-4xl text-3xl font-bold">Optimize Customer Relationships with Pixelizio's CRM Solutions</h1>
            <p class="text-md">
              In modern business, nurturing customer relationships is paramount to success. Pixelizio understands Customer Relationship Management’s (CRM) pivotal role in building lasting connections, driving sales, and fostering brand loyalty.
            </p>
            <p class="text-md">
              We design ERP and CRM solutions that empower your business with tools that streamline interactions, personalize engagements, and drive growth.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get A Quote
            </a> <span><FaAngleDoubleRight /></span></Button>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/crm.webp" alt="CRM Solutions" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
  
    <!-- CRM Advantage Section -->
    <section class="xl:py-16 py-8 px-0 container flex flex-col items-center justify-center">
    <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-3xl text-2xl font-bold xl:mb-16 mb-12">The Pixelizio Advantage in CRM</h2>
            <!-- {/* icon box below */} -->
            <div class="flex flex-col xl:gap-12 gap-6">
              <!-- {/* box 1 */} -->
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">360-Degree Customer View</h3>
                  <p class="text-md">Our CRM systems provide a comprehensive view of each customer, consolidating interactions, purchases, preferences, and history in one place. This 360-degree view gives your team the insights needed to deliver personalized experiences.</p>
                </div>
              </div>
               <!-- {/* box 2 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Enhanced Lead Management</h3>
                  <p class="text-md">Say goodbye to missed opportunities. Our CRM streamlines lead management, from capture to conversion, ensuring no lead slips. Automated workflows and notifications keep your team on top of every prospect.</p>
                </div>
              </div>
              <!-- {/* box 3 */} -->
              <div class="flex items-start  border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Effortless Communication </h3>
                  <p class="text-md">Communication is key, and our CRM simplifies it. Integrated email campaigns, personalized messaging, and scheduling tools ensure your messages reach the right people at the right time, fostering engagement and driving conversions.</p>
                </div>
              </div>
              <!-- {/* box 4 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Data-Driven Decision Making</h3>
                  <p class="text-md">Harness the power of data with our CRM analytics. Real-time reporting and dashboards provide actionable insights into sales trends, customer behavior, and campaign effectiveness, empowering you to make informed decisions.</p>
                </div>
              </div>
              <!-- {/* box 5 */} -->
              <div class="flex items-start">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Seamless Integration</h3>
                  <p>Our CRM integrates with your existing systems, whether your email platform, e-commerce store, or marketing tools. This unified approach eliminates silos, enhances efficiency, and improves collaboration across teams.</p>
                </div>
              </div>
    </section>
  
    <!-- Why Pixelizio Section -->
    <section class="pb-16">
      <div class="container max-w-[1310px] mx-auto px-0">
        <h2 class="xl:text-3xl text-2xl font-bold xl:mb-10 mb-6 text-center">Why Pixelizio for CRM</h2>
        <div class="grid md:grid-cols-3 gap-8">
          <!-- Box 1 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">We understand that every business is unique.</h3>
            <p class="text-md leading-6">Our CRM solutions are customizable to fit your specific needs, whether you're a small startup or a large enterprise.</p>
          </div>
          <!-- Box 2 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
           <h3 class="text-lg font-semibold">Transitioning to a new CRM can be daunting, but we're here to help.</h3>
            <p class="text-md leading-6">Our team provides expert support and training, ensuring a smooth implementation and ongoing success with your CRM.</p>
          </div>
          <!-- Box 3 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Budget-conscious?</h3>
            <p class="text-md leading-6">Our CRM solutions offer cost-effective options without compromising on features. Plus, as your business grows, our systems scale, ensuring your CRM evolves alongside your needs.</p>
          </div>
        </div>
      </div>
    </section>
  
    <!-- Call to Action Section -->
    <section class=" pb-10">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Ready to Optimize Your Customer Relationships?</h2>
        <p class="text-md mb-8">Take the first step towards enhancing your customer experience. Contact us now to explore how our CRM solutions can drive growth, improve efficiency, and foster lasting customer loyalty.</p>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
        </a>
      </div>
    </section>
`;
export default CRMSolutions;