interface Feature {
    icon: string
    title: string
    description: string
  }
  
  const heroContent = {
    title: "Improve Your Mobile Experience with Cutting-Edge App Development",
    description:
      "Use Pixelizio's premium mobile application development to unlock your company's full capability. Whether you need a high-performance native app or a flexible cross-platform solution, our knowledgeable staff is ready to produce outstanding results that inspire activity and expansion.",
  }
  
  const crossPlatformFeatures: Feature[] = [
    {
      icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
      </svg>`,
      title: "Cost Efficiency",
      description: "Save time and resources with a single codebase that serves multiple platforms.",
    },
    {
      icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M13 10V3L4 14h7v7l9-11h-7z"/>
      </svg>`,
      title: "Rapid Deployment",
      description: "Get your app to market faster with streamlined development processes.",
    },
    {
      icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
      </svg>`,
      title: "Consistent User Experience",
      description: "Enjoy a cohesive design and functionality across all devices.",
    },
  ]
  
  const nativeFeatures = [
    {
      title: "Native Applications",
      description:
        "For apps that demand superior performance and full platform integration, our native development services are your best choice. We specialize in creating native applications using the following:",
    },
    {
      title: "Kotlin and Java",
      description: "Kotlin and Java for robust Android applications.",
    },
    {
      title: "Swift",
      description: "Swift for cutting-edge iOS solutions.",
    },
  ]
  
  const benefits = [
    {
      title: "Enhanced Performance",
      description: "Experience smooth, responsive apps optimized for each platform.",
    },
    {
      title: "Superior Security",
      description: "Implement advanced security features specific to each operating system.",
    },
    {
      title: "Seamless Integration",
      description: "Leverage native features and APIs for a truly native user experience.",
    },
  ]
  
  const MobileApplication = `
    <div class="min-h-screen text-white">
      <!-- Hero Section -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <div class="max-w-3xl mx-auto flex flex-col items-center justify-center text-center space-y-6">
            <h1 class="text-2xl md:text-3xl lg:text-4xl font-bold leading-tight">
              ${heroContent.title}
            </h1>
            <p class="text-zinc-400 leading-relaxed">
              ${heroContent.description}
            </p>
            <button class="bg-transparent text-center text-white flex gap-2 hover:bg-white hover:text-black py-2 mt-3 px-5 border border-1 rounded-full text-base font-medium">
              <a href="/contact">Contact Us</a>
            </button>
          </div>
        </div>
      </section>
      <!-- Cross-Platform Features -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <div class="text-center mb-12">
            <h2 class="text-2xl md:text-3xl font-bold mb-4">Cross-Platform Applications</h2>
            <p class="text-zinc-400 max-w-3xl mx-auto">
              Leverage cross-platform mobile apps created with React Native, Flutter, and Kotlin Multiplatform to maximize your influence. Our solutions guarantee the flawless performance of your app on iOS and Android systems.
            </p>
          </div>
  
          <div class="grid md:grid-cols-3 gap-6">
            ${crossPlatformFeatures
              .map(
                (feature) => `
              <div class="group relative">
                <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                <div class="relative bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 p-6 rounded-xl hover:border-red-500/50 transition-all duration-300">
                  <div class="text-primary mb-4">${feature.icon}</div>
                  <h3 class="text-lg font-semibold mb-2">${feature.title}</h3>
                  <p class="text-zinc-400 text-sm">${feature.description}</p>
                </div>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      </section>
      <!-- Native Applications -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <div class="grid lg:grid-cols-2 gap-12 items-center">
            <div class="space-y-6">
              <h2 class="text-2xl md:text-3xl font-bold">
                Ready to Reach a Broader Audience with Less Effort?
              </h2>
              <p class="text-zinc-400">
                Contact us now to discuss your cross-platform app needs and start your project today.
              </p>
            </div>
            <div class="space-y-6">
              ${nativeFeatures
                .map(
                  (feature) => `
                <div class="group relative">
                  <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                  <div class="relative p-6 rounded-xl bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 hover:border-red-500/50 transition-all duration-300">
                    <div class="flex items-center gap-4">
                      <div class="w-3 h-3 bg-red-500 rounded-full"></div>
                      <h3 class="font-semibold">${feature.title}</h3>
                    </div>
                    <p class="mt-2 text-zinc-400 text-sm">${feature.description}</p>
                  </div>
                </div>
              `,
                )
                .join("")}
            </div>
          </div>
        </div>
      </section>
      <!-- Benefits -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <h2 class="text-2xl md:text-3xl font-bold text-center mb-12">
            What Our Native Applications Offer
          </h2>
          <div class="grid md:grid-cols-3 gap-6">
            ${benefits
              .map(
                (benefit) => `
              <div class="group relative">
                <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                <div class="relative p-6 rounded-xl bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 hover:border-red-500/50 transition-all duration-300">
                  <div class="flex items-center gap-4 mb-4">
                    <div class="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center">
                      <div class="w-2 h-2 bg-red-500 rounded-full"></div>
                    </div>
                    <h3 class="font-semibold">${benefit.title}</h3>
                  </div>
                  <p class="text-zinc-400 text-sm">${benefit.description}</p>
                </div>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      </section>
      <!-- CTA Section -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <div class="relative overflow-hidden rounded-2xl">
            <div class="absolute inset-0 bg-[#002147]"></div>
            <div class="absolute inset-0 bg-gradient-to-r from-red-500/10 via-transparent to-blue-500/10"></div>
            <div class="relative p-8 flex flex-col justify-center items-center gap-6 text-center">
              <h2 class="text-2xl md:text-3xl font-bold">Get Started Today - Request a Free Consultation</h2>
              <p class="text-zinc-300 max-w-2xl mx-auto">
                Need help with the best solution for your project? Contact our mobile app experts for a free consultation. We will guide you through your choices, offer professional recommendations, and ensure you decide on the correct path to success.
              </p>
              <button class="bg-transparent text-center text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
              <a href="/contact">Get In Touch</a>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  `
  
  export default MobileApplication
  
  