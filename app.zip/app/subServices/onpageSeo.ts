const heroContent = {
  title: "Boost Your Website with On-Page SEO Brilliance",
  description:
    "Step into the world of precision and performance with our On-Page SEO services. Beyond keywords, we sculpt an online experience that captivates users and search engines alike. Explore how our meticulous approach to on-page optimization can redefine your digital presence.",
};

const expertiseList = [
  "Dive Deep into Targeted Keyword Magic",
  "Unleash the Power of Engaging Content",
  "Meta Tag Mastery for Visibility",
  "Elegant URL Structures that Speak",
  "Speed Up with Page Loading Wizardry",
];

const whatSetsUsApart = {
  title: "What Sets Us Apart",
  description:
    "Our team of SEO artisans transforms your website into a masterpiece. We believe in the art of optimization, where every brushstroke enhances your online canvas. Let us craft the success your website deserves.",
};

const serviceCards = [
  {
    title: "Make Strategy",
    description: "Strategize keywords, content, and backlinks for optimal online visibility and rankings.",
    icon: "target",
  },
  {
    title: "Optimizing for Success",
    description: "Elevate SEO success through strategic optimization, boosting visibility and rankings.",
    icon: "file-search",
  },
  {
    title: "Project Testing",
    description: "Effective social media marketing solutions for unparalleled online engagement and growth.",
    icon: "bar-chart-2",
  },
  {
    title: "Strategic SEO Boost",
    description: "Strategize SEO for heightened online visibility and search engine success.",
    icon: "gauge",
  },
];

const detailedFeatures = [
  {
    title: "Smart Keyword Integration",
    description:
      "Behind every thriving website, there's a carefully composed blend of elements. Our keyword experts dive into the essence of your brand, making sure your website resonates with both users and search engines.",
  },
  {
    title: "Content that Captivates",
    description:
      "Our content alchemists craft words into gripping stories that speak to your readers. From exciting blog entries to strong product descriptions, we live your website and make it a destination users won't want to leave.",
  },
  {
    title: "Meta Magic",
    description:
      "Visibility is key, and our meta tag magicians ensure your website shines in the spotlight. With meta tags crafted to perfection, we pave the way for search engines to understand and showcase the brilliance of your content.",
  },
  {
    title: "Speed Wizardry",
    description:
      "In the fast-paced digital realm, speed matters. Our wizards optimize your website for swift page loading, ensuring that users don't just visit but stay. A faster website is a better website, and we make sure yours is at the top of its game.",
  },
];

const ctaSection = {
  title: "On-Page Brilliance Begins Here",
  description:
    "Ready to transform your website's SEO performance? Let's collaborate to create a strategy that sets you apart from the competition and delights both users and search engines.",
};

const onpageSeo = `
    <!-- Hero Section -->
    <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-4 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full flex flex-col justify-center items-start">
            <h1 class="xl:text-4xl text-3xl font-bold">${heroContent.title}</h1>
            <p class="text-md text-muted-foreground">${heroContent.description}</p>
            <button class="inline-flex items-center justify-center rounded-full border  bg-background px-4 py-2 text-sm font-medium shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground">
              <a href="/contact" class="flex items-center gap-2">
                Get A Quote <span class="ml-2">→</span>
              </a>
            </button>
          </div>
          <div>
            <img 
              src="/assets/servicesDetail/onpageseo.jpg"
              alt="On-Page SEO Services" 
              class="rounded-lg w-full xl:h-[380px] h-[300px] object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  
    <!-- Expertise Section -->
    <section class="xl:py-2 py-4 container">
      <div class="lg:w-full xl:max-w-[1310px] mx-auto flex flex-col items-center justify-center">
        <h2 class="xl:text-2xl text-xl font-bold mb-4">Our On-Page SEO Expertise at a Glance</h2>
        <ul class="space-y-3 text-muted-foreground mb-6">
          ${expertiseList
            .map(
              (item) => `
            <li class="flex items-center gap-2">
              <div class="w-1.5 h-1.5 rounded-full bg-primary"></div>
              ${item}
            </li>
          `
            )
            .join("")}
        </ul>
  
        <!-- What Sets Us Apart -->
        <div class="text-center max-w-[700px] border-t border-border pt-8 mb-12">
          <h2 class="xl:text-2xl text-xl font-bold mb-4">${whatSetsUsApart.title}</h2>
          <p class="text-muted-foreground">${whatSetsUsApart.description}</p>
        </div>
  
      <!-- Service Cards -->
<div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-[1310px] mb-16">
  ${serviceCards
    .map(
      (card, index) => `
      <div class="relative rounded-lg border border-gray-200 hover:border-primary bg-card text-card-foreground shadow-sm">
        <!-- Progress Arrow or Number -->
        <div class="absolute -top-4 left-1/2 transform -translate-x-1/2 w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-bold shadow-md">
          ${index + 1} <!-- Numbering -->
        </div>
        
        <div class="p-6 text-center space-y-4">
          <!-- Icon -->
          <div class="w-6 h-4 mx-auto text-primary">
            <i data-lucide="${card.icon}" class="w-full h-full"></i>
          </div>
          
          <!-- Title -->
          <h3 class="font-semibold text-lg">${card.title}</h3>
          
          <!-- Description -->
          <p class="text-sm text-muted-foreground">${card.description}</p>
        </div>
      </div>
    `
    )
    .join("")}
</div>

        <!-- Detailed Features -->
        <div class="space-y-12 w-full">
          <div class="space-y-6">
            <h2 class="text-2xl font-bold text-center">
              Optimize Your Brand's Visibility and Watch it Thrive with Pixelizio's On-Page SEO Mastery
            </h2>
          </div>
  
          <div class="grid md:grid-cols-2 gap-8">
            ${detailedFeatures
              .map(
                (feature) => `
             <div class="space-y-4 p-4 border border-border rounded-lg shadow-sm">
             <h3 class="text-xl font-semibold">${feature.title}</h3>
             <p class="text-muted-foreground">${feature.description}</p>
             </div>
            `
              )
              .join("")}
</div>

        </div>
      </div>
    </section>
  
    <!-- Call to Action -->
    <section class="py-12 bg-muted/50">
      <div class="container max-w-[800px] mx-auto px-4 text-center">
        <h2 class="text-2xl font-bold mb-6">${ctaSection.title}</h2>
        <p class="text-muted-foreground mb-8">${ctaSection.description}</p>
        <a href="/contact" class="inline-flex items-center justify-center rounded-full border hover:bg-white hover:text-black px-8 py-3 text-sm font-medium text-primary-foreground  transition-colors">
          Optimize Your Website Today
        </a>
      </div>
    </section>
  `;

export default onpageSeo;
