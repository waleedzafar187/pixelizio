// UI/UX Design

const UIUXDesign =  `
         <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h1 class="xl:text-4xl text-2xl font-bold">Unlock Your Digital Potential with Pixelizio's UI/UX Design Services</h1>
            <p class="text-md text-gray-300">
            Transform your digital presence and enhance user engagement with Pixelizio’s expert UI/UX design services. 
            </p>
            <p class="text-md text-gray-300">
            Our team of seasoned design professionals specializes in crafting intuitive and visually captivating user experiences that resonate with your audience and drive business growth.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get a Quote
            </a> <span><FaAngleDoubleRight /></span></Button>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/Ui&Ux.webp" alt="CRM Solutions" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
  
    <!-- CRM Advantage Section -->
    <section class="xl:py-16 py-8 px-0 container flex flex-col items-center justify-center">
    <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-2xl text-xl font-bold xl:mb-16 mb-12">Why Choose Pixelizio for Your UI/UX Design Needs?</h2>
            <!-- {/* icon box below */} -->
            <div class="flex flex-col xl:gap-12 gap-6">
              <!-- {/* box 1 */} -->
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Strategic Approach</h3>
                  <p class="text-md text-gray-300">We take a strategic approach to UI/UX design, focusing on aligning design elements with your business objectives to deliver tangible results.</p>
                </div>
              </div>
               <!-- {/* box 2 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Experienced Team</h3>
                  <p class="text-md text-gray-300">Our team of over 150 design consultants, UX/UI designers, researchers, and engineers brings years of experience and expertise to every project.</p>
                </div>
              </div>
              <!-- {/* box 3 */} -->
              <div class="flex items-start  border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">End-to-End Solutions</h3>
                  <p class="text-md text-gray-300">From initial ideation and wireframing to prototyping and implementation, we offer comprehensive UI/UX design services to meet all your needs.</p>
                </div>
              </div>
              <!-- {/* box 4 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">User-Centric Design</h3>
                  <p class="text-md text-gray-300">We prioritize user-centric design principles to ensure your digital products are intuitive, easy to navigate, and provide a seamless user experience.</p>
                </div>
              </div>
              <!-- {/* box 5 */} -->
              <div class="flex items-start">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Innovative Solutions</h3>
                  <p class="text-md text-gray-300">We stay abreast of the latest design trends and technologies to deliver innovative solutions that set your brand apart.</p>
                </div>
              </div>
    </section>
  
    <!-- Why Pixelizio Section -->
    <section class="pb-16">
      <div class="container max-w-[1310px] mx-auto px-0">
         <h2 class="xl:text-3xl text-xl text-center font-bold xl:mb-16 mb-12">Our Approach to UI/UX Design</h2>
        <div class="grid md:grid-cols-4 gap-8">
          <!-- Box 1 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col items-center gap-6 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-xl font-semibold">Investigate</h3>
            <p class="text-md leading-6 text-center text-gray-300">We start by understanding your business requirements, conducting workshops, creating customer journey maps, and developing personas to inform our design process.</p>
          </div>
          <!-- Box 2 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col items-center gap-6 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-xl font-semibold">Design</h3>
            <p class="text-md leading-6 text-center text-gray-300">Our team then proceeds to design the information architecture, create wireframes and prototypes, and develop visually appealing designs that reflect your brand identity.</p>
          </div>
          <!-- Box 3 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col items-center gap-6 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-xl font-semibold">Evaluate</h3>
            <p class="text-md text-gray-300 leading-6 text-center">We conduct usability testing, emotional response testing, and accessibility evaluations to ensure that our designs meet the highest user experience standards.</p>
          </div>
          <!-- Box 4 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col items-center gap-6 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-xl font-semibold">Implement</h3>
            <p class="text-md text-gray-300 leading-6 text-center">Finally, we implement the designs, ensuring quality control and making necessary iterations to deliver a polished final product.</p>
          </div>
        </div>
      </div>
    </section>
  
    <!-- Call to Action Section -->
    <section class="pb-2">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Start Your UI/UX Design Journey Today</h2>
        <p class="text-md text-gray-300 mb-8">Contact Pixelizio today to explore our offerings and take the first step towards creating unforgettable user experiences for your audience.</p>
        <a href="/services" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
        Learn More About Our Services
        </a>
        <a href="/contact" class="text-primary underline xl:py-4 px-8 pt-8 rounded-full hover:bg-blue-700 transition duration-300">
        Contact Us
        </a>
      </div>
    </section>
    `;
  
  export default UIUXDesign;
  