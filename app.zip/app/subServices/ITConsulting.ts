// IT Consulting

const ITConsulting =  `
      <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h1 class="xl:text-4xl text-2xl font-bold">Unlocking Future-Ready IT Solutions with Pixelizio's IT Consulting Services</h1>
            <p class="text-md text-gray-300">
              At Pixelizio, we lead the charge in technological innovation, serving as more than just consultants – we’re your strategic partners in crafting a future-ready IT roadmap. 
            </p>
            <p class="text-md text-gray-300">
            With a team deeply entrenched in cutting-edge tech expertise, we’re committed to ensuring your business adapts to change and thrives in it.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Contact Us
            </a> <span><FaAngleDoubleRight /></span></Button>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/it-consulting.jpg" alt="CRM Solutions" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
  
    <!-- CRM Advantage Section -->
    <section class="xl:py-16 py-8 px-0 container flex flex-col items-center justify-center">
    <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-2xl text-xl font-bold xl:mb-16 mb-12">From Streamlining Operations to Optimizing Your Software Portfolio to Mobile Solutions, We’re Here Every Step of the Way.            </h2>
            <!-- {/* icon box below */} -->
            <div class="flex flex-col xl:gap-12 gap-6">
              <!-- {/* box 1 */} -->
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Our Esteemed Clients</h3>
                  <p class="text-md text-gray-300">Our IT consulting services have empowered businesses and world-class brands worldwide, enhancing their digital strategies and shaping comprehensive product roadmaps.</p>
                </div>
              </div>
               <!-- {/* box 2 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Embark on a Transformative IT Journey With Pixelizio</h3>
                  <p class="text-md text-gray-300">We go beyond mere advice, partnering with you to refine your software architecture and craft a tech-centric digital roadmap. Our dedicated team of software engineers ensures a seamless digital transformation, from strategic planning to precise execution.</p>
                </div>
              </div>
              <!-- {/* box 3 */} -->
              <div class="flex items-start  border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Cloud Transition & Architecture Revamp</h3>
                  <p class="text-md text-gray-300">Bid farewell to legacy IT systems that hinder progress. Our enterprise architecture specialists make transitioning from cumbersome IT structures to agile, cloud-based solutions seamless</p>
                </div>
              </div>
              <!-- {/* box 4 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Balanced Tech Integration & Delivery</h3>
                  <p class="text-md text-gray-300">Consistency in delivering top-notch IT products and services is paramount. At Pixelizio, we bridge the gap between quality delivery and innovation, ensuring you stand out in the digital landscape without compromise.</p>
                </div>
              </div>
              <!-- {/* box 5 */} -->
              <div class="flex items-start">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Optimized Software Portfolio</h3>
                  <p class="text-md text-gray-300">We meticulously analyze your business operations and software tools in use. After a comprehensive evaluation, we provide insights on necessary alterations, potential developments, and third-party integrations, paving the way for enhanced efficiency.</p>
                </div>
              </div>
              <!-- {/* box 6 */} -->
              <div class="flex items-start">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Align Your IT with Business Vision</h3>
                  <p class="text-md text-gray-300">Engage with Pixelizio’s IT consulting services today with our proven IT consulting process.With a decade of innovation under our belt, Intellectsoft’s legacy thrives on reshaping IT strategies for diverse organizations. Our seasoned experts, many with over fifteen years of hands-on experience, deliver tailored solutions swiftly, ensuring tangible value every single time.</p>
                </div>
              </div>
    </section>
  
    <!-- Why Pixelizio Section -->
    <section class="pb-16">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="grid md:grid-cols-4 gap-8">
          <!-- Box 1 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col items-center gap-6 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-xl font-semibold">Analysis</h3>
            <p class="text-md leading-6 text-center text-gray-300">Our CRM solutions are customizable to fit your specific needs, whether you're a small startup or a large enterprise.</p>
          </div>
          <!-- Box 2 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col items-center gap-6 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-xl font-semibold">Strategy</h3>
            <p class="text-md leading-6 text-center text-gray-300">We craft a roadmap and strategy to leverage cutting-edge technology and streamline your software infrastructure, establishing KPIs for software and employee performance.</p>
          </div>
          <!-- Box 3 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col items-center gap-6 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-xl font-semibold">Performance</h3>
            <p class="text-md text-gray-300 leading-6 text-center">Collaboration is key. We analyze workflows and monitor results, removing hindrances to success with the help of our software developers.</p>
          </div>
          <!-- Box 4 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col items-center gap-6 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-xl font-semibold">Improvements</h3>
            <p class="text-md text-gray-300 leading-6 text-center">Once initial goals are met, our experts make recommendations for future enhancements and assist with their implementation.</p>
          </div>
        </div>
      </div>
    </section>
  
    <!-- Call to Action Section -->
    <section class="pb-6">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Unlock Seamless IT Excellence: Leverage Our Decade-Long Expertise</h2>
        <p class="text-md text-gray-300 mb-8">Stay ahead of the curve with Pixelizio’s strategic IT consulting services. We guide you in selecting and implementing the most apt technologies tailored to your business and industry, from blockchain and augmented reality to artificial intelligence and IT.</p>
        <h3 class="xl:text-2xl text-xl font-semibold mb-6">Ready to Shape Your Future-Ready IT Strategy? Talk to Us Today!</h3>
        <a href="/services" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
        Learn More About Our Services
        </a>
        <a href="/contact" class="text-primary underline border hidden xl:inline border-border xl:py-2 px-4 xl:ml-2 ml-0 pt-2 rounded-full hover:bg-blue-700 transition duration-300">
        Contact Us
</a>
      </div>
    </section>
    `;
  
  export default ITConsulting;
  