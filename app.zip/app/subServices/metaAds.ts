// Meta Ads
const metaAds = ` 
<div class="max-w-[1310px] mx-auto flex flex-col justify-center items-center">
    <section class="xl:py-8 pt-8 xl:px-6 px-0 container text-center xl:max-w-3xl flex flex-col justify-center items-center">
    <h1 class="xl:text-4xl text-2xl font-bold mb-2 text-white leading-normal">Meta Ads Mastery Begins with Pixelizio – Your Catalyst for Digital Growth</h1>
    </section>
    <!-- text section -->
    <section class="xl:py-8 pt-8 container max-w-[1310px] text-left flex xl:flex-row flex-col xl:gap-20 gap-4 justify-center items-start">
      <div>
      <h2 class="xl:text-2xl text-xl font-semibold mb-6 mt-2 text-white leading-normal">Why Meta Ads?</h2>
        <p class="text-md text-gray-300 mb-6 mx-auto">
         Meta Ads aren’t just ads; they’re personalized experiences. Harness the power of detailed user insights to tailor your message for maximum impact.  Our Meta Ads strategies at Pixelizio ensure your brand stands out, resonate with potential customers, and turns clicks into conversions.
        </p>
        <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get In Touch
            </a> <span><FaAngleDoubleRight /></span></Button>
        </button>
      </div>
      <div>
      <h2 class="xl:text-2xl text-xl font-semibold mb-6 mt-2 text-white leading-normal">Precision that Pays Off</h2>
        <p class="text-md text-gray-300 mb-4  mx-auto">
         Meta Ads boast unparalleled precision in targeting, leveraging robust user data to ensure your advertisements reach the most relevant audience. With over 3 billion monthly active users and growing, your brand gains unprecedented visibility, and each ad impression is a strategic move toward business success!
        </p>
      </div>
    </section>
  <!-- 2nd Services Section -->
  <section class="py-8 xl:px-6 px-0">
    <div class="max-w-3xl mx-auto">
      <h2 class="xl:text-3xl text-2xl font-semibold mb-6 text-center">Here's the Kicker – Meta Ads deliver not only precision but also cost-effectiveness</h2>
      <p class="text-md text-gray-300 mb-10">Benefit from our team’s in-depth understanding of Meta Ads. We navigate the intricacies of these platforms, optimizing your campaigns for maximum results.</p>
      <div class="space-y-6">
        <div>
          <h3 class="text-xl font-semibold mb-2">(1) Customized for You: Tailored Solutions, Tangible Results</h3>
          <p class="text-md text-gray-300">Collaborate with us to create Meta Ads strategies tailored to your brand. Whether it's increasing brand awareness, driving website traffic, or generating leads – we've got the expertise to make it happen.</p>
        </div>
        <div>
          <h3 class="text-xl font-semibold mb-2">(2) Full-Spectrum Digital Excellence: Beyond Meta Ads</h3>
          <p class="text-md text-gray-300">While Meta Ads are a game-changer, our services go beyond. Explore a full suite of digital marketing solutions, ensuring your brand's online presence is comprehensive and impactful.</p>
        </div>
      </div>
    </div>
  </section>
  <!-- Call to Action Section -->
  <section class="xl:py-8 py-4 xl:px-6 px-0 text-center">
    <div class="max-w-3xl mx-auto">
      <h2 class="xl:text-3xl text-2xl font-semibold mb-4">Ready to Harness the Power of Meta Ads?</h2>
      <p class="text-md text-gray-300 mb-8">
       Contact us now, and let’s transform your digital advertising strategy into a revenue-generating powerhouse.  
      </p>
      <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
      </a>
    </div>
  </section></div> 
`;
export default metaAds;