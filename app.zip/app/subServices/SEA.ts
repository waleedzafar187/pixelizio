interface Feature {
    icon: string
    title: string
    description: string
  }
  
  interface ServiceFeature {
    title: string
    description: string
    isExpanded?: boolean
  }
  
  const features: Feature[] = [
    {
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>`,
      title: "Reach your audience instantly",
      description:
        "Your ads will appear in top search results, right when potential customers are looking for your products or services.",
    },
    {
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>`,
      title: "Set your budget",
      description:
        "You're in control of how much you spend. We'll help you set a budget that works for you and ensures that every penny counts.",
    },
    {
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
      </svg>`,
      title: "Track performance in real time",
      description: "Monitor your marketing campaign's performance with detailed analytics and real-time progress tracking.",
    },
  ]
  
  const serviceFeatures: ServiceFeature[] = [
    {
      title: "Targeted Ad Campaigns",
      description:
        "We develop customized campaigns that use the keywords critical to your business to ensure your ads find the correct audience. Whether your goals are to draw local business or to grow internationally, we will adapt your SEA plan to fit them.",
    },
    {
      title: "Keyword Research & Bid Strategy",
      description:
        "Effective SEA campaigns are built upon solid keyword research. We identify highly converting keywords and create a clever bidding plan that maximizes your ROI. When the competition is high and you need an exact match, we can help you adjust your bids to make leads turn without draining your wallet.",
    },
    {
      title: "Ad Creation & Optimization",
      description:
        "Successful ads inspire action among their viewers. Our staff specializes in creating captivating and easy-to-click advertisements. We work constantly about your ads' headlines, descriptions, and images to guarantee that your campaign is always running smoothly and to increase its effectiveness.",
    },
  ]
  
  const SearchEngineAdvertising = `
  <div class="min-h-screen text-white">
    <!-- Hero Section -->
    <section class="relative overflow-hidden">
      <div class="container max-w-[1310px] mx-auto px-0 py-8">
        <div class="grid lg:grid-cols-2 gap-12 items-center">
          <div class="space-y-6">
            <div class="flex items-center gap-2">
              <div class="h-px w-12 bg-red-500"></div>
              <span class="text-primary font-medium">SEA</span>
            </div>
            <h1 class="text-2xl lg:text-4xl font-bold leading-tight">
              Instant Visibility, Measurable Results.
            </h1>
            <p class="text-zinc-400 text-lg leading-relaxed">
              The best approach to rapidly drive qualified visitors to your website is search engine advertising (SEA). Using SEA will help you reach your brand at the top of search results pages, exactly where your target market is looking. Pixelizio creates data-driven SEA campaigns that all eye toward quick outcomes.
            </p>
            <a href="/contact">
              <button class="px-6 mt-6 py-1.5 border rounded-full text-white hover:bg-white hover:text-black transition-all duration-300">
                Get In Touch
              </button> 
            </a>
          </div>
          <div class="relative">
            <img 
              src="/assets/servicesDetail/sea.jpg"
              alt="SEA Services" 
              class="rounded-2xl w-full object-fit  xl:h-[400px]"
            />
          </div>
        </div>
      </div>
    </section>
  
    <!-- Features Section -->
    <section class="py-8 relative">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="text-center mb-16">
          <div class="flex items-center justify-center gap-2 mb-4">
            <div class="h-px w-12 bg-red-500"></div>
            <span class="text-primary font-medium">SEA</span>
            <div class="h-px w-12 bg-red-500"></div>
          </div>
          <h2 class="text-2xl lg:text-3xl font-bold mb-4">Why Choose SEA?</h2>
        </div>
  
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          ${features
            .map(
              (feature) => `
            <div class="group">
              <div class="relative p-6 border-border border rounded-2xl bg-zinc-900/50 backdrop-blur-sm transition-all duration-300 hover:-translate-y-2 hover:shadow-xl hover:shadow-black/30">
                <div class="absolute inset-0 bg-gradient-to-br from-zinc-800/50 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div class="relative z-10">
                  <div class="w-16 h-16 bg-gradient-to-br from-red-500/10 to-transparent rounded-xl flex items-center justify-center mb-6 text-primary">
                    ${feature.icon}
                  </div>
                  <h3 class="text-xl font-semibold mb-4">${feature.title}</h3>
                  <p class="text-zinc-400">${feature.description}</p>
                </div>
              </div>
            </div>
          `,
            )
            .join("")}
        </div>
      </div>
    </section>
  
    <!-- Service Features Section -->
    <section class="py-8 relative">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="max-w-3xl mx-auto">
          <div class="text-center mb-16">
            <div class="flex items-center justify-center gap-2 mb-4">
              <div class="h-px w-12 bg-red-500"></div>
              <span class="text-primary font-medium">SEA</span>
              <div class="h-px w-12 bg-red-500"></div>
            </div>
            <h2 class="text-2xl lg:text-3xl font-bold mb-6">What is SEA?</h2>
            <p class="text-zinc-400 text-lg">
              If you're looking for instant visibility, SEA does exactly the job. By purchasing ad space on well-known search engines like Bing and Google through SEA, you will be in front of the correct consumers at the appropriate time.
            </p>
          </div>
  
          <div class="space-y-6">
            ${serviceFeatures
              .map(
                (feature) => `
              <div class="relative">
                <div class="p-8 rounded-2xl bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 hover:border-red-500/30 transition-all duration-300">
                  <h3 class="text-xl font-semibold mb-4 flex items-center gap-3">
                    <span class="w-2 h-2 bg-red-500 rounded-full"></span>
                    ${feature.title}
                  </h3>
                  <p class="text-zinc-400 leading-relaxed">
                    ${feature.description}
                  </p>
                </div>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      </div>
    </section>
  
    <!-- CTA Section -->
    <section class="py-4">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="relative rounded-2xl overflow-hidden">
          <div class="absolute inset-0 bg-gradient-to-br from-zinc-900 to-black"></div>
          <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-red-500/10 via-transparent to-transparent"></div>
          
          <div class="relative p-12 text-center">
            <h2 class="text-2xl lg:text-3xl font-bold mb-6">Get Started with SEA Today</h2>
            <p class="text-zinc-400 text-lg mb-6 max-w-2xl mx-auto">
              Ready to boost your online visibility and drive qualified traffic to your website? Contact us now to begin your SEA journey.
            </p>
            <a href="/contact">
              <button class="px-6 py-1.5 border rounded-full text-white hover:bg-white hover:text-black transition-all duration-300">
                Contact Us
              </button> 
            </a>
          </div>
        </div>
      </div>
    </section>
  </div>
  `
  
  export default SearchEngineAdvertising
  
  