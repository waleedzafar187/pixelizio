// socialMediaBrandManagement

const socialMediaBrandManagement =  `

<section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] flex flex-col items-start justify-center w-full">
            <h1 class="xl:text-2xl text-xl font-bold">Step Into a World of Limitless Possibilities With Pixelizio’s Unparalleled Expertise in Social Media Brand Management.</h1>
            <p class="text-md">
            Transform your brand’s presence on platforms like Instagram, Snapchat, Twitter, and LinkedIn, forging meaningful connections that resonate.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get In Touch
            </a> <span><FaAngleDoubleRight /></span></Button>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/socialMediaBrandManagement.webp" alt="CRM Solutions" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
  
    <!-- social media power Section -->
    <section class=" py-10">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-left">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">The Power of Social Media Brand Management</h2>
        <p class="text-md mb-8">Discover the real deal:  Social Media Brand Management is not just a service; it’s a proven force. Experience a remarkable surge in engagement, propelling your brand into the limelight across various social media platforms.</p>
      </div>
    </section>
    <!-- Assist You in Social Media Section -->
    <section class=" pb-6">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-left">
        <h2 class="xl:text-2xl text-xl font-bold mb-6">How We Assist You in Social Media ‘Brand’ Management</h2>
        <p class="text-md mb-8">Our Social Media Brand Management is not about random posts; it’s a smart and complete way to build, maintain, and boost your brand on social media.</p>
        <p class="text-md mb-8">We don’t just share content; we carefully shape your brand image, connect genuinely with your audience, and effectively use each platform’s unique features to tell your brand story.</p>  
    </div>
    </section>
     <!-- Transformative Brand Storytelling Section -->
    <section class=" pb-10">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-left">
        <h2 class="xl:text-2xl text-xl font-bold mb-6">Enjoy Transformative Brand Storytelling with Pixelizio</h2>
        <p class="text-md mb-8">It’s not just about having a presence on social platforms; it’s about crafting a compelling narrative, fostering genuine connections, and ensuring your brand resonates in the hearts and minds of your audience.</p>
    </div>
    </section>
   
    <!-- Why Pixelizio Section -->
    <section class="pb-16">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="grid md:grid-cols-3 gap-8">
          <!-- Box 1 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Crafting Your Brand Narrative</h3>
            <p class="text-md leading-6">We understand that your brand is more than just a logo or a tagline—it's a story waiting to be told. We focus on crafting a narrative reflecting your brand's values, mission, and personality. We ensure that every content contributes to a cohesive and compelling brand story.</p>
          </div>
          <!-- Box 2 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
           <h3 class="text-lg font-semibold">Authentic Engagement Strategies</h3>
            <p class="text-md leading-6">Gone are the days of one-way communication. We go beyond likes and shares, fostering conversations, addressing concerns, and building a community around your brand. Our goal is to make your audience not just customers but brand advocates.</p>
          </div>
          <!-- Box 3 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Strategic Content Distribution</h3>
            <p class="text-md leading-6">It's not just about what you say; it's about where and how you say it. Whether it's the visually captivating realm of Instagram or the real-time updates on Twitter, we tailor our approach to maximize the impact of your content.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Why Choose Pixelizio for Social Media Brand Management  Section -->
    <section class="pb-16">
      <div class="container max-w-[1310px] mx-auto px-0">
        <h2 class="xl:text-3xl text-2xl font-bold xl:mb-16 mb-12 text-center">Why Choose Pixelizio for Social Media Brand Management?</h2>
        <div class="grid md:grid-cols-3 gap-8">
          <!-- Box 1 -->
          <div class="bg-black hover:bg-transparent border-border p-6 rounded-md flex flex-col justify-center items-center text-center gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Expertise that Transcends Trends</h3>
            <p class="text-sm leading-6">We aren't just keeping up with the latest social media trends; we're setting them. Our team at Pixelizio comprises masters of the art and science of Social Media Brand Management. Trust us to keep your brand ahead of the curve on Instagram, Snapchat, Twitter, and LinkedIn.</p>
          </div>
          <!-- Box 2 -->
          <div class="bg-black hover:bg-transparent border-border p-6 rounded-md flex flex-col justify-center items-center text-center gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
           <h3 class="text-lg font-semibold">Customized Solutions for Real Outcomes</h3>
            <p class="text-sm leading-6">Every brand is unique, and so are our solutions. Collaborate with us to tailor Social Media Brand Management campaigns that align with your brand's objectives. Whether it's increasing your LinkedIn presence, creating shareable content on Instagram, or sparking conversations on Twitter – we've got the expertise to turn your brand vision into a social media reality.</p>
          </div>
          <!-- Box 3 -->
          <div class="bg-black hover:bg-transparent border-border p-6 rounded-md flex flex-col justify-center items-center text-center gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Beyond Brand Management: A Holistic Approach</h3>
            <p class="text-sm leading-6">While Social Media Brand Management is our forte, our services extend beyond. Explore a comprehensive suite of digital marketing solutions, from SEO optimization to website development, ensuring your brand's digital journey is managed and maximized.</p>
          </div>
        </div>
      </div>
    </section>
    <!-- Call to Action Section -->
    <section class=" pb-10">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Pixelizio – Where Social Media Brand Management Transforms Potential into Power</h2>
        <p class="text-md mb-8">Ready to unveil the true potential of your brand across the Social Realm? Contact us now, and let’s embark on a journey of Social Media Brand Management that captivates, resonates, and converts.</p>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
        </a>
      </div>
    </section>

`;
export default socialMediaBrandManagement;