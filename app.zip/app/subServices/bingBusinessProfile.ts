const BingBusinessProfile = `
<div class="min-h-screen">
  <!-- Hero Section -->
  <section class="py-6 w-full">
    <div class="container max-w-[1310px] px-0 mx-auto">
      <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
        <div class="space-y-6 xl:w-[90%] w-full">
          <h1 class="xl:text-4xl text-3xl font-bold">Amplify Your Local Impact with Pixelizio's Bing Business Profile Optimization</h1>
          <p class="text-md">
            Ready to dominate local searches on Bing and drive unprecedented growth for your business? Look no further! Pixelizio is your key to unlocking a powerful online presence through our Bing Business Profile service. Elevate your business on Bing and surpass your competitors with our tailored approach.
          </p>
          <a href="/contact" class="inline-block">
            <button class="bg-transparent text-white hover:bg-white hover:text-black py-2 px-5 border rounded-full text-base font-medium transition-all duration-300">
              Get In Touch
            </button>
          </a>
        </div>
        <div class="relative">
          <img 
            src="/assets/servicesdetail/bingbusinessprofile.jpg" 
            alt="Bing Business Profile Service" 
            class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover"
          />
        </div>
      </div>
    </div>
  </section>

  <!-- Strategy Cards Section -->
  <section class="py-6">
    <div class="max-w-[1310px] container px-0 mx-auto">
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        ${[
          {
            number: "01",
            title: "Make Strategy",
            description: "Strategize keywords, content, and backlinks for optimal online visibility and rankings.",
          },
          {
            number: "02",
            title: "Optimizing for Success",
            description: "Elevate SEO success through strategic optimization, boosting visibility and rankings.",
          },
          {
            number: "03",
            title: "Project Testing",
            description: "Effective social media marketing solutions for unparalleled online engagement and growth.",
          },
          {
            number: "04",
            title: "Strategic SEO Boost",
            description: "Strategize SEO for heightened online visibility and search engine success.",
          },
        ]
          .map(
            (item) => `
          <div class="border border-zinc-800 p-6 rounded-md text-white group hover:bg-zinc-900/50 transition-all duration-300">
            <h2 class="text-5xl font-semibold text-zinc-700 group-hover:text-white transition-colors duration-300 mb-4">${item.number}</h2>
            <h3 class="font-semibold text-lg mb-2">${item.title}</h3>
            <p class="text-sm text-zinc-400">${item.description}</p>
          </div>
        `,
          )
          .join("")}
      </div>
    </div>
  </section>

  <!-- Heading Text Section -->
  <section class="xl:py-10 py-5">
    <div class="container max-w-[850px] mx-auto px-0 lg:px-8 text-center">
      <h2 class="xl:text-3xl text-2xl font-bold mb-6">Unleash Your Potential via Bing Business Profile</h2>
      <p class="text-md mb-8 text-zinc-400">In a digital age where local businesses thrive online, Bing Business Profile is your gateway to visibility on Bing Search and Maps. With Pixelizio's Bing Business Profile service, brace yourself for:</p>
    </div>
  </section>

  <!-- Features Grid Section -->
  <section class="pb-16">
    <div class="container max-w-[1310px] mx-auto px-0">
      <div class="grid md:grid-cols-2 xl:gap-10 gap-6">
        ${[
          {
            title: "Seize the Spotlight in Local Searches",
            description:
              "Fine-tune your business listing to claim the top spot in local search results on Bing, leaving your competition in the rearview mirror.",
          },
          {
            title: "Captivate Audiences with Dynamic Content",
            description:
              "Transform your Bing Business Profile into a dynamic hub with striking visuals, engaging posts, and real-time updates. Keep your audience captivated by the latest promotions, events, and news, setting a new benchmark for local SEO expectations.",
          },
          {
            title: "Cultivate Trust and Authority",
            description:
              "Showcase glowing customer reviews and ratings on your Bing Business Profile. We'll help you respond to feedback, demonstrating your unwavering commitment to excellence and earning the trust of those seeking digital marketing agency services.",
          },
          {
            title: "Drive On-Site Traffic with Precision Information",
            description:
              "Ensure your business details—operating hours, contact info, and location—are spot-on in your Bing Business Profile. Make it easy for customers to locate and visit your physical storefront, solidifying your standing as a local SEO services trailblazer.",
          },
        ]
          .map(
            (feature) => `
          <div class="border border-zinc-800 hover:bg-black p-6 rounded-md flex flex-col gap-4 transition-all duration-300">
            <div class="h-6 w-6 border border-red-500 rounded-full flex items-center justify-center">
              <div class="w-4 h-4 bg-red-500 rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">${feature.title}</h3>
            <p class="text-md leading-6 text-zinc-400">${feature.description}</p>
          </div>
        `,
          )
          .join("")}
      </div>
    </div>
  </section>

  <!-- Timeline Section -->
  <section class="py-16">
    <div class="max-w-4xl mx-auto px-4">
      <h3 class="text-white text-2xl md:text-3xl font-bold mb-16">
        Enjoy the Pinnacle of Bing Business Profile Excellence with Pixelizio
      </h3>

      <div class="relative">
        <div class="absolute left-5 top-0 h-full w-px border-l-2 border-dashed border-red-500"></div>
        
        ${[
          {
            title: "Immersive Bing Business Profile Setup and Optimization",
            description:
              "Let us craft and optimize your Bing Business Profile, ensuring every detail is accurate, relevant, and irresistibly appealing to potential customers. We go beyond the efforts of typical local SEO companies.",
          },
          {
            title: "Dynamic Management and Continuous Updates",
            description:
              "Stay steps ahead with our proactive approach to your Bing Business Profile. We'll curate engaging content, respond promptly to customer reviews, and inform your audience about your latest offerings. Expect nothing less than setting new standards in the realm of digital marketing agency services.",
          },
          {
            title: "Strategic Performance Monitoring and Reporting",
            description:
              "Witness the impact of our Bing Business Profile service through detailed performance reports. Gain insights into how your local SEO efforts drive results, empowering you to make informed decisions that outpace even the most advanced local SEO services.",
          },
        ]
          .map(
            (item, index) => `
          <div class="relative flex mb-10 ${index === 2 ? "" : "mb-10"}">
            <div class="flex-shrink-0 w-10 h-10 bg-red-500 rotate-45 relative">
              <div class="absolute inset-0 flex items-center justify-center -rotate-45">
                <div class="w-4 h-4 bg-white rounded-full"></div>
              </div>
            </div>
            <div class="ml-8">
              <h2 class="text-white text-xl font-bold mb-2">${item.title}</h2>
              <p class="text-sm leading-6 text-zinc-400">${item.description}</p>
            </div>
          </div>
        `,
          )
          .join("")}
      </div>
    </div>
  </section>

  <!-- CTA Section -->
  <section class="xl:pt-12 pt-12 py-8">
    <div class="container max-w-[800px] mx-auto px-4 text-center">
      <h2 class="xl:text-3xl text-2xl font-bold mb-6">Ready to Transform Your Bing Presence?</h2>
      <p class="text-md mb-8 text-zinc-400">
        Prevent your business from fading into digital obscurity. Join forces with Pixelizio and let our Bing Business Profile service redefine your local presence on Bing. Contact us now for a free consultation and take the initial stride towards unlocking your business's complete potential.
      </p>
      <a href="/contact" class="inline-block">
        <button class="bg-red-500 hover:bg-red-600 text-white py-2 px-6 rounded-full transition-all duration-300">
          Contact Us Now
        </button>
      </a>
    </div>
  </section>
</div>
`

export default BingBusinessProfile

