const emailMarketingContent = `
<!-- Hero Section -->
<section class="py-6 w-full">
  <div class="container max-w-[1310px] px-0 mx-auto">
    <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
      <div class="space-y-6 xl:w-[90%] w-full flex flex-col justify-center items-start">
        <h1 class="xl:text-4xl text-3xl font-bold">Email Marketing is STILL Relevant. Let Pixelizio Help You</h1>
        <p class="text-md text-gray-300">
          With a staggering 3.9 billion daily users globally, email is not just a communication tool; it’s your direct link to customers. Are you seizing the opportunity to engage with your audience at the perfect moment and turbocharge your sales? If not, you’re at the right place.
        </p>
        <a href="/contact" class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
          Get In Touch
        </a>
      </div>
      <div>
        <img src="/assets/servicesDetail/Email Marketing.webp" alt="Email Marketing" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
      </div>
    </div>
  </div>
</section>

<!-- What is Email Marketing Section -->
<section class="xl:py-16 py-8 px-0 container flex flex-col items-center justify-center">
  <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center">
    <h2 class="xl:text-3xl text-2xl font-bold mb-4">What is Email Marketing?</h2>
    <p class="text-md mb-8 text-gray-300">It’s your digital strategy powerhouse. From newsletters to promotional alerts, it’s how brands connect, build, and grow.</p>
    <h2 class="xl:text-2xl text-xl font-bold mb-4">Why Email Marketing Matters: Building a Loyal Tribe</h2>
    <p class="text-md mb-8 text-gray-300">In the digital marketing landscape, nothing beats the precision of email marketing. Studies show that 61 per cent of consumers prefer brand interactions through email. It’s not just about sending messages; but crafting a connection.</p>

    <!-- Feature Boxes -->
    <div class="flex flex-col xl:gap-12 gap-6">
      <!-- Feature Box 1 -->
      <div class="flex items-start border-b pb-4 border-border">
        <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0"></div>
        <div>
          <h3 class="text-xl font-semibold mb-2">Why Pixelizio's Email Magic Works</h3>
          <p class="text-md text-gray-300">We get it. Mismanaged email campaigns lead to chaos. Pixelizio guides you through the email maze, optimizing your campaigns for B2B and B2C success.</p>
        </div>
      </div>
      <!-- Feature Box 2 -->
      <div class="flex items-start border-b pb-4 border-border">
        <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0"></div>
        <div>
          <h3 class="text-xl font-semibold mb-2">Providing Value, Delivering Results</h3>
          <p class="text-md text-gray-300">Our email services aren't just about sending emails. They're about reaching customers in real time, delivering info, building credibility, and connecting meaningfully.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Importance of Email Marketing for Your Brand Section -->
<section class="pb-10">
  <div class="container max-w-[1310px] mx-auto px-0">
    <h2 class="xl:text-3xl text-2xl font-bold xl:mb-10 mb-6 text-center">Here’s Why Email Marketing is Important for Your Brand.</h2>
    <div class="grid md:grid-cols-4 gap-8">
      <!-- Benefit Box 1 -->
      <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
        <h3 class="text-lg font-semibold">Build Customer Loyalty</h3>
        <p class="text-md leading-6 text-gray-300">Helps in creating strong relationships without breaking the bank.</p>
      </div>
      <!-- Benefit Box 2 -->
      <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
        <h3 class="text-lg font-semibold">Expand Your Business Reach</h3>
        <p class="text-md leading-6 text-gray-300">Get better reach and engagement than traditional methods.</p>
      </div>
      <!-- Benefit Box 3 -->
      <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
        <h3 class="text-lg font-semibold">Connect With Different Audiences</h3>
        <p class="text-md leading-6 text-gray-300">Assists in curating tailored messages for varied segments.</p>
      </div>
      <!-- Benefit Box 4 -->
      <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
        <h3 class="text-lg font-semibold">Save Time and Effort</h3>
        <p class="text-md leading-6 text-gray-300">Emails help with quick communication with ideal market segments.</p>
      </div>
    </div>
  </div>
</section>

<!-- Why We Matter Section -->
<section class="xl:py-16 py-8 px-0 container flex flex-col items-center justify-center">
  <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center">
    <h2 class="xl:text-2xl text-xl font-bold mb-10">Here’s Why WE are Important for Email Marketing for Your Brand.</h2>
    <div class="flex flex-col xl:gap-12 gap-6">
      <!-- Icon Box 1 -->
      <div class="flex items-start border-b pb-4 border-border">
        <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0"></div>
        <div>
          <h3 class="text-xl font-semibold mb-2">Full-Service Email Magic</h3>
          <p class="text-md text-gray-300">Need help with Shopify, drip campaigns, or email blasts? We've got you covered.</p>
        </div>
      </div>
      <!-- Icon Box 2 -->
      <div class="flex items-start border-b pb-4 border-border">
        <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0"></div>
        <div>
          <h3 class="text-xl font-semibold mb-2">Testing for Success</h3>
          <p class="text-md text-gray-300">We don't just launch; we rigorously test every aspect for exceptional results.</p>
        </div>
      </div>
      <!-- Icon Box 3 -->
      <div class="flex items-start border-b pb-4 border-border">
        <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0"></div>
        <div>
          <h3 class="text-xl font-semibold mb-2">Tailored List Segmentation</h3>
          <p class="text-md text-gray-300">Your brand is unique. We research and segment to ensure your emails hit the right spots.</p>
        </div>
      </div>
      <!-- Icon Box 4 -->
      <div class="flex items-start border-b pb-4 border-border">
        <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0"></div>
        <div>
          <h3 class="text-xl font-semibold mb-2">Detailed Email Reports</h3>
          <p class="text-md text-gray-300">Track results effortlessly with custom monthly reports detailing campaign efficiency.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Final Call to Action Section -->
<section class="py-10">
  <div class="container max-w-[610px] mx-auto px-0 text-center flex flex-col items-center gap-4">
    <h2 class="xl:text-3xl text-2xl font-bold">Let Pixelizio Elevate Your Email Strategy!</h2>
    <p class="text-md mb-4">With our state-of-the-art tools, continuous training, and success stories, we’re your partner in business growth. Whether you’re a small business, Fortune 500, or multi-location agency, Pixelizio has your back.
    </p>
    <a href="/contact" class="text-white py-1.5 px-6 rounded-full text-md border border-border hover:bg-white hover:text-black transition duration-300">Get Started</a>
  </div>
  
</section>
`;

export default emailMarketingContent;
