// Declare necessary variables and types
interface ServiceCard {
    icon: string
    title: string
    description: string
  }
  
  interface Feature {
    title: string
    description: string
  }
  
  const heroContent = {
    tag: "Welcome To Pixelizio",
    title: "Your Pathway to Exceptional Web Development.",
    description:
      "With expertise honed through over 1000+ web projects, Pixelizio professionally designs, redesigns, and continuously supports customer-facing and enterprise web apps, achieving high conversion and adoption rates.",
    features: ["Mobile-friendly", "Design for every device", "Positive UX & Helps SEO"],
  }
  
  const serviceCards: ServiceCard[] = [
    {
      icon: `<svg viewBox="0 0 24 24" class="w-6 h-6" fill="none" stroke="currentColor"><path d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>`,
      title: "Business Analysis",
      description:
        "Our business analysts focus on the needs of your target audience to perform requirements engineering and outline the scope of the solution. They also bridge the gap between business stakeholders and an IT team to keep all the involved parties aligned.",
    },
    {
      icon: `<svg viewBox="0 0 24 24" class="w-6 h-6" fill="none" stroke="currentColor"><path d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6z"></path></svg>`,
      title: "UX and UI Design",
      description:
        "We start designing a web app by analyzing the target audience and planning convenient, quick, and frictionless user journeys. Our UI designers wrap the interfaces into a stylish cover along the way.",
    },
    {
      icon: `<svg viewBox="0 0 24 24" class="w-6 h-6" fill="none" stroke="currentColor"><path d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>`,
      title: "Architecture",
      description:
        "Our solution architects plan all functional components and select feasible tech to ensure that the business logic to be implemented is secure and fast.",
    },
    {
      icon: `<svg viewBox="0 0 24 24" class="w-6 h-6" fill="none" stroke="currentColor"><path d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path></svg>`,
      title: "Front-End Development",
      description:
        "Our front-end developers can implement any design idea and ensure all front-end components work properly. We work with all the most-used JavaScript frameworks.",
    },
    {
      icon: `<svg viewBox="0 0 24 24" class="w-6 h-6" fill="none" stroke="currentColor"><path d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4"></path></svg>`,
      title: "Back-End Development",
      description:
        "Our developers accurately implement the business logic of your web app on the back end. We rely on proven frameworks and ensure fast and quality coding in .Net, Java, Python, Node.js, PHP, and Go.",
    },
    {
      icon: `<svg viewBox="0 0 24 24" class="w-6 h-6" fill="none" stroke="currentColor"><path d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536"></path></svg>`,
      title: "Integration",
      description:
        "We set up APIs to integrate your web app with corporate or third-party systems and services. App integration ensures immediate data synchronization across systems.",
    },
  ]
  
  const features: Feature[] = [
    {
      title: "Web Apps",
      description:
        "In our portfolio of over 500+ created web apps, you will find solutions for efficiently managing different business activities. We apply smart automation to streamline workflows and integrate corporate apps for coherent operation.",
    },
    {
      title: "Web Portals",
      description:
        "Pixelizio takes pride in working with web portals for different audiences: customers, business partners, e-commerce users, patients, vendors, and system users. Our portals automatically aggregate data from corporate systems, becoming a source of up-to-date information and help for users.",
    },
    {
      title: "Websites",
      description:
        "Numerous businesses and governmental and non-profit organizations use the websites we've created for corporate presentations and brand building. We ensure our websites have an easy-to-use page editor for dynamic content management.",
    },
    {
      title: "E-commerce",
      description:
        "With over 10+ years in e-commerce development, we've grown our expertise from entry-level apps for startups to custom e-commerce solutions built for large-scale and high-growth businesses. We multiply business efficiency by using scalable microservices architectures.",
    },
  ]
  
  const WebDevelopment = `
    <!-- Hero Section -->
    <section class="w-full text-white">
      <div class="container max-w-[1310px] mx-auto px-2 py-8">
        <div class="grid lg:grid-cols-2 gap-12 items-center">
          <div class="space-y-6">
            <div class="flex items-center gap-2 text-primary">
              <div class="h-px w-8 bg-red-500"></div>
              <span class="text-sm">${heroContent.tag}</span>
            </div>
            <h1 class="xl:text-4xl text-3xl font-bold leading-tight">${heroContent.title}</h1>
            <p class="text-zinc-400">${heroContent.description}</p>
            <ul class="space-y-2">
              ${heroContent.features
                .map(
                  (feature) => `
                <li class="flex items-center gap-2 text-zinc-400">
                  <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                  ${feature}
                </li>
              `,
                )
                .join("")}
            </ul>
          </div>
          <div class="relative">
            <img 
              src="/assets/servicesDetail/webdevelopment.jpg"
              alt="Web Development" 
              class="rounded-lg w-full object-cover"
            />
            <div class="absolute inset-0 bg-gradient-to-r from-red-500/10 to-transparent rounded-lg"></div>
          </div>
        </div>
      </div>
    </section>
  
    <!-- Services Section -->
    <section class="py-8">
      <div class="container max-w-[1310px] mx-auto px-2">
        <h2 class="xl:text-3xl text-2xl font-bold text-center text-white mb-16">Full-Scale Web Development by Pixelizio</h2>
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          ${serviceCards
            .map(
              (service) => `
            <div class="bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 rounded-lg p-6 hover:border-red-500/30 transition-all duration-300">
              <div class="w-12 h-12 bg-gradient-to-br from-red-500/20 to-transparent rounded-lg mb-4 flex items-center justify-center text-primary">
                ${service.icon}
              </div>
              <h3 class="text-xl font-semibold text-white mb-3">${service.title}</h3>
              <p class="text-zinc-400 text-sm leading-relaxed">${service.description}</p>
            </div>
          `,
            )
            .join("")}
        </div>
      </div>
    </section>
  
    <!-- Understanding Section -->
    <section class="py-8">
      <div class="container max-w-[1310px] mx-auto px-2">
        <div class="flex items-center gap-2 text-primary mb-8">
          <div class="h-px w-8 bg-red-500"></div>
          <span class="text-sm">Web Development</span>
        </div>
        <h2 class="xl:text-3xl text-2xl font-bold text-white mb-12">Understanding the Need</h2>
        <div class="grid md:grid-cols-2 gap-8">
          ${features
            .map(
              (feature) => `
            <div class="border border-zinc-800/50 rounded-lg p-8 hover:border-red-500/30 transition-all duration-300">
              <h3 class="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                <span class="w-2 h-2 bg-red-500 rounded-full"></span>
                ${feature.title}
              </h3>
              <p class="text-zinc-400 leading-relaxed">${feature.description}</p>
            </div>
          `,
            )
            .join("")}
        </div>
      </div>
    </section>
  
    <!-- CTA Section -->
    <section class="bg-header rounded-2xl py-10">
      <div class="container max-w-[1310px] mx-auto px-2 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold text-white mb-4">We've got you covered.</h2>
        <p class="text-zinc-400 mb-4">Connect with Pixelizio for Seamless Web Development Today.</p>
        <a href="/contact" class="inline-flex h-11 items-center justify-center rounded-full px-8 text-sm font-medium border hover:bg-white hover:text-black transition-colors">
          Get A Free Quote
        </a>
      </div>
    </section>
  `
  
  export default WebDevelopment
  
  