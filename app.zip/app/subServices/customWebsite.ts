// Custom Website 
const customWebsite = `
 <!-- Hero Section -->
 <section class="text-center py-16 px-6">
    <h2 class="text-primary text-lg font-semibold">Responsive Design</h2>
    <h1 class="text-4xl font-bold mt-4">Your Brand, Our Canvas – Let's Create!</h1>
    <p class="text-gray-300 mt-4 max-w-3xl mx-auto">
      At Pixelizio, we understand the power of a captivating online presence. Your website is the digital face of your brand, and we’re here to help you make it extraordinary.
    </p>
  </section>
<!-- image box section -->
  <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h3 class="xl:text-2xl text-xl font-semibold">We help you create an identity that connects your brand.</h3>
            <p class="text-md">
             Your brand deserves more than recognition; it deserves a story that resonates. At Pixelizio, we redefine brand identity, ensuring it is not just memorable but uniquely yours – a visual language that captivates, connects, and sets your brand apart.
            </p>
            <ul class="text-white space-y-4">
             <li class="flex items-center">
             <span class="text-primary mr-2">✔</span> Mobile-friendly
             </li>
             <li class="flex items-center">
             <span class="text-primary mr-2">✔</span> Design for every device
             </li>
             <li class="flex items-center">
             <span class="text-primary mr-2">✔</span> Positive UX & Helps SEO
             </li>
             </ul>
          </div>
          <div>
            <Image src="/assets/servicesdetail/customwebsite.jpg" alt="Real Estate Landing Page" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
    
    <section class="xl:py-16 py-8">
      <div class="max-w-[1310px] container px-0 mx-auto text-center">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 ">
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">01</h2>
           <h3 class="font-semibold text-lg mb-2">Make Strategy</h3>
           <p class="text-sm">Define objective brand Plans, keyword research & positioning strategy.</p>
         </div>
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">02</h2>
           <h3 class="font-semibold text-lg mb-2">Website Design</h3>
           <p class="text-sm">We settle on some initial design drafts for website & choose one concept.</p>
         </div>
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">03</h2>
           <h3 class="font-semibold text-lg mb-2">Development</h3>
           <p class="text-sm">To make the content, information architecture, visual design all work.</p>
         </div>
         <div class="border border-border p-8 rounded-md text-white group">
           <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">04</h2>
           <h3 class="font-semibold text-lg mb-2">Project Testing</h3>
           <p class="text-sm">Our team of experts are always available for any updates you may need.</p>
         </div>
      </div>
    </section>

    <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h3 class="xl:text-2xl text-xl font-semibold">Designs that Speak. Development that Performs. Content that Converts.</h3>
            <p class="text-md">
            Our team of expert designers and developers is dedicated to creating a web experience that perfectly aligns with the unique essence of your brand.
            </p>
            <h3 class="xl:text-2xl text-xl font-semibold">Committed to Crafting Your Visualizations.</h3>
            <p class="text-md">
            With precision and passion, we transform your ideas into reality, crafting visuals that leave a lasting impression and a website that compels your target audience to convert.
            </p>
          </div>
    <div class="flex flex-col gap-6">
    <!-- box 1 start-->
      <div class="p-8 bg-header hover:bg-black text-white rounded-lg border border-border flex items-start justify-center">
          <!-- Icon -->
           <div class="xl:w-20 w-40 h-8 flex items-center justify-center bg-red-100 rounded-full mr-4">
        <span class="text-primary">✔</span>
        </div>
         <!-- Content -->
        <div>
         <h3 class="text-lg font-bold">Tailored Design</h3>
        <p class="mt-2 text-sm leading-7 text-gray-300">
        Immerse your audience in a visually stunning and user-friendly website that reflects the character of your business. At Pixelizio, we understand that one size doesn't fit all – your custom design awaits.
         </p>
        </div>
      </div>
    <!-- box 1 end-->
    <!-- box 2 start-->
    <div class="p-8 bg-header hover:bg-black text-white rounded-lg border border-border flex items-start justify-center">
          <!-- Icon -->
           <div class="xl:w-24 w-40 h-8 flex items-center justify-center bg-red-100 rounded-full mr-4">
        <span class="text-primary">✔</span>
        </div>
         <!-- Content -->
        <div>
         <h3 class="text-lg font-bold">Advanced Development</h3>
        <p class="mt-2 text-sm leading-7 text-gray-300">
        Beyond aesthetics, our developers ensure your website is not only visually appealing but technically flawless. Experience the power of seamless navigation, responsive design, and a site that performs as great as it looks.
         </p>
        </div>
      </div>
    <!-- box 2 end--> 
     <!-- box 3 start-->
    <div class="p-8 bg-header hover:bg-black text-white rounded-lg border border-border flex items-start justify-center">
          <!-- Icon -->
           <div class="xl:w-20 w-40 h-8 flex items-center justify-center bg-red-100 rounded-full mr-4">
        <span class="text-primary">✔</span>
        </div>
         <!-- Content -->
        <div>
         <h3 class="text-lg font-bold">Mobile Optimization</h3>
        <p class="mt-2 text-sm leading-7 text-gray-300">
        In a world where mobile reigns, your website must shine on every device. Our custom websites are optimized for mobile, ensuring your brand makes an impact, no matter the screen size.
        </p>
        </div>
      </div>
    <!-- box 3 end--> 
          </div>
        </div>
      </div>
    </section>
 <!-- Call to Action Section -->
 <section class="py-8">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Ready to Transform Your Online Presence?</h2>
        <p class="text-md mb-8">Let’s build a website that reflects the uniqueness of your brand and drives success in the digital realm.  Get in touch with Pixelizio today!</p>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
        </a>
      </div>
    </section>
`;
export default customWebsite;
