interface Feature {
    icon: string
    title: string
    description: string
  }
  
  const heroContent = {
    title: "Desktop Applications",
    description:
      "We at Pixelizio realize your desktop application ideas. Our customized solutions are meant to increase productivity, improve effectiveness, and satisfy your particular needs for your company. Find out how our creative approach and knowledgeable staff might completely rethink your desktop experience.",
  }
  
  const erpFeatures: Feature[] = [
    {
      icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
      </svg>`,
      title: "Unified Operations",
      description: "Integrate all aspects of your business into a single, powerful system.",
    },
    {
      icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
      </svg>`,
      title: "Operational Efficiency",
      description: "Automate routine tasks and optimize workflows to enhance productivity.",
    },
    {
      icon: `<svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
      </svg>`,
      title: "Insightful Analytics",
      description: "Gain actionable insights with real-time data reporting and analytics.",
    },
  ]
  
  const softwareFeatures = [
    {
      icon: "📈",
      title: "Scalability",
      description: "Design software that evolves with your business needs.",
    },
    {
      icon: "🔒",
      title: "Enhanced Security",
      description: "Implement top-tier security measures to safeguard your data.",
    },
    {
      icon: "🔄",
      title: "Integration",
      description: "Seamlessly connect with your existing systems to improve functionality.",
    },
  ]
  
  const techStack = [
    {
      title: "C Sharp (C#)",
      description: "For developing scalable and feature-rich applications",
    },
    {
      title: "Electron JS",
      description: "To create modern, cross-platform desktop apps with web technologies",
    },
    {
      title: "Tauri",
      description: "For lightweight, secure applications with exceptional performance",
    },
  ]
  
  const DesktopApplication = `
    <div class="min-h-screen text-white">
      <!-- Hero Section -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <div class="grid lg:grid-cols-2 gap-12 items-center">
            <div class="space-y-6">
              <h1 class="text-2xl md:text-3xl lg:text-4xl font-bold">${heroContent.title}</h1>
              <p class="text-zinc-400 leading-relaxed">${heroContent.description}</p>
              <button class="bg-transparent  text-white flex gap-2 hover:bg-white hover:text-black py-2 mt-3 px-5 border border-1 rounded-full text-base font-medium">
              <a href="/contact">Get In Touch</a>
              </button>
            </div>
            <div class="relative group">
              <div class="absolute inset-0 bg-gradient-to-r from-red-500/10 to-blue-500/10 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
              <img 
                src="/assets/servicesDetail/desktopapplication.jpg"
                alt="Desktop Applications" 
                class="rounded-xl relative z-10"
              />
            </div>
          </div>
        </div>
      </section>
  
      <!-- ERP Features -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <div class="text-center mb-12">
            <div class="flex items-center justify-center gap-2 text-red-500 mb-4">
              <div class="h-px w-8 bg-red-500"></div>
              <span class="text-sm">Why Choose Pixelizio For Desktop Applications?</span>
              <div class="h-px w-8 bg-red-500"></div>
            </div>
            <h2 class="text-2xl md:text-3xl font-bold mb-4">Tailored ERP Systems</h2>
            <p class="text-zinc-400">Streamline your enterprise processes with our bespoke ERP systems. Our solutions offer:</p>
          </div>
  
          <div class="grid md:grid-cols-3 gap-6">
            ${erpFeatures
              .map(
                (feature) => `
              <div class="group relative">
                <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                <div class="relative bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 p-6 rounded-xl hover:border-red-500/50 transition-all duration-300">
                  <div class="text-red-500 mb-4">${feature.icon}</div>
                  <h3 class="text-lg font-semibold mb-2">${feature.title}</h3>
                  <p class="text-zinc-400 text-sm">${feature.description}</p>
                </div>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      </section>
  
      <!-- Software Features -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <h2 class="text-2xl md:text-3xl font-bold text-center mb-12">Comprehensive Enterprise Software</h2>
          <div class="grid md:grid-cols-3 gap-6">
            ${softwareFeatures
              .map(
                (feature) => `
              <div class="group relative overflow-hidden">
                <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                <div class="relative bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 p-8 rounded-xl text-center hover:border-red-500/50 transition-all duration-300">
                  <div class="text-4xl mb-4">${feature.icon}</div>
                  <h3 class="text-lg font-semibold mb-2">${feature.title}</h3>
                  <p class="text-zinc-400 text-sm">${feature.description}</p>
                </div>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      </section>
  
      <!-- Tech Stack -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <h2 class="text-2xl md:text-3xl font-bold text-center mb-12">Our Technology Stack</h2>
          <div class="grid md:grid-cols-3 gap-6">
            ${techStack
              .map(
                (tech) => `
              <div class="group relative overflow-hidden">
                <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                <div class="relative bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 p-8 rounded-xl hover:border-red-500/50 transition-all duration-300">
                  <div class="w-12 h-12 bg-zinc-800 rounded-lg mb-4 flex items-center justify-center">
                    <svg class="w-6 h-6 text-red-500" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"/>
                    </svg>
                  </div>
                  <h3 class="text-lg font-semibold mb-2">${tech.title}</h3>
                  <p class="text-zinc-400 text-sm">${tech.description}</p>
                </div>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      </section>
  
      <!-- CTA Section -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <div class="relative overflow-hidden rounded-2xl">
            <div class="absolute inset-0 bg-[#002147]"></div>
            <div class="absolute inset-0 bg-gradient-to-r from-red-500/10 via-transparent to-blue-500/10"></div>
            <div class="relative p-12 text-center flex items-center justify-center flex-col gap-6 n ">
              <h2 class="text-2xl md:text-3xl font-bold">Get Started with Pixelizio</h2>
              <p class="text-zinc-300  max-w-2xl mx-auto">
                Not sure which fix will work for you? Get a free expert consultation. We will offer individualized advice and recommendations to assist you in selecting the best desktop application project solution.
              </p>
              <button class="bg-transparent text-center text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
              <a href="/contact">Get In Touch</a>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  `
  
  export default DesktopApplication
  
  