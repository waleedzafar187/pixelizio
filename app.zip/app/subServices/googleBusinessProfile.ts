// <!-- Google Business Profile -->
const bingBusinessProfile = `
<section class="py-6 w-full">
  <div class="container max-w-[1310px] px-0 mx-auto">
    <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
      <div class="space-y-6 xl:w-[90%] w-full">
        <h1 class="xl:text-4xl text-3xl font-bold">Boost Your Local Presence with Pixelizio's Google Business Profile (GBP) Service</h1>
        <p class="text-md">
          Enjoy effortless local SEO with Pixelizio, your go-to partner for local business growth through digital marketing! Are you ready to outshine your GBP competition and dominate local searches? Our Google Business Profile (GBP) service is tailor-made to enhance your online visibility, attract more customers, and drive growth in your community.
        </p>
        <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
          <a href="/contact" class="text-white hover:text-black">Get In Touch</a>
        </button>
      </div>
      <div>
        <img src="/assets/servicesdetail/bingbusinessprofile.jpg" alt="SEO Audit Service" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
      </div>
    </div>
  </div>
</section>

<!-- Why Choose Pixelizio for Your eCommerce SEO? -->
<section class="py-6">
  <div class="max-w-[1310px] container px-0 mx-auto text-center">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      <div class="border border-border p-6 rounded-md text-white group">
        <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">01</h2>
        <h3 class="font-semibold text-lg mb-2">Make Strategy</h3>
        <p class="text-sm">Strategize keywords, content, and backlinks for optimal online visibility and rankings.</p>
      </div>
      <div class="border border-border p-6 rounded-md text-white group">
        <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">02</h2>
        <h3 class="font-semibold text-lg mb-2">Optimizing for Success</h3>
        <p class="text-sm">Elevate SEO success through strategic optimization, boosting visibility and rankings.</p>
      </div>
      <div class="border border-border p-6 rounded-md text-white group">
        <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">03</h2>
        <h3 class="font-semibold text-lg mb-2">Project Testing</h3>
        <p class="text-sm">Effective social media marketing solutions for unparalleled online engagement and growth.</p>
      </div>
      <div class="border border-border p-6 rounded-md text-white group">
        <h2 class="text-5xl font-semibold group-hover:text-white text-border mb-4">04</h2>
        <h3 class="font-semibold text-lg mb-2">Strategic SEO Boost</h3>
        <p class="text-sm">Strategize SEO for heightened online visibility and search engine success.</p>
      </div>
    </div>
  </div>
</section>

<!-- Heading Text Section -->
<section class="xl:py-10 py-5">
  <div class="container max-w-[850px] mx-auto px-0 lg:px-8 text-center">
    <h2 class="xl:text-3xl text-2xl font-bold mb-6">Why Google Business Profile?</h2>
    <p class="text-md mb-8">In today’s digital age, having a strong online presence is crucial for local businesses. Google Business Profile is a powerful tool for managing how your business appears on Google Search and Maps. With Pixelizio’s GBP service, you can:</p>
  </div>
</section>

<!-- Why Pixelizio Section -->
<section class="pb-16">
  <div class="container max-w-[1310px] mx-auto px-0">
    <div class="grid md:grid-cols-2 xl:gap-10 gap-6">
      <!-- Box 1 -->
      <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform">
        <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
          <div class="w-4 h-4 bg-primary rounded-full"></div>
        </div>
        <h3 class="text-lg font-semibold">Stand Out in Local Searches</h3>
        <p class="text-md leading-6">Optimize your business listing to ensure it appears at the top of local search results, leaving your GBP competition in the dust.</p>
      </div>
      <!-- Box 2 -->
      <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform">
        <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
          <div class="w-4 h-4 bg-primary rounded-full"></div>
        </div>
        <h3 class="text-lg font-semibold">Build Trust and Credibility</h3>
        <p class="text-md leading-6">Showcase positive customer reviews and ratings. Boost your reputation by responding to customer feedback, demonstrating your commitment to excellent service, and earning the trust of those seeking digital marketing agency services.</p>
      </div>
      <!-- Box 3 -->
      <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform">
        <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
          <div class="w-4 h-4 bg-primary rounded-full"></div>
        </div>
        <h3 class="text-lg font-semibold">Drive More Traffic</h3>
        <p class="text-md leading-6">Use your Google Business Profile to attract more customers to your website and physical location with compelling offers and updates.</p>
      </div>
      <!-- Box 4 -->
      <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform">
        <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
          <div class="w-4 h-4 bg-primary rounded-full"></div>
        </div>
        <h3 class="text-lg font-semibold">Measure Your Success</h3>
        <p class="text-md leading-6">Leverage insights from Google Analytics to monitor your performance and refine your strategy for even better results.</p>
      </div>
    </div>
  </div>
</section>
`;
export default bingBusinessProfile;