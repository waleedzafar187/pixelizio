const heroContent = {
    title: "Off-Page SEO Services",
    description:
      "Embrace a commitment to results with our Off-Page SEO and digital marketing agency – no excuses, just outcomes.",
  };
  
  const expertiseList = [
    "Backlink Quality & Diversity",
    "Social Signals",
    "Brand Mentions",
    "Industry-Specific Insights",
  ];
  
  const whyChooseUs = {
    title: "Why Companies Choose Pixelizio as Their Marketing Agency",
    description:
      "We specialize in Off-Page SEO and digital marketing, focusing on planning, executing, and optimizing strategies that enhance your website's authority and visibility beyond its pages.",
  };
  
  const industryInsights = `
    Our team caters to multiple industries, collaborating with diverse businesses, from software developers to real estate. We have successfully boosted the organizations’ online presence, from startups to industry leaders.
    Whether your audience is in the early stages of research or ready to make a purchase, our Off-Page SEO and Optimization tactics position your company in their view. Moreover, we conduct thorough backlink analysis and implement digital marketing strategies to identify the steps your customers take in their journey. Our team creates strategies to connect with them effectively.
  `;
  
  const servicesDescription = `
    At Pixelizio, we offer a full range of SEO services, from collaborative consulting to comprehensive Off-Page SEO and digital marketing, encompassing strategy development, content creation, link building, and technical Off-Page SEO. Contact us today.
  `;
  
  const serviceCards = [
    {
      title: "Link Building Strategies",
      description:
        "Boost your online presence with strategic link-building services, securing high-quality backlinks that enhance authority.",
      icon: "link",
    },
    {
      title: "Social Media Outreach",
      description:
        "Amplify your brand across social platforms, fostering engagement and driving traffic to improve online reputation.",
      icon: "social",
    },
    {
      title: "Content Marketing Campaigns",
      description:
        "Take your online visibility to new heights with content marketing campaigns that capture attention and build awareness.",
      icon: "file-text",
    },
    {
      title: "Local SEO Optimization",
      description:
        "Dominate local searches with geo-targeted keywords and Google My Business optimization, boosting local visibility.",
      icon: "map-pin",
    },
  ];
  
  const whyOffPageSEO = `
    Off-page SEO is the linchpin of your website's success in the competitive digital landscape. Often synonymous with "Site Trust & Authority," it revolves around the intricate dynamics of your website's backlink and citation profile—essential metrics that play a pivotal role in determining your online standing.
  `;
  
  const ctaSection = {
    title: "Get in Touch",
    description:
      "Discover why companies choose us for Off-Page SEO and digital marketing. Let's collaborate to grow your online presence.",
  };
  
  const offpageSeo = `
    <!-- Hero Section -->
    <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-4 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full flex flex-col justify-center items-start">
            <h1 class="xl:text-4xl text-3xl font-bold">${heroContent.title}</h1>
            <p class="text-md text-muted-foreground">${heroContent.description}</p>
            <button class="inline-flex items-center justify-center rounded-full border  bg-background px-4 py-2 text-sm font-medium shadow-sm transition-colors hover:bg-accent hover:text-accent-foreground">
              <a href="/contact" class="flex items-center gap-2">
                SCHEDULE A CALL <span class="ml-2">→</span>
              </a>
            </button>
          </div>
          <div>
            <img 
              src="/assets/servicesDetail/offpageseo.jpg"
              alt="Off-Page SEO Services" 
              class="rounded-lg w-full xl:h-[380px] h-[300px] object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  
    <!-- Why Choose Us Section -->
    <section class="xl:py-2 py-4 container">
      <div class="lg:w-full xl:max-w-[1310px] mx-auto flex flex-col items-center justify-center">
        <h2 class="xl:text-2xl text-xl font-bold mb-4">${whyChooseUs.title}</h2>
        <p class="text-md text-muted-foreground">${whyChooseUs.description}</p>
      </div>
    </section>
  
    <!-- Industry Insights Section -->
    <section class="py-4 container">
      <div class="lg:w-full xl:max-w-[1310px] mx-auto">
        <p class="text-muted-foreground">${industryInsights}</p>
      </div>
    </section>
  
    <!-- Services Description -->
    <section class="py-4 container">
      <div class="lg:w-full xl:max-w-[1310px] mx-auto">
        <p class="text-muted-foreground">${servicesDescription}</p>
      </div>
    </section>
  
    <!-- Expertise Section -->
    <section class="xl:py-6 py-4 container">
      <div class="lg:w-full xl:max-w-[1310px] mx-auto flex flex-col items-center justify-center">
        <h2 class="xl:text-2xl text-xl font-bold mb-4">Backlink Quality & Diversity | Social Signals | Brand Mentions</h2>
        <ul class="space-y-3 text-muted-foreground mb-12">
          ${expertiseList
            .map(
              (item) => `
            <li class="flex items-center gap-2">
              <div class="w-1.5 h-1.5 rounded-full bg-primary"></div>
              ${item}
            </li>
          `
            )
            .join("")}
        </ul>
  
        <!-- Service Cards -->
        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-[1310px] xl:mb-16 mb-2">
          ${serviceCards
            .map(
              (card, index) => `
              <div class="relative rounded-lg border border-gray-200 hover:border-primary bg-card text-card-foreground shadow-sm">
                <div class="absolute -top-4 left-1/2 transform -translate-x-1/2 w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-bold shadow-md">
                  ${index + 1}
                </div>
                <div class="p-6 text-center space-y-4">
                  <div class="w-6 h-4 mx-auto text-primary">
                    <i data-lucide="${card.icon}" class="w-full h-full"></i>
                  </div>
                  <h3 class="font-semibold text-lg">${card.title}</h3>
                  <p class="text-sm text-muted-foreground">${card.description}</p>
                </div>
              </div>
            `
            )
            .join("")}
        </div>
  
      </div>
    </section>
  
    <!-- Why Off-Page SEO Section -->
    <section class="py-4 container">
      <div class="lg:w-full xl:max-w-[910px] mx-auto text-center">
        <h2 class="xl:text-2xl text-xl font-bold mb-4">Why Off-Page SEO Holds the Key to Your Rankings</h2>
        <p class="text-md text-muted-foreground">${whyOffPageSEO}</p>
      </div>
    </section>
  
    <!-- Call to Action -->
    <section class="xl:py-12 py-6 bg-muted/50">
      <div class="container max-w-[800px] mx-auto px-4 text-center">
        <h2 class="text-2xl font-bold mb-6">${ctaSection.title}</h2>
        <p class="text-muted-foreground mb-8">${ctaSection.description}</p>
        <a href="/contact" class="inline-flex items-center justify-center rounded-full border hover:bg-white hover:text-black px-8 py-3 text-sm font-medium text-primary-foreground  transition-colors">
          Optimize Your Website Today
        </a>
      </div>
    </section>
  `;
  
  export default offpageSeo;
  