// ERP
const ERP = ` 
<div class="max-w-[1310px] mx-auto flex flex-col justify-center items-center">
    <section class="xl:py-8 pt-8 xl:px-6 px-0 container text-center xl:max-w-3xl flex flex-col justify-center items-center">
      <div class="flex items-end mb-2 space-x-2 text-primary">
        <!-- {/* SVG icon*/} -->
        <svg xmlnsXlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4.15 1.83" class="w-24 h-10 fill-current">
        <path d="M0.1,0.57C0.25,0.5,0.39,0.4,0.54,0.32C0.69,0.25,0.85,0.2,1.01,0.19c0.3-0.02,0.57,0.11,0.69,0.39 c0.12,0.27,0.14,0.57,0.39,0.76c0.22,0.17,0.5,0.21,0.77,0.22c0.16,0,0.33-0.01,0.49-0.03C3.43,1.51,3.52,1.5,3.61,1.48 c0.08-0.01,0.17-0.02,0.24-0.06c0.04-0.02,0.02-0.07-0.02-0.07C3.75,1.34,3.68,1.37,3.61,1.38C3.53,1.4,3.46,1.42,3.38,1.43 C3.23,1.46,3.07,1.47,2.91,1.47c-0.29,0-0.63-0.04-0.84-0.26c-0.23-0.23-0.2-0.59-0.39-0.84C1.52,0.18,1.26,0.1,1.01,0.11 C0.85,0.12,0.69,0.17,0.54,0.24c-0.16,0.08-0.34,0.17-0.47,0.3C0.06,0.55,0.08,0.58,0.1,0.57L0.1,0.57z"></path>
        <polygon points="4.06,1.39 3.81,1.24 3.55,1.09 3.78,1.41 3.61,1.76 3.84,1.57"></polygon>
        </svg>
        <!-- {/* Text */} -->
        <span> Streamline Your Business with Pixelizio's ERP Solutions</span>
      </div>
    <h1 class="xl:text-4xl text-2xl font-bold mb-6 mt-2 text-white leading-normal">Unlocking Operational Excellence: ERP Solutions by Pixelizio</h1>
    <p class="text-md text-gray-300 mb-4  mx-auto">
    At Pixelizio, we understand that efficient operations are the backbone of a successful business. We designed our Customer Relationship Management (CRM) and Enterprise Resource Planning (ERP) solutions to streamline your operations, enhance financial management, optimize supply chains, and revolutionize inventory management.
    </p>
  </section>

  <!-- ERP Services Section -->
  <section class="py-8 xl:px-6 px-0">
    <div class="max-w-3xl mx-auto">
      <h2 class="xl:text-3xl text-2xl font-semibold mb-6 text-center">Efficiency Across the Board: Pixelizio's ERP Services</h2>
      <div class="space-y-6">
        <div>
          <h3 class="text-xl font-semibold mb-2">(1) Operations Management</h3>
          <p class="text-md text-gray-300">Seamlessly integrate all your business processes into a single, unified system. Pixelizio’s ERP ensures smooth operations and enhanced productivity from sales to production and customer service.</p>
        </div>
        <div>
          <h3 class="text-xl font-semibold mb-2">(2) Financial Management</h3>
          <p class="text-md text-gray-300">Gain complete visibility and control over your finances with our ERP solutions. Monitor cash flow, track expenses, and generate accurate financial reports for informed decision-making.</p>
        </div>
        <div>
          <h3 class="text-xl font-semibold mb-2">(3) Supply Chain Management</h3>
          <p class="text-md text-gray-300">Optimize your supply chain from end to end. Our ERP system allows you to manage suppliers, track orders, and streamline logistics, ensuring timely deliveries and cost savings.</p>
        </div>
        <div>
          <h3 class="text-xl font-semibold mb-2">(4) Inventory Management</h3>
          <p class="text-md text-gray-300">Say goodbye to stockouts and overstocking. Pixelizio’s ERP provides real-time inventory tracking, demand forecasting, and automated replenishment, optimizing inventory levels and reducing costs.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Features Section -->
  <section class="xl:py-8 py-2 px-0">
    <div class="mx-auto  grid md:grid-cols-2 lg:grid-cols-4 gap-8">
      <div class="border border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Data Security</h3>
        <p class="text-md text-gray-300">Protect your prized business asset — data — with an ERP system’s centralized storage. Replace scattered spreadsheets and documents with a secure, cloud-based solution that enhances data protection and reduces risks.</p>
      </div>
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Standardized/ Centralized Data</h3>
        <p class="text-md text-gray-300">Say goodbye to data inconsistency and duplication. ERP systems standardize critical information, ensuring all unified data for seamless reporting and informed decision-making.</p>
      </div>
      <div class="border border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Compliance Support</h3>
        <p class="text-md text-gray-300">Simplify compliance efforts with accurate and up-to-date records at your fingertips. Customizable reporting tools within ERP make tracking and adjusting compliance requirements easier, ensuring you remain auditable and up-to-date with regulations.</p>
      </div>
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Increased Productivity</h3>
        <p class="text-md text-gray-300">Experience a productivity boost with ERP automation. By streamlining repetitive tasks and simplifying processes, employees have more time for value-adding projects, reducing the need for additional headcount.</p>
      </div>
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Visibility</h3>
        <p class="text-md text-gray-300">Gain powerful insights with ERP’s comprehensive visibility into all aspects of your business. Managers can make faster, more informed decisions, and teams benefit from improved collaboration and access to critical information.</p>
      </div>
      <div class="border border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Scalability</h3>
        <p class="text-md text-gray-300">Grow your business confidently with an ERP system that scales alongside your organization. Add new functionalities and users as needed without  a complete system overhaul.</p>
      </div>
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Mobility</h3>
        <p class="text-md text-gray-300">Access real-time data from anywhere with mobile-friendly ERP solutions. Employees can stay connected and make informed decisions using mobile browsers or dedicated apps, whether in the field or on the go.</p>
      </div>
      <div class="border border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Cost Savings</h3>
        <p class="text-md text-gray-300">Reduce operational costs significantly with ERP automation and efficiency improvements. ERP systems often deliver a rapid return on investment (ROI), from eliminating manual data entry to optimizing resource allocation.</p>
      </div>
      <div class="border border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Real-time Reporting</h3>
        <p class="text-md text-gray-300">Harness the power of customizable, real-time reports across all functions. ERP systems provide insights into finances, inventory, and sales, empowering data-driven decision-making.</p>
      </div> 
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Operational Efficiency</h3>
        <p class="text-md text-gray-300">Improve operational efficiency company-wide. Automation and streamlined processes result in less time spent on manual tasks, reduced errors, and higher profitability.</p>
      </div> 
      <div class="border border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Better Customer Service</h3>
        <p class="text-md text-gray-300">Enhance the customer experience with ERP’s centralized customer information. Access order history, support cases, and contact details in one place for faster, more personalized service.</p>
      </div>
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg">Organized Workflows</h3>
        <p class="text-md text-gray-300">Streamline processes and eliminate redundancies with ERP’s standardized workflows. Every department follows best practices, ensuring consistency and efficiency across the organization.</p>
      </div>
    </div>
  </section>

  <!-- Why Choose Pixelizio Section -->
  <section class="py-8 xl:px-6 px-0">
    <div class="max-w-3xl mx-auto text-center">
      <h2 class="xl:text-3xl text-2xl font-semibold mb-6">Why Choose Pixelizio?</h2>
      <p class="text-md text-gray-300 mb-4">
      Pixelizio offers all these benefits and more, with a comprehensive suite of solutions to manage your entire business on a single platform. NetSuite delivers company-wide visibility, efficiency gains, scalability, mobility, data security, and compliance from accounting to inventory management, supply chain, and HR.
      </p>
      <ul class="list-disc list-inside text-left space-y-4">
        <li class="text-gray-300 text-md"><strong class="text-white text-lg">Leverage Best Practices:</strong> Unify data and processes for streamlined operations.</li>
        <li class="text-gray-300 text-md"><strong  class="text-white text-lg">Access Real-Time Insights:</strong> Make faster decisions with customizable, real-time reports.</li>
        <li class="text-gray-300 text-md"><strong class="text-white text-lg">Improve Customer Experience:</strong> Centralize customer information for personalized service.</li>
        <li class="text-gray-300 text-md"><strong class="text-white text-lg">Enhance Collaboration:</strong> Break down silos and promote teamwork with shared visibility.</li>
        <li class="text-gray-300 text-md"><strong class="text-white text-lg">Grow Confidently:</strong> Scale your business quickly with a flexible and scalable ERP solution.</li>
      </ul>
    </div>
  </section>

  <!-- Call to Action Section -->
  <section class="xl:py-8 py-4 xl:px-6 px-0 text-center">
    <div class="max-w-xl mx-auto">
      <h2 class="xl:text-3xl text-2xl font-semibold mb-4">Take the Next Step with Pixelizio</h2>
      <p class="text-md text-gray-300 mb-8">
      Discover the advantages of Pixelizio for your business. Contact us today for a personalized demo and see how NetSuite can transform your operations, drive growth, and unlock your full potential. Pixelizio – Where Efficiency Meets Innovation!  
      </p>
      <div class="flex xl:flex-row flex-col justify-center items-center gap-10">
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-1 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Us Today
        </a>
        <a href="/services" class="text-primary underline">Learn More About Our Services</a>
      </div>
    </div>
  </section></div> 
`;
export default ERP;