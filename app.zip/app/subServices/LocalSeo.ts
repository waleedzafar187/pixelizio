// Declare necessary variables.  Replace with actual imports or declarations as needed.
const heroContent = {
    tag: "Local SEO",
    title: "Elevate Your Local Business with Our Expert SEO Services",
    description:
      "We help local businesses rank higher in search results, attract more customers, and boost their bottom line.",
  }
  const serviceCards = [
    {
      title: "On-Page Optimization",
      description: "We optimize your website's content and structure to improve search engine rankings.",
    },
    {
      title: "Off-Page Optimization",
      description: "We build high-quality backlinks to your website to increase its authority and visibility.",
    },
    {
      title: "Local Citation Building",
      description: "We create and manage your business listings on relevant online directories.",
    },
    {
      title: "Google My Business Optimization",
      description: "We optimize your Google My Business profile to attract more customers.",
    },
  ]
  const localSEOFeatures = [
    { title: "Increased Visibility", description: "Rank higher in search results for relevant keywords." },
    { title: "More Customers", description: "Attract more potential customers searching for your services." },
    { title: "Improved Brand Reputation", description: "Build trust and credibility with potential customers." },
    { title: "Higher ROI", description: "See a significant return on your investment in local SEO." },
  ]
  const whyChooseUs = {
    title: "Why Choose Our Local SEO Services?",
    description:
      "We offer a comprehensive suite of local SEO services designed to help your business succeed. Our team of experts is dedicated to providing you with the best possible results.",
  }
  const ctaSection = {
    title: "Ready to Take Your Local Business to the Next Level?",
    description:
      "Contact us today to learn more about our local SEO services and how we can help you achieve your business goals.",
  }
  
  // Previous content variables remain the same...
  
  const LocalSeo = `
    <!-- Hero Section -->
    <section class="py-8 w-full bg-background">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[100%] w-full flex flex-col justify-center items-start">
            <div class="flex items-center gap-2 text-red-500">
              <div class="h-[2px] w-8 bg-red-500"></div>
              <span class="text-sm font-medium">${heroContent.tag}</span>
            </div>
            <h1 class="xl:text-3xl text-2xl font-bold text-foreground leading-tight">${heroContent.title}</h1>
            <p class="text-md text-muted-foreground leading-relaxed">${heroContent.description}</p>
            <a href="/contact">
            <button class="inline-flex h-11 items-center justify-center border rounded-full px-8 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-white hover:text-black">
              Get Started
            </button>
            </a>
          </div>
          <div class="relative">
            <div class="absolute inset-0 bg-gradient-to-r from-red-500/10 to-transparent rounded-lg"></div>
            <img 
              src="/assets/servicesDetail/localseo.jpg"
              alt="Local SEO Services" 
              class="rounded-lg w-full xl:h-[380px] h-[300px] object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  
    <!-- Service Cards -->
    <section class="py-6">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          ${serviceCards
            .map(
              (card) => `
            <div class="rounded-lg border border-border/50 bg-card/50 backdrop-blur p-6 hover:border-red-500/50 hover:bg-card/80 transition-all duration-300">
              <div class="w-12 h-12 bg-gradient-to-br from-red-500/20 to-transparent rounded-lg mb-4 flex items-center justify-center">
                <div class="w-6 h-6 text-red-500"></div>
              </div>
              <h3 class="text-md font-semibold mb-3">${card.title}</h3>
              <p class="text-sm text-muted-foreground leading-relaxed">${card.description}</p>
            </div>
          `,
            )
            .join("")}
        </div>
      </div>
    </section>
  
    <!-- Local SEO Features -->
    <section class="py-6">
      <div class="container max-w-[1310px] mx-auto px-4">
        <div class="text-center mb-10">
          <h2 class="xl:text-3xl text-2xl font-bold mb-4">What Can Local SEO Do for Your Business?</h2>
          <div class="w-20 h-1 bg-red-500 mx-auto rounded-full"></div>
        </div>
        <div class="grid md:grid-cols-2 gap-6">
          ${localSEOFeatures
            .map(
              (feature) => `
            <div class="rounded-lg border border-border/50 bg-card/50 backdrop-blur p-8 hover:border-red-500/50 transition-all duration-300">
              <h3 class="text-xl font-semibold mb-4 flex items-center gap-2">
                <span class="w-2 h-2 bg-red-500 rounded-full"></span>
                ${feature.title}
              </h3>
              <p class="text-muted-foreground leading-relaxed">${feature.description}</p>
            </div>
          `,
            )
            .join("")}
        </div>
      </div>
    </section>
  
    <!-- Why Choose Us -->
    <section class="py-6 bg-gradient-to-b from-muted/5 to-transparent">
      <div class="container max-w-[1310px] mx-auto px-4">
        <div class="max-w-[800px] mx-auto text-center">
          <h2 class="xl:text-3xl text-2xl font-bold mb-6">${whyChooseUs.title}</h2>
          <p class="text-md text-muted-foreground leading-relaxed">${whyChooseUs.description}</p>
        </div>
      </div>
    </section>
  
    <!-- CTA Section -->
    <section class="py-6 border-">
      <div class="container max-w-[1310px] mx-auto px-4">
        <div class="max-w-[800px] mx-auto text-center border-y border-border  rounded-2xl p-10">
          <h2 class="xl:text-3xl text-2xl font-bold mb-4">${ctaSection.title}</h2>
          <p class="text-md text-muted-foreground mb-8 leading-relaxed">${ctaSection.description}</p>
          <a href="/contact">
          <button class="inline-flex h-11 items-center justify-center border rounded-full px-8 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-white hover:text-black">
            Contact Now
          </button>
          </a>
        </div>
      </div>
    </section>
  `
  
  export default LocalSeo
  
  