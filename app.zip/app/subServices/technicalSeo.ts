const heroContent = {
    title: "Craft Your Path to Success with Pixelizio's Mastery of Technical SEO.",
    description:
      "Welcome to our technical SEO services in the domain of accuracy and efficiency. Beyond appearances, we explore the minute elements driving the operation of your website. Find out how our Technical SEO knowledge could drive your online profile to unprecedented levels.",
  }
  
  const seoSection = {
    title: "Unlocking Technical SEO Brilliance",
    description:
      "Technical SEO is the pillar of a great website in the always-changing digital terrain. Our professionals carefully improve the technical features so that your site not only looks good but also offers a flawless user experience.",
  }
  
  const serviceCards = [
    {
      title: "Make Strategy",
      description: "Strategize keywords, content, and backlinks for optimal online visibility and rankings.",
    },
    {
      title: "Optimizing for Success",
      description: "Elevate SEO success through strategic optimization, boosting visibility and rankings.",
    },
    {
      title: "Project Testing",
      description: "Effective social media marketing solutions for unparalleled online engagement and growth.",
    },
    {
      title: "Strategic SEO Boost",
      description: "Strategize SEO for heightened online visibility and search engine success.",
    },
  ]
  
  const technicalFeatures = [
    {
      title: "Site Architecture Perfection",
      description:
        "Your website's architecture is its foundation. We optimize it for both search engines and users, creating a structure that enhances navigation and accessibility.",
    },
    {
      title: "Mobile Optimization",
      description:
        "In a mobile-centric world, we ensure your site is not just mobile-friendly but optimized for superior performance on various devices.",
    },
    {
      title: "Crawlability and Indexability",
      description:
        "We optimize your site for search engine crawlers, ensuring every page you want indexed gets the attention it deserves.",
    },
    {
      title: "Page Speed Alchemy",
      description:
        "Speed matters. Our technical wizards fine-tune your website for optimal loading times, keeping visitors engaged and search engines impressed.",
    },
    {
      title: "Structured Data Excellence",
      description:
        "Enhance your search results with structured data. Our experts implement schema markup to provide rich, informative snippets that stand out.",
    },
  ]
  
  const closingSection = {
    tagline: "Optimize. Improvise. Succeed.",
    description:
      "Our team of Technical SEO maestros doesn't just fix issues; we elevate your website's technical foundation. We believe in the art of optimization, where every line of code contributes to a symphony of seamless user experiences and search engine recognition.",
  }
  
  const technicalSeo = `
  <!-- Hero Section -->
  <section class="py-8 w-full bg-background">
    <div class="container max-w-[1310px] px-4 mx-auto">
      <div class="grid lg:grid-cols-2 xl:gap-8 gap-8">
        <div class="space-y-6 xl:w-[100%] w-full flex flex-col justify-center items-start">
          <div class="flex items-center gap-2 text-primary">
            <div class="w-8 h-[2px] bg-primary"></div>
            <span>Speed Up Your Website</span>
          </div>
          <h1 class="xl:text-3xl text-2xl font-bold text-foreground">${heroContent.title}</h1>
          <p class="text-lg text-muted-foreground">${heroContent.description}</p>
        </div>
        <div>
          <img 
            src="/assets/servicesDetail/technicalseo.jpg"
            alt="Technical SEO Services" 
            class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover"
          />
        </div>
      </div>
    </div>
  </section>

  <!-- SEO Brilliance Section -->
  <section class="py-8 bg-muted/10">
    <div class="container max-w-[1310px] mx-auto px-0">
      <div class="grid lg:grid-cols-2 gap-8 items-center">
        <img 
          src="/assets/servicesDetail/technicalseo2.jpg"
          alt="SEO Tools" 
          class="rounded-lg w-full object-cover"
        />
        <div class="space-y-6">
          <h2 class="text-3xl font-bold">${seoSection.title}</h2>
          <p class="text-lg text-muted-foreground">${seoSection.description}</p>
          <button class="inline-flex h-10 items-center justify-center rounded-full border px-8 text-sm font-medium  hover:bg-white hover:text-black">
            SCHEDULE A CALL
          </button>
        </div>
      </div>
    </div>
  </section>

  <!-- Service Cards (with numbering) -->
  <section class="py-8">
    <div class="container max-w-[1310px] mx-auto px-0">
      <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        ${serviceCards
          .map(
            (card, index) => `
          <div class="rounded-lg border border-border bg-card/50 backdrop-blur p-6 hover:bg-black transition-colors">
            <div class="text-3xl font-bold text-primary mb-4">${index + 1}</div>
            <h3 class="text-lg font-semibold mb-3">${card.title}</h3>
            <p class="text-sm text-muted-foreground">${card.description}</p>
          </div>
        `,
          )
          .join("")}
      </div>
    </div>
  </section>

  <!-- Technical Features -->
  <section class="py-8 bg-muted/10">
    <div class="container max-w-[1310px] mx-auto px-0">
      <h2 class="text-3xl font-bold mb-12 text-center">Technical SEO: What's In It?</h2>
      <div class="grid md:grid-cols-2 gap-8">
        ${technicalFeatures
          .map(
            (feature) => `
          <div class="rounded-lg border border-border backdrop-blur p-8">
            <h3 class="text-xl font-semibold mb-4">${feature.title}</h3>
            <p class="text-muted-foreground">${feature.description}</p>
          </div>
        `,
          )
          .join("")}
      </div>
    </div>
  </section>

  <!-- Closing Section -->
  <section class="py-8">
    <div class="container max-w-[910px] mx-auto px-4 text-center">
      <div class="flex items-center justify-center gap-2 text-primary mb-6">
        <div class="w-8 h-[2px] bg-primary"></div>
        <span>${closingSection.tagline}</span>
        <div class="w-8 h-[2px] bg-primary"></div>
      </div>
      <h2 class="text-3xl font-bold mb-8">Optimize Your Digital Presence with Technical SEO Brilliance</h2>
      <p class="text-lg text-muted-foreground mb-8">${closingSection.description}</p>
      <a href="/contact">
      <button class="inline-flex h-11 items-center justify-center border rounded-full px-8 text-sm font-medium text-primary-foreground shadow transition-colors hover:bg-white hover:text-black">
        Contact Now 
      </button>
      </a>
    </div>
  </section>
`

export default technicalSeo;


  
  