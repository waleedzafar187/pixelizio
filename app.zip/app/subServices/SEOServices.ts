interface Service {
    title: string
    image: string
    slug: string
  }
  
  const services: Service[] = [
    {
      title: "On-Page SEO",
      image: "/assets/services media/On-Page-SEO.webp", 
      slug: "on-page-seo",
    },
    {
      title: "Off-Page SEO",
      image: "/assets/services media/Off-Page-SEO.webp",
      slug: "off-page-seo",
    },
    {
      title: "Technical SEO",
      image: "/assets/services media/Technical-SEO.webp",
      slug: "technical-seo",
    },
    {
      title: "Local SEO",
      image: "/assets/services media/Local-SEO.webp",
      slug: "local-seo",
    },
    {
      title: "Google My Business",
      image: "/assets/services media/GMB-SEO.webp",
      slug: "google-my-business",
    },
    {
      title: "Bing Business Profile",
      image: "/assets/services media/Bing-Business-Profile.webp",
      slug: "bing-business-profile",
    },
    {
      title: "E-Commerce SEO",
      image: "/assets/services media/E-Commerce-SEO.webp",
      slug: "ecommerce-seo",
    },
    {
      title: "SEO Audit",
      image: "/assets/services media/SEO-Audit.webp",
      slug: "seo-audit",
    },
  ]
  
  const SEOServices = `
    <div class="min-h-screen">
      <div class="container max-w-[1310px] px-4 mx-auto py-12">
        <!-- Header -->
        <div class="flex items-end gap-2 text-red-500 mb-4">
          <svg class="w-24 h-10 fill-current" viewBox="0 0 4.15 1.83">
            <path d="M0.1,0.57C0.25,0.5,0.39,0.4,0.54,0.32C0.69,0.25,0.85,0.2,1.01,0.19c0.3-0.02,0.57,0.11,0.69,0.39 c0.12,0.27,0.14,0.57,0.39,0.76c0.22,0.17,0.5,0.21,0.77,0.22c0.16,0,0.33-0.01,0.49-0.03C3.43,1.51,3.52,1.5,3.61,1.48 c0.08-0.01,0.17-0.02,0.24-0.06c0.04-0.02,0.02-0.07-0.02-0.07C3.75,1.34,3.68,1.37,3.61,1.38C3.53,1.4,3.46,1.42,3.38,1.43 C3.23,1.46,3.07,1.47,2.91,1.47c-0.29,0-0.63-0.04-0.84-0.26c-0.23-0.23-0.2-0.59-0.39-0.84C1.52,0.18,1.26,0.1,1.01,0.11 C0.85,0.12,0.69,0.17,0.54,0.24c-0.16,0.08-0.34,0.17-0.47,0.3C0.06,0.55,0.08,0.58,0.1,0.57L0.1,0.57z"></path>
            <polygon points="4.06,1.39 3.81,1.24 3.55,1.09 3.78,1.41 3.61,1.76 3.84,1.57"></polygon>
          </svg>
          <span>Services</span>
        </div>
        
        <h1 class="text-2xl md:text-3xl font-bold text-white mb-12">
          Discover Exceptional SEO Services at Pixelizio
        </h1>
  
        <!-- Services Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          ${services
            .map(
              (service) => `
            <div class="group">
              <!-- Card Content -->
              <div class="bg-header rounded-xl p-5 flex flex-col justify-center items-center gap-4 overflow-hidden transition-all duration-300 border border-transparent hover:shadow-xl hover:shadow-black/20 hover:border hover:border-[#4B3F3F]"> 
              <!-- Image Container -->
                <div class="relative h-48 w-72">
                  <img
                    src="${service.image}"
                    alt="${service.title}"
                    class="w-full h-full object-fit transition-transform duration-500"
                  />
                </div>
                <!-- Text Content -->
                <div class="p-6 flex flex-col items-center justify-center gap-6 text-center">
                  <h3 class="text-xl font-semibold text-white">${service.title}</h3>
                  <a href="/services/${service.slug}" class="inline-block">
                    <button class="px-4 py-1.5 text-sm rounded-full border  hover:bg-white hover:text-black transition-all duration-300">
                      Service Details
                    </button>
                  </a>
                </div>
              </div>
            </div>
          `,
            )
            .join("")}
        </div>
      </div>
    </div>
  `
  
  export default SEOServices
  