interface Technology {
    name: string
    description: string
  }
  
  const heroContent = {
    title: "Use Pixelizio to Unlock the Future of Web Applications",
    description:
      "Are you prepared to improve your online visibility? Pixelizio transforms your innovative concepts into state-of-the-art online apps that excite, persuade, and propel your company to new heights. Enter a realm where innovation and technology collide, to reshape your online presence completely.",
  }
  
  const technologies = {
    frontend: [
      { name: "React", description: "Use this dynamic library's power to craft engaging and dynamic user interfaces." },
      {
        name: "NextJS",
        description: "Combine server-side rendering with static site generation for blazingly quick performance.",
      },
      { name: "Vue", description: "Use an easily customizable framework to fit your needs and scalability." },
      {
        name: "Astro",
        description:
          "Use our cutting-edge static site generator to maximize the speed and functionality of your website.",
      },
      {
        name: "Svelte",
        description:
          "With a compiler that produces incredibly efficient code, discover the web development of the future.",
      },
    ],
    backend: [
      {
        name: "NodeJS",
        description: "Power your server with this high-performance JavaScript runtime for unparalleled speed.",
      },
      {
        name: "Python",
        description: "Use Python's efficiency and elegance for your intricate data and backend logic requirements.",
      },
      {
        name: "PHP",
        description:
          "For reliable server-side scripting and database administration, rely on this tried and true language.",
      },
      {
        name: "Go",
        description: "Use Go's concurrency features to your advantage when developing apps that require optimal speed.",
      },
    ],
    deployment: [
      {
        name: "Kubernetes",
        description: "Use this robust platform to orchestrate and grow your containers efficiently.",
      },
      {
        name: "DevOps",
        description: "Adopt an automated and continuous delivery mindset for quicker, more dependable deployments.",
      },
      { name: "AWS", description: "Use Amazon's extensive cloud offering for safe and scalable hosting." },
      {
        name: "Digital Ocean",
        description: "Use our recommended cloud platform to benefit from cost-effectiveness and simplicity.",
      },
      { name: "Azure", description: "Use Microsoft's extensive cloud offerings for flexible and safe solutions." },
    ],
    cms: [
      {
        name: "WordPress",
        description: "The world's most widely used CMS workflow, ideal for producing and managing dynamic web content.",
      },
      {
        name: "Strapi",
        description:
          "An adaptable and customizable headless content management system for contemporary content requirements.",
      },
      {
        name: "Payload",
        description: "A fast and user-friendly high-performance content management system tailored for the custom web.",
      },
    ],
  }
  
  const WebApplications = `
    <div class="min-h-screen text-white">
      <!-- Hero Section -->
      <section class="relative py-8 overflow-hidden">
        <div class="container max-w-[1310px] mx-auto px-0 relative z-10">
          <div class="max-w-3xl mx-auto text-center flex flex-col justify-center items-center space-y-6">
            <h1 class="text-2xl md:text-3xl lg:text-4xl font-bold leading-tight bg-gradient-to-r from-white to-zinc-400 bg-clip-text text-transparent">
              ${heroContent.title}
            </h1>
            <p class="text-zinc-400 leading-relaxed">
              ${heroContent.description}
            </p>
            <button class="bg-transparent  text-white flex gap-2 hover:bg-white hover:text-black py-2 mt-3 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">Get In Touch</a>
            </button>
          </div>
        </div>
      </section>
  
      <!-- Technology Sections -->
      <section class="py-8">
        <div class="container max-w-[1310px] mx-auto px-0">
          <!-- Frontend Development -->
          <div class="mb-14">
            <h2 class="text-2xl font-bold mb-8">Front-End Development</h2>
            <p class="text-zinc-400 mb-8 max-w-2xl">Imagine an aesthetically pleasing, responsive, and intuitive interface. Our front-end development services use the latest developments in web technology to realize your vision.</p>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              ${technologies.frontend
                .map(
                  (tech) => `
                <div class="group relative">
                  <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                  <div class="relative p-6 rounded-xl bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 hover:border-red-500/50 transition-all duration-300">
                    <div class="flex items-center gap-3 mb-3">
                      <div class="w-2 h-2 bg-red-500 rounded-full"></div>
                      <h3 class="font-semibold xl:text-xl text-lg">${tech.name}</h3>
                    </div>
                    <p class="text-zinc-400 text-base">${tech.description}</p>
                  </div>
                </div>
              `,
                )
                .join("")}
            </div>
          </div>
  
          <!-- Backend Development -->
          <div class="mb-14">
            <h2 class="text-2xl font-bold mb-8">Backend Development</h2>
            <p class="text-zinc-400 mb-8 max-w-2xl">A robust and dependable backend is the foundation of any outstanding web application. Our backend development services guarantee your application's seamless operation and scalability.</p>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-2 gap-6">
              ${technologies.backend
                .map(
                  (tech) => `
                <div class="group relative">
                  <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                  <div class="relative p-6 rounded-xl bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 hover:border-red-500/50 transition-all duration-300">
                    <div class="flex items-center gap-3 mb-3">
                      <div class="w-2 h-2 bg-red-500 rounded-full"></div>
                      <h3 class="font-semibold xl:text-xl text-lg">${tech.name}</h3>
                    </div>
                    <p class="text-zinc-400 text-base">${tech.description}</p>
                  </div>
                </div>
              `,
                )
                .join("")}
            </div>
          </div>
  
          <!-- Deployment -->
          <div class="mb-14">
            <h2 class="text-2xl font-bold mb-8">Deployment</h2>
            <p class="text-zinc-400 mb-8 max-w-2xl">With the knowledge that your application is designed for scalability and robustness, deploy with assurance. Our deployment solutions guarantee smooth administration and integration.</p>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              ${technologies.deployment
                .map(
                  (tech) => `
                <div class="group relative">
                  <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                  <div class="relative p-6 rounded-xl bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 hover:border-red-500/50 transition-all duration-300">
                    <div class="flex items-center gap-3 mb-3">
                      <div class="w-2 h-2 bg-red-500 rounded-full"></div>
                      <h3 class="font-semibold xl:text-xl text-lg">${tech.name}</h3>
                    </div>
                    <p class="text-zinc-400 text-sm">${tech.description}</p>
                  </div>
                </div>
              `,
                )
                .join("")}
            </div>
          </div>
  
          <!-- CMS -->
          <div class="mb-14">
            <h2 class="text-2xl font-bold mb-6">Content Management Systems (CMS)</h2>
            <p class="text-zinc-400 mb-8 max-w-2xl">Content management ought to be as easy as content creation. Our CMS solutions help you manage your content quickly and effectively.</p>
            
            <div class="grid md:grid-cols-3 gap-6">
              ${technologies.cms
                .map(
                  (tech) => `
                <div class="group relative">
                  <div class="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 rounded-xl blur-xl transition-all duration-300 opacity-0 group-hover:opacity-100"></div>
                  <div class="relative p-6 rounded-xl bg-zinc-900/50 backdrop-blur-sm border border-zinc-800/50 hover:border-red-500/50 transition-all duration-300">
                    <div class="flex items-center gap-3 mb-3">
                      <div class="w-2 h-2 bg-red-500 rounded-full"></div>
                      <h3 class="font-semibold xl:text-xl text-lg">${tech.name}</h3>
                    </div>
                    <p class="text-zinc-400 text-md">${tech.description}</p>
                  </div>
                </div>
              `,
                )
                .join("")}
            </div>
          </div>
  
          <!-- CTA Section -->
          <div class="relative rounded-2xl overflow-hidden">
            <div class="absolute inset-0 bg-[#002147]"></div>
            <div class="absolute inset-0 bg-gradient-to-r from-red-500/10 via-transparent to-blue-500/10"></div>
            <div class="relative p-8 text-center flex flex-col justify-center items-center gap-6">
              <h2 class="text-2xl md:text-3xl font-bold">Are You Prepared to Transform Your Online Presence?</h2>
              <p class="text-zinc-300 max-w-2xl mx-auto">
                Join forces with Pixelizio right now, and together, let's create something truly unique. Contact us to begin your transformation!
              </p>
              <button class="bg-transparent text-center text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
              <a href="/contact">Get In Touch</a>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  `
  
  export default WebApplications
  
  