// Wordpress Website
const wordpressWebsite = ` 
<section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[98%] w-full">
            <h1 class="xl:text-4xl text-3xl font-bold">We work using the ‘BEST’ design framework</h1>
            <p class="text-md">
             Your website goes beyond merely representing your digital identity; it is a crucial factor in user engagement and conversion rates. This is why 88% of visitors are unlikely to revisit if your site sells a subpar experience.
             At Pixelizio, we’ve helped numerous businesses craft exceptional first impressions through user-friendly, functional, and visually appealing websites.
             We specialize in designing websites that not only boast aesthetic appeal but also enhance your sales potential by optimizing for search engines and ensuring compatibility with mobile devices.
             Let us help you create a professional website for your brand. Reach out to discover more about our web design services at Pixelizio.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get In Touch
            </a>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/wordpresswebsite1.jpg" alt="Wordpress Website Service" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
    <!-- image box section  -->
    <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div>
            <Image src="/assets/servicesdetail/wordpresswebsite2.jpg" alt="Wordpress Website Service" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
          <div class="space-y-6 w-full">
            <h2 class="xl:text-2xl text-xl font-semibold">It's Not Just About Looks: Our Websites Embrace Functionality</h2>
            <p class="text-md">
             Creating an impressive webpage goes beyond just making it look good. While aesthetics matter, there’s more to good web design.
             When we design websites, we aim for more than just pretty visuals. We embrace the best practices in UI and UX, ensuring our websites have a fantastic appearance and function
             seamlessly. So, if you’re searching for a website that’s a breeze to navigate and a pleasure to behold, you’re in the right place.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Contact Us
            </a>
            </button>
          </div>
        </div>
      </div>
    </section>
      <!-- Text box section  -->
      <section class="py-6 xl:pb-16 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto flex flex-col justify-center items-center">
          <div class="space-y-6 max-w-5xl w-full justify-center items-center text-center">
            <h2 class="xl:text-2xl text-xl font-semibold">We work using the ‘BEST’ design framework</h2>
            <p class="text-md">
            By ‘BEST’, we mean the best, a framework we use to actively shape web design and development services that empower businesses to create websites that align with your business goals, driving tangible results. Whether enhancing online presence, increasing conversions, or providing a better customer experience, we support you in achieving your goals and succeeding online.
            </p>
          </div>
      </div>
    </section>
   
    <!-- Why Pixelizio Section -->
    <section class="xl:pb-1 pb-0">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="grid md:grid-cols-2 xl:gap-8 gap-6">
          <!-- Box 1 -->
          <div class="border border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
           <h3 class="text-lg font-semibold">Ease of Use</h3>
            <p class="text-md leading-6">By ‘BEST’, we mean the best, a framework we use to actively shape web design and development services that empower businesses to create websites that align with your business goals, driving tangible results. Whether enhancing online presence, increasing conversions, or providing a better customer experience, we support you in achieving your goals and succeeding online.</p>
            <div class="space-y-4">
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> A clear hierarchy of information and well-defined navigation
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Fast site speed
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Structured data
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Strong internal linking structure
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Sitemap / Robots.txt
            </p>
          </div>
          </div>
   <!-- Box 2 -->
      <div class="border border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
           <h3 class="text-lg font-semibold">Brand</h3>
            <p class="text-md leading-6">Brand consistency is crucial. Most customers (over 80%) emphasize the importance of companies going the extra mile to deliver a consistent experience.When shaping your website, you can demonstrate brand consistency by engaging a web design team well-versed in developing and adhering to branding guidelines. Active elements contributing to a consistent brand include:</p>
            <div class="space-y-4">
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Brand colors
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Typography
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Icons and graphics
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Brand voice
            </p>
            </div>
          </div>
        </div>
      </div>
    </section>
     <!-- Text box 2 section  -->
     <section class="pt-14 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto flex flex-col justify-center items-center">
          <div class="space-y-6 max-w-5xl w-full justify-center items-center text-center">
            <h2 class="xl:text-2xl text-xl font-semibold">Service-Centric</h2>
            <p class="text-md">
            Nearly 70% of consumers stress the need for a seamless user experience, indicating reduced revisits after subpar encounters on a website.Consequently, both your website design and content should meet customer expectations.Illustrations of being service-centric include:
            Ensuring that your page is titled as per the service you’re offering; it explicitly outlines your business offers thus retains visitors.
            Tailoring language and to your target audience; for instance, a business aiming at a Singaporean audience should use terms commonly used by locals (e.g., “lawyer” instead of “attorney” for a law firm).  
            </p>
          </div>
      </div>
    </section>
     <!-- Text box 3 section  -->
     <section class="pt-14 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto flex flex-col justify-center items-center">
          <div class="space-y-6 max-w-5xl w-full justify-center items-center text-center">
            <h2 class="xl:text-2xl text-xl font-semibold">Tailored for Online Marketing</h2>
            <p class="text-md">
            In addition to constructing a website, it’s vital to equip it for forthcoming marketing endeavors. A proficient web design team will factor this in, guaranteeing your website has crucial features for effective online marketing. Examples of online marketing-centric features:  
            </p>
            <div class="space-y-4">
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Seamless page creation using a Visual Builder for timely updates on promotions.
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Search Engine Optimization (SEO)
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Creation of landing pages for Social Media Advertising or Search Engine Marketing
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Pop-up banners for promotions or lead magnets
            </p>
            <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Countdown timers to evoke a sense of urgency
            </p> <p class="flex items-center text-sm space-x-3">
            <span class="text-red-500">✔</span> Integration of Open Graph tags for effective Social Media Management
            </p>
          </div>
          </div>
      </div>
    </section>
    <!-- Text box 4 section  -->
    <section class="pt-14 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto flex flex-col justify-center items-center">
          <div class="space-y-6 max-w-5xl w-full justify-center items-center text-center">
            <h2 class="xl:text-2xl text-xl font-semibold">Explore Our Web Design Services</h2>
            <p class="text-md">
            At Pixelizio, we provide all-encompassing web design services in Pakistan, dedicated to assisting businesses in crafting impressive and impactful websites that deliver tangible results. Our services include:  
            </p>
          </div>
      </div>
    </section>
     <!-- Why Pixelizio Section -->
     <section class="py-14">
      <div class="max-w-[1310px] container px-0 mx-auto text-left">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 ">
         <div class="border hover:bg-transparent bg-black border-border p-8 rounded-md text-white group">
           <h2 class="text-4xl font-semibold group-hover:text-white text-border mb-4">01</h2>
           <h3 class="font-semibold text-lg mb-2">Crafting Design Mockups and Wireframes</h3>
         </div>
         <div class="border hover:bg-transparent bg-black border-border p-8 rounded-md text-white group">
           <h2 class="text-4xl font-semibold group-hover:text-white text-border mb-4">02</h2>
           <h3 class="font-semibold text-lg mb-2">Developing Responsive Websites</h3>
         </div>
         <div class="border hover:bg-transparent bg-black border-border p-8 rounded-md text-white group">
           <h2 class="text-4xl font-semibold group-hover:text-white text-border mb-4">03</h2>
           <h3 class="font-semibold text-lg mb-2">Implementing SEO Copywriting for Websites</h3>
         </div>
         <div class="border hover:bg-transparent bg-black border-border p-8 rounded-md text-white group">
           <h2 class="text-4xl font-semibold group-hover:text-white text-border mb-4">04</h2>
           <h3 class="font-semibold text-lg mb-2">Optimizing Meta Titles and Descriptions</h3>
         </div>
         <div class="border hover:bg-transparent bg-black border-border p-8 rounded-md text-white group">
           <h2 class="text-4xl font-semibold group-hover:text-white text-border mb-4">05</h2>
           <h3 class="font-semibold text-lg mb-2">Incorporating Website Security Plugins</h3>
         </div>
         <div class="border hover:bg-transparent bg-black border-border p-8 rounded-md text-white group">
           <h2 class="text-4xl font-semibold group-hover:text-white text-border mb-4">06</h2>
           <h3 class="font-semibold text-lg mb-2">Conducting SEO Keyword Research</h3>
         </div>
      </div>
    </section>
    <!-- Call to Action Section -->
    <section class="pb-8">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Boost Your Brand with Our Web Design Expertise Today!</h2>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
        </a>
      </div>
    </section>
`;
export default wordpressWebsite;