// Types and interfaces
interface ServiceCard {
    icon: string
    title: string
    link: string
  }
  
  interface Feature {
    text: string
  }
  
  // Content
  const heroContent = {
    title: "Real Estate Just Got Real — Explore Solutions Built for the Modern Market!",
    description:
      "Navigating the real estate landscape can be complex, but with Pixelizio's real estate solutions, it doesn't have to be. Our innovative tech is designed to streamline property management, client relationships, and even closings—helping agents and brokers focus on what really matters: selling homes and growing your business.",
  }
  
  const serviceCards: ServiceCard[] = [
    {
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
        <circle cx="9" cy="7" r="4"></circle>
        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
      </svg>`,
      title: "CRM",
      link: "/contact",
    },
    {
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
        <polyline points="9 22 9 12 15 12 15 22"></polyline>
      </svg>`,
      title: "Property Management Solutions",
      link: "/contact",
    },
    {
      icon: `<svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path>
      </svg>`,
      title: "Branding",
      link: "/contact",
    },
  ]
  
  const features: Feature[] = [
    { text: "Intuitive tools for managing properties and clients" },
    { text: "Advanced analytics to guide smarter decisions" },
    { text: "Cloud-based solutions for access anywhere, anytime" },
  ]
  
  const RealEstateSolutions = `
  <div class="min-h-screen w-full text-white">
    <!-- Hero Section -->
    <section class="relative py-10 overflow-hidden w-full">
      <div class="w-full mx-auto relative z-10 px-4">
        <div class="max-w-3xl mx-auto text-center space-y-6">
          <h1 class="text-2xl md:text-4xl font-bold leading-tight bg-gradient-to-r from-white to-zinc-400 bg-clip-text text-transparent">
            ${heroContent.title}
          </h1>
          <p class="text-zinc-400 text-lg leading-relaxed">
            ${heroContent.description}
          </p>
          <a href="/contact">
            <button class="px-6 py-1.5 mt-6 border rounded-full text-white hover:bg-white hover:text-black transition-all">
              Get In Touch
            </button>
          </a>
        </div>
      </div>
    </section>

    <!-- Services Section -->
    <section class="relative py-10 w-full">
      <!-- Gradient circles -->
        ${serviceCards
          .map(
            (_, index) => `
          <div class="absolute xl:w-[400px] w-[100px] h-[100px] xl:h-[400px] bg-gradient-to-r from-red-500/10 to-blue-500/10 rounded-full blur-[100px]"
            style="left: ${index * 30}%; top: ${index * 15}%"></div>
        `,
          )
          .join("")}

      <div class="w-full mx-auto relative z-10 px-4">
        <div class="grid md:grid-cols-3 gap-8">
          ${serviceCards
            .map(
              (card, index) => `
            <a href="${card.link}" class="group">
              <div class="relative p-8 rounded-2xl backdrop-blur-xl bg-zinc-900/50 border border-zinc-800/50 
                         hover:bg-zinc-800/50 transition-all duration-500 hover:scale-105">
                <!-- Card gradient effect -->
              
                
                <!-- Content -->
                <div class="relative z-10">
                  <div class="text-red-500 mb-6 transform group-hover:scale-100 transition-transform duration-300">
                    ${card.icon}
                  </div>
                  <h3 class="text-xl font-semibold mb-4">${card.title}</h3>
                  <div class="flex items-center text-red-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span>Get In Touch</span>
                    <svg class="w-4 h-4 ml-2" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                    </svg>
                  </div>
                </div>
              </div>
            </a>
          `,
            )
            .join("")}
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="relative py-8 overflow-hidden w-full">
      <div class="absolute rounded-xl inset-0">
        <div class="absolute right-0 top-0 w-[600px] h-[600px] sm:w-[200px] sm:h-[800px] bg-gradient-to-bl from-red-500/10 to-transparent rounded-full blur-[120px]"></div>
      </div>

      <div class="w-full mx-auto relative z-10 px-4">
        <div class="max-w-3xl mx-auto">
          <h2 class="text-2xl md:text-3xl font-bold text-center mb-12">
            Here's How You Can Utilise Our Help and Make Your Real Estate Business Soar.
          </h2>
          <div class="space-y-6">
            ${features
              .map(
                (feature) => `
              <div class="flex items-center gap-4 p-6 rounded-xl backdrop-blur-xl bg-zinc-900/30 border border-zinc-800/50
                         hover:bg-zinc-800/50 transition-all duration-300 group">
                <div class="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center">
                  <svg class="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                  </svg>
                </div>
                <p class="text-lg text-zinc-300 group-hover:text-white transition-colors duration-300">${feature.text}</p>
              </div>
            `,
              )
              .join("")}
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="relative pt-8 w-full">
      <div class="w-full mx-auto xl:px-4 px-0">
        <div class="relative rounded-2xl overflow-hidden">
          <!-- Gradient background -->
          <div class="absolute inset-0 bg-gradient-to-br from-zinc-900 to-zinc-800"></div>
          <!-- Animated gradient circles -->
          <div class="absolute inset-0">
            <div class="absolute left-0 top-0 w-80 sm:w-96 h-80 sm:h-96 bg-red-500/20 rounded-full blur-[100px] animate-pulse"></div>
            <div class="absolute right-0 bottom-0 w-80 sm:w-96 h-80 sm:h-96 bg-blue-500/20 rounded-full blur-[100px] animate-pulse delay-1000"></div>
          </div>
          
          <div class="relative p-12 text-center">
            <h2 class="text-2xl md:text-3xl font-bold mb-6">Get a Free Consultation with Pixelizio</h2>
            <p class="text-zinc-400 mb-8 max-w-2xl mx-auto">
              Join the ranks of real estate pros who trust Pixelizio for seamless, innovative, and powerful real estate solutions.
            </p>
            <a href="/contact">
             <button class="px-6 py-1.5 border rounded-full text-white hover:bg-white hover:text-black transition-all">
              Contact Us
             </button>
             </a>
          </div>
        </div>
      </div>
    </section>
  </div>
`

export default RealEstateSolutions


  
  