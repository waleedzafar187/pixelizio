// Social Media Ads
const socialMediaAds = ` 
 <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h1 class="xl:text-4xl text-3xl font-bold">Dominate Social Media with Ads That Resonate</h1>
            <p class="text-md">
              Step into the realm of unlimited possibilities with Social Media Ads. Elevate your brand on platforms like Instagram, Snapchat, Twitter, and LinkedIn, forging connections that matter.
            </p> 
            <h3 class="text-xl">Here's the real deal – Social Media Ads aren't just a trend; they're a proven force.</h3>
            <p class="text-md">
              Experience a remarkable 40% surge in engagement, propelling your brand into the limelight on Instagram, Snapchat, Twitter, and LinkedIn.
            </p> 
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get In Touch
            </a> <span><FaAngleDoubleRight /></span></Button>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/social Media Ads.webp" alt="CRM Solutions" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
  
    <!-- Advantage Section -->
    <section class="xl:py-16 py-8 px-0 container flex flex-col items-center justify-center">
    <div class="lg:w-full xl:max-w-[800px] flex flex-col items-start justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-3xl text-2xl font-bold mb-4">Transform Your Brand’s Story with Strategic Ads”</h2>
            <h3 class="text-xl font-bold mb-4">Precision Unleashed: Targeted Advertising, Perfected</h3>
            <p class="text-md mb-6">Say goodbye to generic outreach. Our Social Media Ads strategies ensure your message hits the bullseye. Leverage in-depth user insights for laser-focused targeting, turning casual scrollers into devoted brand enthusiasts.</p>          
            <!-- {/* icon box below */} -->
            <div class="flex flex-col xl:gap-8 gap-6">
              <!-- {/* box 1 */} -->
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-lg font-semibold mb-2">Unmatched Targeting Precision</h3>
                  <p class="text-sm">Detailed user data ensures precise ad targeting based on demographics, interests, and behavior, boosting engagement.</p>
                </div>
              </div>
               <!-- {/* box 2 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Mobile Optimization</h3>
                  <p class="text-md">Social Media Ads are inherently mobile-friendly, ensuring seamless brand reach across various devices.</p>
                </div>
              </div>
              <!-- {/* box 3 */} -->
              <div class="flex items-start  border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Enhanced Brand Visibility</h3>
                  <p class="text-md">Social media is where people spend significant online time, increasing brand visibility and recall.</p>
                </div>
              </div>
            </div>
    </section>
  
    <!-- Why Pixelizio Section -->
    <section class="pb-16">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="grid md:grid-cols-3 gap-8">
          <!-- Box 1 -->
          <div class="border bg-black hover:bg-transparent border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Impact</h3>
            <p class="text-md leading-6">Social media platforms connect billions globally, offering unparalleled reach for impactful local engagement.</p>
          </div>
          <!-- Box 2 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
           <h3 class="text-lg font-semibold">Cost-Effective Advertising</h3>
            <p class="text-md leading-6">Fact: Social Media Ads offer cost-effective solutions, enabling impactful campaigns for businesses of all sizes.</p>
          </div>
          <!-- Box 3 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Real-Time Analytics and Insights</h3>
            <p class="text-md leading-6">Robust analytics tools provide real-time insights, allowing for on-the-fly optimization of campaigns.</p>
          </div>
           <!-- Box 4 -->
           <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Interactive and Engaging Content</h3>
            <p class="text-md leading-6">Diverse ad formats, including videos and polls, create engaging content that captures attention and encourages sharing.</p>
            </div>
              <!-- Box 5 -->
            <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Community Building and Customer Loyalty</h3>
            <p class="text-md leading-6">Social media fosters community engagement, building brand loyalty through direct interactions and social groups.</p>
            </div>
              <!-- Box 6 -->
            <div class="border bg-black hover:bg-transparent border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Continuous Innovation and Features</h3>
            <p class="text-md leading-6">Social media platforms continually introduce new ad features, providing marketers with opportunities for innovation and staying ahead.</p>
            </div>
              <!-- Box 7 without bg -->
            <div class="xl:p-10 p-6 rounded-md flex flex-col justify-center items-center text-center gap-4">
            <h3 class="text-lg font-semibold">Masters of Social Media Ads: Trust in Expertise</h3>
            <p class="text-md leading-6">At Pixelizio, we’re not just practitioners; we’re masters of the art and science of Social Media Ads. Stay ahead of trends and algorithms, ensuring your brand shines on Instagram, Snapchat, Twitter, and LinkedIn.</p>
            </div>
              <!-- Box 8 without bg -->
            <div class="xl:p-10 p-6 rounded-md flex flex-col justify-center items-center text-center gap-4">
            <h3 class="text-lg font-semibold">Customized Solutions, Real Outcomes</h3>
            <p class="text-md leading-6">One size doesn’t fit all. Collaborate with us to craft Social Media Ads campaigns tailored to your brand. Whether it’s boosting your LinkedIn presence, creating Instagram-worthy content, or capturing the fleeting attention on Snapchat – we’ve got the recipe for success.</p>
            </div>
              <!-- Box 9 without bg -->
            <div class="xl:p-12 p-6 rounded-md flex flex-col justify-center items-center text-center gap-4">
            <h3 class="text-lg font-semibold">Beyond Ads: Holistic Digital Brilliance</h3>
            <p class="text-md leading-6">While Social Media Ads are our forte, our services extend beyond. Explore a complete suite of digital marketing solutions, from SEO optimization to website development, ensuring your brand’s digital journey is comprehensive and impactful.</p>
            </div>
        </div>
      </div>
    </section>
  
    <!-- Call to Action Section -->
    <section class="pb-10">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Pixelizio – Where Social Media Ads Transform Potential into Power</h2>
        <p class="text-md mb-8">Ready to dominate on Instagram, Snapchat, Twitter, and LinkedIn? Contact us now, and let’s sculpt Social Media Ads that captivate, resonate, and convert.</p>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
        </a>
      </div>
    </section>
`;
export default socialMediaAds;