// application Services

const applicationServices =  `
      <div class="max-w-[1310px] mx-auto flex flex-col justify-center items-center">
    <section class="xl:py-8 pt-8 xl:px-6 px-0 container text-center xl:max-w-3xl flex flex-col justify-center items-center">
      <div class="flex items-end mb-2 space-x-2 text-primary">
        <!-- {/* SVG icon*/} -->
        <svg xmlnsXlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4.15 1.83" class="w-24 h-10 fill-current">
        <path d="M0.1,0.57C0.25,0.5,0.39,0.4,0.54,0.32C0.69,0.25,0.85,0.2,1.01,0.19c0.3-0.02,0.57,0.11,0.69,0.39 c0.12,0.27,0.14,0.57,0.39,0.76c0.22,0.17,0.5,0.21,0.77,0.22c0.16,0,0.33-0.01,0.49-0.03C3.43,1.51,3.52,1.5,3.61,1.48 c0.08-0.01,0.17-0.02,0.24-0.06c0.04-0.02,0.02-0.07-0.02-0.07C3.75,1.34,3.68,1.37,3.61,1.38C3.53,1.4,3.46,1.42,3.38,1.43 C3.23,1.46,3.07,1.47,2.91,1.47c-0.29,0-0.63-0.04-0.84-0.26c-0.23-0.23-0.2-0.59-0.39-0.84C1.52,0.18,1.26,0.1,1.01,0.11 C0.85,0.12,0.69,0.17,0.54,0.24c-0.16,0.08-0.34,0.17-0.47,0.3C0.06,0.55,0.08,0.58,0.1,0.57L0.1,0.57z"></path>
        <polygon points="4.06,1.39 3.81,1.24 3.55,1.09 3.78,1.41 3.61,1.76 3.84,1.57"></polygon>
        </svg>
        <!-- {/* Text */} -->
        <span>Application Services</span>
      </div>
    <h1 class="xl:text-4xl text-2xl font-bold mb-6 mt-2 text-white leading-normal">Application Services that Matter</h1>
    <p class="text-md text-gray-300 mb-4  mx-auto">From conceptualization to deployment and beyond, our range of application services covers every stage of the application lifecycle, ensuring that your applications are robust, reliable, and aligned with your business goals.</p>
  </section>

  <!-- ERP Services Section -->
  <section class="py-4 xl:px-6 px-0">
    <div class="max-w-3xl mx-auto flex flex-col gap-3 items-center justify-center">
          <h2 class="xl:text-2xl text-xl font-semibold mb-6 text-center">Unlocking Value Through Innovation: Driving Business Agility and Growth</h2>
          <p class="text-md text-gray-300 text-center">We empower organizations to embrace innovation and drive business agility through our cutting-edge application services. Whether you’re looking to modernize legacy systems, optimize existing applications, or develop new solutions from scratch, we have the expertise and capabilities to bring your vision to life.</p>
          <button class="bg-transparent  text-white flex gap-2 hover:bg-white hover:text-black py-2 mt-3 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">Get In Touch</a>
          </button>
    </div>
  </section>
  <section class="py-4 xl:px-6 px-0">
    <div class="max-w-3xl mx-auto flex flex-col gap-3 items-center justify-center">
          <h2 class="xl:text-2xl text-xl font-semibold mb-2 text-center">Comprehensive Suite of Application Services: From Development to Optimization</h2>
          <p class="text-md text-gray-300 text-center">Pixelizio offers a comprehensive suite of best application services to address all your needs.</p>
    </div>
  </section>

  <!-- Features Section -->
  <section class="xl:py-8 py-2 px-0">
    <div class="mx-auto  grid md:grid-cols-2 lg:grid-cols-3 gap-8">
      <div class="border border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-4 text-xl text-center">Application Development</h3>
        <p class="text-md text-gray-300 text-center">We specialize in developing custom solutions tailored to your unique requirements, from mobile apps to web applications.</p>
      </div>
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg text-center">Application Modernization</h3>
        <p class="text-md text-gray-300 text-center">We help organizations modernize legacy systems and migrate to modern platforms to unlock new opportunities for innovation and growth.</p>
      </div>
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-lg text-center">Application Management</h3>
        <p class="text-md text-gray-300 text-center">Our application management services ensure that your applications remain secure, reliable, and up-to-date, allowing you to focus on your core business activities.</p>
      </div>
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-xl text-center">Application Testing</h3>
        <p class="text-md text-gray-300 text-center">We provide comprehensive testing services to ensure the quality and reliability of your applications, including functional testing, performance testing, and security testing.</p>
      </div>
      <div class="border border-border hover:border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-xl text-center">Application Integration</h3>
        <p class="text-md text-gray-300 text-center">Our integration services enable seamless connectivity between your applications and systems, allowing for streamlined workflows and enhanced productivity.</p>
      </div>
      <div class="border border-primary p-6 rounded-lg">
        <h3 class="font-semibold mb-2 text-xl text-center ">Application Support</h3>
        <p class="text-md text-gray-300 text-center">Our dedicated support team is available around the clock to provide assistance and resolve any issues that may arise, ensuring the smooth operation of your applications.</p>
      </div>
      
    </div>
  </section>

  <!-- Why Choose Pixelizio Section -->
  <section class="xl:py-6 py-8 px-0 container flex flex-col items-center justify-center">
    <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-2xl text-xl font-bold  mb-4">Why Choose Us</h2>
            <p class="text-md text-center mb-12 text-gray-300">Applications drive customer engagement, operational efficiency, and overall growth. Here’s why our comprehensive app services are essential for your business:
            </p>
            <!-- {/* icon box below */} -->
            <div class="flex flex-col xl:gap-12 gap-6">
              <!-- {/* box 1 */} -->
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Elevated Customer Experience</h3>
                  <p class="text-md text-gray-300">Exceptional user experiences are at the core of successful applications. Our app services ensure that your applications are functional and intuitive, user-friendly, and capable of delivering seamless interactions that keep your customers coming back for more.</p>
                </div>
              </div>
               <!-- {/* box 2 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Agility in Action</h3>
                  <p class="text-md text-gray-300">In a rapidly evolving marketplace, agility is key to staying ahead of the competition. Our app services empower your business to adapt quickly to changing market dynamics, scale operations efficiently, and respond to customer needs with agility and precision.</p>
                </div>
              </div>
              <!-- {/* box 3 */} -->
              <div class="flex items-start  border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Optimized Performance, Always</h3>
                  <p class="text-md text-gray-300">Your applications must perform at their peak to meet user expectations. With our app services, you can rest assured that your applications undergo rigorous performance testing, optimization, and monitoring to deliver exceptional performance, even under the most demanding conditions.</p>
                </div>
              </div>
              <!-- {/* box 4 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Fortified Security and Compliance</h3>
                  <p class="text-md text-gray-300">Protecting your sensitive data and ensuring compliance with industry regulations are non-negotiable. Our app services include robust security measures and compliance protocols to safeguard your data, mitigate risks, and maintain customers trust.</p>
                </div>
              </div>
              <!-- {/* box 5 */} -->
              <div class="flex items-start">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Cost-Effective Solutions</h3>
                  <p class="text-md text-gray-300">Our app services are designed to optimize costs, streamline operations, and deliver tangible value, ensuring you get the most out of your application development and management investment.</p>
                </div>
              </div>
              <!-- {/* box 6 */} -->
              <div class="flex items-start">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Focus on What Matters</h3>
                  <p class="text-md text-gray-300">By entrusting your application needs to us, you can redirect your internal resources toward strategic initiatives and core business activities. Let us handle the technical complexities while you focus on driving innovation, growth, and success for your organization.</p>
                </div>
              </div>
               <!-- {/* box 7 */} -->
               <div class="flex items-start">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Scalability for Future Growth</h3>
                  <p class="text-md text-gray-300">As your business evolves, your application needs will evolve, too. Our scalable app services are designed to grow with your business, providing flexible solutions that adapt to your changing requirements and support your long-term growth objectives.</p>
                </div>
              </div>
               <!-- {/* box 8 */} -->
               <div class="flex items-start">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Gain a Competitive Edge</h3>
                  <p class="text-md text-gray-300">Our app services help you differentiate your brand, attract and retain customers, and gain a competitive edge by delivering exceptional digital experiences that set you apart.</p>
                </div>
              </div>
    </section>
  <!-- Call to Action Section -->
  <section class="xl:py-8 py-4 xl:px-6 px-0 text-center">
    <div class="max-w-xl mx-auto">
      <h2 class="xl:text-3xl text-2xl font-semibold mb-4">Ready to Elevate Your Applications?</h2>
      <p class="text-md text-gray-300 mb-8">
      Contact us today to learn more about our application services and how we can help you unlock the full potential of your applications.  
      </p>
      <div class="flex xl:flex-row flex-col justify-center items-center gap-10">
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-1 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Us Today
        </a>
      </div>
    </div>
  </section>
  </div>
    `;
  
  export default applicationServices;
  