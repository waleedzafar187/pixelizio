// Bing Ads
const bingAds = ` 
<div class="max-w-[1310px] mx-auto flex flex-col justify-center items-center">
    <section class="xl:py-8 pt-8 xl:px-6 px-0 container text-center xl:max-w-3xl flex flex-col justify-center items-center">
    <h1 class="xl:text-4xl text-2xl font-bold mb-2 text-white leading-normal">Boost Your Brand with Bing Ads: Pixelizio's Power-Packed Solution</h1>
    </section>
    <!-- text section -->
    <section class="xl:py-8 pt-8 container max-w-[1310px] text-left flex xl:flex-row flex-col xl:gap-20 gap-4 justify-center items-start">
      <div>
      <h2 class="xl:text-2xl text-xl font-semibold mb-6 mt-2 text-white leading-normal">Why Bing Ads?</h2>
        <p class="text-md text-gray-300 mb-6 mx-auto">
         Tap into a massive audience beyond Google. Bing Ads at Pixelizio is your secret weapon to reach millions of potential customers.
        </p>
        <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get In Touch
            </a> <span><FaAngleDoubleRight /></span></Button>
        </button>
      </div>
      <div>
      <h2 class="xl:text-2xl text-xl font-semibold mb-6 mt-2 text-white leading-normal">Strategic Campaigns, Real Results</h2>
        <p class="text-md text-gray-300 mb-4  mx-auto">
         Customized Bing Ads campaigns, meticulously planned for YOUR business. Optimize ad placements and identify the perfect keywords – we ensure your brand stands out.
        </p>
      </div>
    </section>
  <!-- 2nd Services Section -->
  <section class="py-8 xl:px-6 px-0">
    <div class="max-w-3xl mx-auto">
      <div class="space-y-6">
        <div>
          <h3 class="text-xl font-semibold mb-2">Precision Targeting</h3>
          <p class="text-md text-gray-300">Get your message to the right audience. Pixelizio leverages advanced targeting strategies for maximum impact and engagement.</p>
        </div>
        <div>
          <h3 class="text-xl font-semibold mb-2">Data-Driven Optimization</h3>
          <p class="text-md text-gray-300">No guesswork here. We monitor, analyze, and optimize in real time, ensuring every dollar spent brings value.</p>
        </div>
      </div>
    </div>
  </section>
   <!-- Why choose Pixelizio Section -->
   <section class="pb-8">
      <div class="container max-w-[1310px] mx-auto px-0">
      <h2 class="xl:text-3xl text-xl font-semibold mb-6 mt-2 text-white leading-normal">Why Bing Ads?</h2>
        <div class="grid md:grid-cols-3 gap-8">
          <!-- Box 1 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Expertise That Delivers</h3>
            <p class="text-md leading-6">Our seasoned professionals bring years of experience to the table. Stay ahead of the curve with Pixelizio’s Bing Ads mastery.</p>
          </div>
          <!-- Box 2 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
           <h3 class="text-lg font-semibold">Your Success, Our Priority</h3>
            <p class="text-md leading-6">Collaboration is key. We work closely with you to understand your brand, goals, and challenges. Your success is our mission.</p>
          </div>
          <!-- Box 3 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">All-Inclusive Digital Solutions</h3>
            <p class="text-md leading-6">Bing Ads is just the beginning. Pixelizio offers a full suite of services – SEO, website development, social media management, and more – for a complete digital marketing strategy.</p>
          </div>
        </div>
      </div>
    </section>
  <!-- Call to Action Section -->
  <section class="xl:py-8 py-4 xl:px-6 px-0 text-center">
    <div class="max-w-3xl mx-auto">
      <h2 class="xl:text-3xl text-2xl font-semibold mb-4">Ready to Skyrocket Your Brand with Bing Ads?</h2>
      <p class="text-md text-gray-300 mb-8">
       Don’t miss out – contact us now, and let’s turn clicks into customers! 
      </p>
      <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today  
      </a>
    </div>
  </section></div> 
`;
export default bingAds;