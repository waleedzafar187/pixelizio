// Social Media Management
const socialMediaManagement = ` 
 <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full">
            <h1 class="xl:text-4xl text-3xl font-bold">Pixelizio– Your Social Media Management Maestro!</h1>
            <h3 class="xl:text-2xl text-xl font-bold">Why Social Media Management Matters?</h3>
            <p class="text-md">
              In the digital age, your brand’s online presence is synonymous with its success. Pixelizio understands social media’s pivotal role in shaping perceptions, building communities, and driving conversions. Our Social Media Management services are about posting content and sculpting a digital narrative that resonates with your audience.
            </p> 
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get In Touch
            </a> <span><FaAngleDoubleRight /></span></Button>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/socialMediaBrandManagement.webp" alt="CRM Solutions" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
  
    <!-- Advantage Section -->
    <section class="xl:py-16 py-8 px-0 container flex flex-col items-center justify-center">
    <div class="lg:w-full xl:max-w-[800px] flex flex-col items-start justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-2xl text-xl font-bold mb-4">“Businesses that actively manage their social media presence experience, on average, a 25% increase in brand visibility and customer engagement.”
            </h2>
            <p class="text-md mb-6">Say goodbye to generic outreach. Our Social Media Ads strategies ensure your message hits the bullseye. Leverage in-depth user insights for laser-focused targeting, turning casual scrollers into devoted brand enthusiasts.</p>
            <h2 class="xl:text-2xl text-xl font-bold mb-10">Precision Unleashed: Targeted Advertising, Perfected
            </h2>          
            <!-- {/* icon box below */} -->
            <div class="flex flex-col xl:gap-8 gap-6">
              <!-- {/* box 1 */} -->
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-lg font-semibold mb-2">Unmatched Targeting Precision</h3>
                  <p class="text-sm">Detailed user data ensures precise ad targeting based on demographics, interests, and behavior, boosting engagement.</p>
                </div>
              </div>
               <!-- {/* box 2 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Mobile Optimization</h3>
                  <p class="text-md">Social Media Ads are inherently mobile-friendly, ensuring seamless brand reach across various devices.</p>
                </div>
              </div>
              <!-- {/* box 3 */} -->
              <div class="flex items-start  border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Enhanced Brand Visibility</h3>
                  <p class="text-md">Social media is where people spend significant online time, increasing brand visibility and recall.</p>
                </div>
              </div>
            </div>
    </section>
  
    <!-- Why Pixelizio Section -->
    <section class="pb-16">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="grid md:grid-cols-3 gap-8">
          <!-- Box 1 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Strategic Content Calendar</h3>
            <p class="text-md leading-6">We don't just post; we plan. Our strategic content calendar ensures a consistent and cohesive brand presence, maximizing platform engagement.</p>
          </div>
          <!-- Box 2 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
           <h3 class="text-lg font-semibold">Audience Engagement Mastery</h3>
            <p class="text-md leading-6">Engaging with your audience is our forte. We promptly respond to comments, messages, and interactions, fostering a vibrant community around your brand.</p>
          </div>
          <!-- Box 3 -->
          <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Customized Strategies for Your Brand</h3>
            <p class="text-md leading-6">One size doesn’t fit all. Collaborate with us to tailor Social Media Management strategies that align with your brand's voice, values, and objectives.</p>
          </div>
           <!-- Box 4 -->
           <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Experienced Social Media Navigators</h3>
            <p class="text-md leading-6">Our team consists of seasoned professionals well-versed in the nuances of social media platforms. We navigate trends, algorithms, and user behavior to keep your brand ahead of the curve.</p>
            </div>
              <!-- Box 5 -->
            <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Data-Driven Decision Making</h3>
            <p class="text-md leading-6">Numbers tell a story. Our Social Media Management approach is grounded in data analytics, allowing us to make informed decisions and optimize your social strategy for tangible results.</p>
            </div>
              <!-- Box 6 -->
            <div class="border hover:bg-black border-border p-6 rounded-md flex flex-col gap-4 transition-transform transform hover:-translate-y-2">
            <div class="h-6 w-6 border border-primary border-e-2 rounded-full">
              <div class="w-4 h-4 bg-primary rounded-full"></div>
            </div>
            <h3 class="text-lg font-semibold">Comprehensive Digital Brilliance</h3>
            <p class="text-md leading-6">Beyond management, we offer a suite of digital marketing solutions – from SEO optimization to paid campaigns – ensuring your brand's digital journey is holistic and impactful.</p>
            </div>
        </div>
      </div>
    </section>
  
    <!-- Call to Action Section -->
    <section class=" pb-10">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Ready to Transform Your Social Media Narrative?</h2>
        <p class="text-md mb-8">Contact us now, and let’s craft a social strategy that captivates, engages, and converts.</p>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
        </a>
      </div>
    </section>
`;
export default socialMediaManagement;