// Types
interface Feature {
    title: string
    description: string
  }
  
  // Content
  const heroContent = {
    title: "Your Vision, Our Custom Code—Tailored Apps for Your Business.",
    description:
      "Looking for an app that does exactly what your business needs? At Pixelizio, we don't believe in cookie-cutter solutions. Our area of expertise is custom application development that vividly captures your vision.",
    subDescription:
      "Whether your company is big or a startup, our staff of developers will create a customized application that fits your operations, increasing production and promoting expansion.",
  }
  
  const features: Feature[] = [
    {
      title: "Boost Your Business and Discover it's Hidden Potential:",
      description:
        "Allow us to create an app tailored to your company like a glove. Our bespoke apps are made to be scalable, safe, and future-proof so your company can grow without missing a beat.",
    },
  ]
  
  const benefits = [
    "Tailored solutions built to your specifications",
    "Smooth integration with existing systems",
    "Ongoing support and updates to keep your app at peak performance",
  ]
  
  const CustomApplications = `
  <div class="min-h-screen text-white">
    <!-- Hero Section -->
    <section class="relative py-4 overflow-hidden">
      <div class="container max-w-[1310px] mx-auto px-0 relative z-10">
        <div class="grid lg:grid-cols-2 gap-8 items-center"> 
          <div class="space-y-6">
            <h1 class="text-2xl sm:text-3xl lg:text-4xl font-bold leading-tight bg-gradient-to-r from-white to-zinc-400 bg-clip-text text-transparent">
              ${heroContent.title}
            </h1>
            <div class="space-y-4">
              <p class="text-zinc-400">${heroContent.description}</p>
              <p class="text-zinc-400">${heroContent.subDescription}</p>
            </div>
            <a href="/contact">
              <button class="px-6 mt-6 py-1.5 border rounded-full text-white hover:bg-white hover:text-black transition-all duration-300">
                Get In Touch
              </button> 
            </a>
          </div>
          <div class="relative">
            <div class="absolute inset-0 bg-gradient-to-r from-red-500/10 to-transparent rounded-lg"></div>
            <img 
              src="/assets/servicesDetail/customappdev.jpg"
              alt="Custom Application Development" 
              class="rounded-lg w-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="relative py-4">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="grid lg:grid-cols-2 gap-6 items-center"> 
          <div class="space-y-6 xl:border-r border-border xl:pr-8">
            <h2 class="text-xl sm:text-2xl lg:text-3xl font-bold">
              Why Settle For Off-The-Shelf When You Can Have Something Built Just for You?
            </h2>
            <p class="text-zinc-400">${features[0].description}</p>
          </div>
          <div class="space-y-6">
            <div class="flex items-center gap-4 text-primary mb-4">
              <div class="xl:w-12 w-20 h-12 rounded-full bg-red-500/10 flex items-center justify-center">
                <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                </svg>
              </div>
              <h3 class="text-lg sm:text-xl font-semibold">${features[0].title}</h3>
            </div>
            <div class="space-y-4">
              ${benefits
                .map(
                  (benefit) => `
                <div class="flex items-center gap-4 p-4 rounded-lg bg-zinc-900/50 backdrop-blur-sm hover:bg-zinc-800/50 transition-all duration-300">
                  <svg class="w-5 h-5 text-primary flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                  </svg>
                  <span class="text-zinc-300">${benefit}</span>
                </div>
              `,
                )
                .join("")}
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="relative py-4">
      <div class="container max-w-[1310px] mx-auto px-0">
        <div class="relative rounded-2xl overflow-hidden bg-[#002147] p-10"> 
          <div class="absolute inset-0 bg-gradient-to-br from-blue-900/50 to-transparent"></div>
          <div class="relative z-10 text-center space-y-6">
            <h2 class="text-2xl xl:text-3xl font-bold">Ready to Make Your App Idea a Reality?</h2>
            <p class="text-zinc-300 max-w-2xl mx-auto">
              Let's talk and turn your vision into a custom application today! Contact Now.
            </p>
            <a href="/contact">
              <button class="px-6 mt-6 py-1.5 mx-auto rounded-full hover:bg-white border hover:text-black transition-all duration-300">
                Get a Free Consultation
              </button>
            </a>
          </div>
        </div>
      </div>
    </section>
  </div>
`

export default CustomApplications

  
  