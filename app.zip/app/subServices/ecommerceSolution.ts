// Declare necessary variables and types
interface CommerceFeature {
    text: string
  }
  
  interface CommercePlatform {
    title: string
    description: string
    features: CommerceFeature[]
  }
  
  const heroContent = {
    title: "Ecommerce Solutions That Fit Your Brand",
    description:
      "Your web store represents more than just a website; it's what drives your company. Like your company, our e-commerce offerings are distinctive. Whether you are just starting or expanding your company, we would be happy to assist you in designing and running an online store that transforms visitors into devoted consumers.",
  }
  
  const whyPixelizio = {
    title: "Why Pixelizio?",
    description:
      "We know that there is no one-size-fits-all approach to e-commerce success. Thus, our special e-commerce solutions are designed to meet your needs, ensuring your store distinguishes itself in a crowded market.",
  }
  
  const platforms: CommercePlatform[] = [
    {
      title: "Shopify Solutions",
      description:
        "If you're looking for a simple, highly flexible platform with great management capacity, Shopify is the answer. We will walk you through every phase from organizing your store to including outside apps.",
      features: [
        { text: "Custom design and development tailored to your brand" },
        { text: "Full integration of Shopify Apps to enhance functionality" },
        { text: "Optimized SEO to improve search rankings and visibility" },
        { text: "Seamless payment gateways and secure checkout" },
      ],
    },
    {
      title: "WooCommerce Expertise",
      description:
        "Looking for more control and customization? WooCommerce provides strong e-commerce features combined with PHP's adaptability. Whether your goal is to convert your present WooCommerce store or start from nothing, we will handle everything — from site optimization to sales-driving WooCommerce plugin integration.",
      features: [
        { text: "Custom WordPress themes built specifically for WooCommerce" },
        { text: "Integration of essential WooCommerce plugins for advanced features" },
        { text: "Product page customization to showcase your inventory" },
        { text: "Streamlined checkout processes to increase conversions" },
      ],
    },
  ]
  
  const buildBusiness = {
    title: "We don't just build stores—we build businesses.",
    description:
      "Our staff offers continuous support to enable you to flourish and fit the fast-paced e-commerce environment. Want a fresh feature? We are right now. Looking to run a campaign? We have the means to assist in your marketing of it. No matter the platform, our end-to-end e-commerce solutions will provide everything you need to attract, interact with, and convert your audience.",
  }
  
  const ctaSection = {
    title: "Let's Elevate Your E-commerce Business",
    description:
      "Whether you choose Shopify or WooCommerce, our e-commerce solutions are designed to deliver results. Contact Pixelizio to let us create a digital shopping experience your consumers will enjoy.",
  }
  
  const EcommerceSolutions = `
    <!-- Hero Section -->
    <section class="w-full text-white">
      <div class="container max-w-[1310px] mx-auto xl:px-4 px-2 py-8">
        <div class="grid lg:grid-cols-2 gap-12 items-center">
          <div class="space-y-6">
            <h1 class="xl:text-4xl text-3xl font-bold leading-tight">${heroContent.title}</h1>
            <p class="text-zinc-400 leading-relaxed">${heroContent.description}</p>
            <a href="/contact">
            <button class="px-6 py-1.5 mt-8 border rounded-full text-white hover:bg-white hover:text-black transition-all">
              Get In Touch
            </button>
            </a>
          </div>
          <div class="relative">
            <img 
              src="/assets/servicesDetail/ecommercesolution.jpg"
              alt="Ecommerce Solutions" 
              class="rounded-lg w-full object-cover"
            />
            <div class="absolute inset-0 bg-gradient-to-r from-red-500/10 to-transparent rounded-lg"></div>
          </div>
        </div>
      </div>
    </section>
  
    <!-- Why Pixelizio Section -->
    <section class="py-8">
      <div class="container max-w-[1310px] mx-auto xl:px-4 px-2 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold text-white mb-6">${whyPixelizio.title}</h2>
        <p class="text-zinc-400 max-w-3xl mx-auto">${whyPixelizio.description}</p>
      </div>
    </section>
  
    <!-- Platforms Section -->
    <section class="py-8">
      <div class="container max-w-[1310px] mx-auto xl:px-4 px-2">
        <div class="grid md:grid-cols-2 gap-8">
          ${platforms
            .map(
              (platform) => `
            <div class="bg-zinc-900/50  backdrop-blur-sm border border-zinc-800/50 rounded-lg p-8 hover:border-red-500/30 transition-all duration-300">
              <h3 class="text-2xl font-bold text-white mb-4">${platform.title}</h3>
              <p class="text-zinc-400 mb-6 leading-relaxed">${platform.description}</p>
              ${
                platform.title.includes("Shopify")
                  ? '<h4 class="text-white mb-4">What we offer with Shopify:</h4>'
                  : '<h4 class="text-white mb-4">Our WooCommerce services include:</h4>'
              }
              <ul class="space-y-3">
                ${platform.features
                  .map(
                    (feature) => `
                  <li class="flex items-start gap-2 text-zinc-400">
                    <span class="text-red-500 mt-1">
                      <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                    </span>
                    ${feature.text}
                  </li>
                `,
                  )
                  .join("")}
              </ul>
              ${
                platform.title.includes("Shopify")
                  ? '<p class="mt-6 text-zinc-400">Our goal is to build you a Shopify store that doesn\'t just look great but also performs flawlessly.</p>'
                  : "<p class=\"mt-6 text-zinc-400\">With WooCommerce, the sky's the limit. And we're here to make sure your store reaches it.</p>"
              }
            </div>
          `,
            )
            .join("")}
        </div>
      </div>
    </section>
  
    <!-- Build Business Section -->
    <section class="py-8">
      <div class="container max-w-[1310px] mx-auto xl:px-4 px-2 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold text-white mb-6">${buildBusiness.title}</h2>
        <p class="text-zinc-400 max-w-3xl mx-auto leading-relaxed">${buildBusiness.description}</p>
      </div>
    </section>
  
    <!-- CTA Section -->
    <section class= "py-8">
      <div class="container max-w-[1310px] mx-auto xl:px-4 px-2">
        <div class="bg-zinc-800/50 backdrop-blur-sm border border-zinc-700/50 rounded-2xl xl:p-12 p-8 text-center">
          <h2 class="xl:text-3xl text-2xl font-bold text-white mb-4">${ctaSection.title}</h2>
          <p class="text-zinc-400 mb-6 max-w-2xl mx-auto">${ctaSection.description}</p>
          <a href="/contact">
            <button class="px-6 py-1.5 border rounded-full text-white hover:bg-white hover:text-black transition-all">
              Get In Touch
            </button>
          </a>
        </div>
      </div>
    </section>
  `
  
  export default EcommerceSolutions
  
  