// softwareDevelopment.ts

const mobileAppDevelopment =  `
      <!-- Hero Section -->
    <section class="py-6 w-full">
      <div class="container max-w-[1310px] px-0 mx-auto">
        <div class="grid lg:grid-cols-2 xl:gap-16 gap-8">
          <div class="space-y-6 xl:w-[90%] w-full flex flex-col justify-center items-start">
            <h1 class="xl:text-4xl text-3xl font-bold">Turn Your Mobile App Ideas into Reality</h1>
            <p class="text-md">With our expertise and dedication, we help businesses of all sizes create engaging and intuitive mobile experiences that drive user engagement and business growth.
            </p>
            <button class="bg-transparent text-white flex gap-2 hover:bg-white hover:text-black py-2 px-5 border border-1 rounded-full text-base font-medium">
            <a href="/contact">
            Get A Quote
            </a> <span><FaAngleDoubleRight /></span></Button>
            </button>
          </div>
          <div>
            <Image src="/assets/servicesdetail/mobile app development.webp" alt="CRM Solutions" class="rounded-lg w-full xl:h-[400px] h-[300px] object-cover">
          </div>
        </div>
      </div>
    </section>
  
    <!-- CRM Advantage Section -->
    <section class="xl:py-6 py-8 px-0 container flex flex-col items-center justify-center">
    <div class="lg:w-full xl:max-w-[800px] flex flex-col items-center justify-center pl-0 lg:pl-12 lg:pr-3">
            <h2 class="xl:text-2xl text-xl font-bold  mb-4">Tailored Mobile Solutions: From Concept to Launch</h2>
            <p class="text-md text-center mb-12 text-gray-300">Every app is unique, so we offer tailored mobile app development services to meet your specific needs. From concept to launch, our team works closely with you to ensure that your app reflects your vision and delivers exceptional value to your users.
            </p>
            <!-- {/* icon box below */} -->
            <div class="flex flex-col xl:gap-12 gap-6">
              <!-- {/* box 1 */} -->
              <div class="flex items-start border-b pb-4 border-border">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Expertise Across Platforms: iOS, Android, and More</h3>
                  <p class="text-md text-gray-300">Whether you're targeting the iOS or Android platform or both, our team of experienced developers has the expertise to bring your app to life on any platform. We stay up-to-date with the latest technologies and trends to ensure your app stands out in the crowded app marketplace.</p>
                </div>
              </div>
               <!-- {/* box 2 */} -->
              <div class="flex items-start border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">User-Centric Design: Creating Seamless Experiences</h3>
                  <p class="text-md text-gray-300">User experience is at the heart of everything we do. Our designers work tirelessly to create intuitive and visually stunning interfaces that keep users engaged and returning for more. From sleek designs to seamless navigation, we ensure that every aspect of your app delights users.</p>
                </div>
              </div>
              <!-- {/* box 3 */} -->
              <div class="flex items-start  border-b pb-4 border-border">
              <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-primary mr-8 mt-1 flex-shrink-0">
                <div class="xl:w-10 xl:h-10 w-8 h-8 rounded-full bg-transparent border mr-6 ml-2 xl:mt-3 mt-2 flex-shrink-0"></div>
                </div>
                <div>
                  <h3 class="text-xl font-semibold mb-2">Scalable and Future-Proof Solutions</h3>
                  <p class="text-md text-gray-300">We understand the importance of scalability and future-proofing your app for long-term success. Whether launching a startup app or expanding an existing product, our solutions are designed to grow your business and adapt to changing market demands.</p>
                </div>
              </div>
            </div>
    </section>
    <!-- scaleability section -->
    <section class=" py-10">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Full-Scale Web Development by Pixelizio</h2>
        <p class="text-md text-center mb-8">Every app is unique, so we offer tailored mobile app development services to meet your specific needs. From concept to launch, our team works closely with you to ensure that your app reflects your vision and delivers exceptional value to your users.</p> 
      </div>
    </section>
    <!-- Call to Action Section -->
    <section class=" pb-10">
      <div class="container max-w-[800px] mx-auto px-0 lg:px-8 text-center">
        <h2 class="xl:text-3xl text-2xl font-bold mb-6">Ready to Bring Your App Idea to Life?</h2>
        <p class="text-md mb-8">Contact us today to learn more about our mobile app development services and how we can help you turn your application idea into a reality. Let’s collaborate to create an app that sets you apart from the competition and delights your users.</p>
        <a href="/contact" class="bg-blue hover:bg-primary text-white py-2 px-4 rounded-full hover:bg-blue-700 transition duration-300">
          Contact Pixelizio Today
        </a>
      </div>
    </section>
    `;
  
  export default mobileAppDevelopment;
  