"use client";
import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import Button from '@/components/Button';
import { ImSpinner6 } from "react-icons/im";
import { FaAngleDoubleRight } from "react-icons/fa"; 

const posts = [
  { id: 1, title: 'Digital Marketing Campaigns with Personalization | Pixelizio – Boost Your ROI', description: 'Discover the power of personalisation in digital marketing campaigns. Learn how tailored strategies can boost ROI by targeting customer needs, preferences, and behaviours, ensuring meaningful connections and higher conversion rates.In...', image: '/assets/blog images/pixelizio new blog.jpg', slug: 'digital-marketing-campaigns-personalization-boost-your-roi' },
  { id: 2, title: 'Local Search Engine Optimization: How to Dominate Search Results', description: 'Businesses hoping to improve their local search result exposure must focus on local search engine optimization (SEO) Expert. You may outperform rivals and draw more local business by leveraging local SEO...', image: '/assets/blog images/optimized local seo.jpg', slug: 'local-search-engine-optimization-how-to-dominate-search-results' },
  { id: 3, title: "Top 10 Digital Marketing Trends Businesses Can't Ignore in 2024", description: 'As we enter the second half of 2024, the terrain of digital marketing has changed quite rapidly. Businesses trying to maintain a competitive edge must stay ahead of these changes.Adopting...', image: '/assets/blog images/top 10 digitalmarketing busiencesses.jpg', slug: 'top-10-digital-marketing-trends-businesses-cant-ignore-2024' },
  { id: 4, title: 'Why Digital Marketing is Important for Small Businesses', description: 'Being well-established online is not a choice in today digital age. In this post, we shall go into great detail on why small businesses need online digital marketing services to succeed.Small...', image: '/assets/blog images/new blog.jpg', slug: 'why-digital-marketing-is-important-for-small-businesses' },
  { id: 5, title: 'How to Create a Digital Marketing Funnel, and Why is it Important?', description: 'Knowing how to build an efficient digital marketing funnel is essential for companies hoping to turn leads into devoted clients. This article explores the concept of the digital marketing funnel...', image: '/assets/blog images/new.jpg', slug: 'how-to-create-a-digital-marketing-funnel-and-why-it-is-important' },
  { id: 6, title: 'Navigating Cybersecurity for Small Businesses – Simple Steps to Protect...', description: 'Small companies need cybersecurityto prevent data breaches and financial losses. This guide offers straightforward, doable actions to improve your business cybersecurity protocols to protect confidential data.These steps can help you...', image: '/assets/blog images/navigating cybersecurity for small businees.jpg', slug: 'navigating-cybersecurity-for-small-businesses-simple-steps-to-protect-your-company' },
  { id: 7, title: 'Top 10 Pros and Cons of Traditional Marketing Vs Digital Marketing', description: ' A successful business means choosing the correct marketing technique that will have a long-lasting impact on your brand. Marketing is your brand\'s voice and informs people about your services, business,...', image: '/assets/blog images/Top-10-Pros-and-Cons-of-Traditional-Marketing-Vs-Digital-Marketing-For-Website.jpg', slug: 'top-10-pros-and-cons-of-traditional-marketing-vs-digital-marketing' },
  { id: 8, title: '10 Digital Marketing Tips For Your Real Estate Business', description: 'With real estate businesses booming, it can be very competitive to stay on top of this industry. That is why real estate businesses are always on the lookout for ways...', image: '/assets/blog images/10-Digital-Marketing-Tips-For-Your-Real-Estate-Business.jpg', slug: '10-digital-marketing-tips-for-your-real-estate-business' },
  { id: 9, title: 'Boost Blog Ranking: A Complete Backlink Building Guide.', description: 'When driving organic traffic to your blog, achieving a high ranking in search engine results pages (SERPs) is crucial. A higher blog ranking increases visibility and builds trust and credibility...', image: '/assets/blog images/boost blog.jpg', slug: 'boost-blog-ranking-a-complete-backlink-building-guide' },
];

export default function Blog() {
  const [visiblePosts, setVisiblePosts] = useState(9);
  const [loading, setLoading] = useState(false);

  const loadMore = () => {
    setLoading(true);
    setTimeout(() => {
      setVisiblePosts((prev) => prev + 3);
      setLoading(false); 
    }, 1200); 
  };

  return (
    <div className="container max-w-[1310px] px-2.5 mx-auto py-12">
      <div className="flex items-end space-x-2 text-primary">
        <svg xmlnsXlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4.15 1.83" className="w-24 h-10 fill-current">
          <path d="M0.1,0.57C0.25,0.5,0.39,0.4,0.54,0.32C0.69,0.25,0.85,0.2,1.01,0.19c0.3-0.02,0.57,0.11,0.69,0.39 c0.12,0.27,0.14,0.57,0.39,0.76c0.22,0.17,0.5,0.21,0.77,0.22c0.16,0,0.33-0.01,0.49-0.03C3.43,1.51,3.52,1.5,3.61,1.48 c0.08-0.01,0.17-0.02,0.24-0.06c0.04-0.02,0.02-0.07-0.02-0.07C3.75,1.34,3.68,1.37,3.61,1.38C3.53,1.4,3.46,1.42,3.38,1.43 C3.23,1.46,3.07,1.47,2.91,1.47c-0.29,0-0.63-0.04-0.84-0.26c-0.23-0.23-0.2-0.59-0.39-0.84C1.52,0.18,1.26,0.1,1.01,0.11 C0.85,0.12,0.69,0.17,0.54,0.24c-0.16,0.08-0.34,0.17-0.47,0.3C0.06,0.55,0.08,0.58,0.1,0.57L0.1,0.57z"></path>
          <polygon points="4.06,1.39 3.81,1.24 3.55,1.09 3.78,1.41 3.61,1.76 3.84,1.57"></polygon>
        </svg>
        <span>Latest News</span>
      </div>
      <h1 className="xl:text-3xl xl:mb-12 my-4 text-2xl font-bold">Read our latest blogs</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:gap-6 md:gap-4 sm:gap-0">
        {posts.slice(0, visiblePosts).map((post) => (
          <div key={post.id} className="flex flex-col items-start px-5 pt-5 pb-5 mx-auto w-full leading-none text-white rounded-md  group bg-header  group shadow-custom max-md:px-5 max-md:mt-6">
            <Link href={`/blog/${post.slug}`}>
              <div className="overflow-hidden w-full">
                <Image
                  src={post.image}
                  alt={post.title}
                  width={500}
                  height={294}
                  className="object-cover w-full aspect-[1.70] transition-transform duration-500 ease-in-out group-hover:scale-110"
                />
              </div>
              <h2 className="xl:mt-8 mt-6 text-lg font-semibold leading-8">{post.title}</h2>
            </Link>
            <Link href={`/blog/${post.slug}`} className="mt-6">
              <button className="w-full  flex justify-center items-center gap-2 py-2 px-4 text-sm  text-center rounded-full border group-hover:bg-white group-hover:text-black text-white border-border max-md:pl-5 transition-colors duration-300 ease-in-out hover:bg-zinc-800">
                Read more <span><FaAngleDoubleRight /></span>
              </button>
            </Link>
          </div>
        ))}
      </div>
      
      {visiblePosts < posts.length && (
        <div className="flex justify-center mt-8">
          <Button
            variant="outline"
            size="medium"
            onClick={loadMore}
            className="flex flex-row items-center justify-between gap-2"
          >
            {loading && (
              <svg
                className="w-4 h-4 mr-2 animate-spin"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <circle cx="12" cy="12" r="10" strokeWidth="4" className="opacity-25" />
                <path
                  fill="currentColor"
                  d="M4 12a8 8 0 108-8 8 8 0 00-8 8z"
                />
              </svg>
            )}
            {loading ? 'Loading...' : 'Load More'} 
            <ImSpinner6 />
          </Button>
        </div>
      )}
    </div>
  );
}