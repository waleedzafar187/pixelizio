"use client"
import { useRouter } from 'next/navigation'; // Change from 'next/router' to 'next/navigation'
import Link from 'next/link';
import softwareDevelopmentContent from '@/app/subServices/softwareDevelopmentContent';
import emailMarketingContent from '@/app/subServices/emailMarketingContent';
import mobileAppDevelopment from '@/app/subServices/mobileAppDevelopment';
import applicationServices from '@/app/subServices/applicationServices';
import UIUXDesign from '@/app/subServices/UiUxDesign';
import ITConsulting from '@/app/subServices/ITConsulting';
import ERP from '@/app/subServices/ERP';
import CRMSolutions from '@/app/subServices/CRMSolutions';
import socialMediaBrandManagement from '@/app/subServices/socialMediaBrandManagement';
import socialMediaManagement from '@/app/subServices/socialMediaManagement';
import socialMediaAds from '@/app/subServices/socialMediaAds';
import metaAds from '@/app/subServices/metaAds';
import bingAds from '@/app/subServices/bingAds';
import googleAds from '@/app/subServices/googleAds';
import realEstateLandingPage from '@/app/subServices/realEstateLandingPage';
import ecommerceWebsite from '@/app/subServices/ecommerceWebsite';
import wordpressWebsite from '@/app/subServices/wordpressWebsite';
import customWebsite from '@/app/subServices/customWebsite';
import seoAudit from '@/app/subServices/seoAudit';
import ecommerceSEO from '@/app/subServices/ecommerceSEO';
import bingBusinessProfile from '@/app/subServices/bingBusinessProfile';
import googleBusinessProfile from '@/app/subServices/googleBusinessProfile';
import onpageSeo from '@/app/subServices/onpageSeo';
import offpageSeo from '@/app/subServices/offpageSeo';
import technicalSeo from '@/app/subServices/technicalSeo';
import LocalSeo from '@/app/subServices/LocalSeo';
import WebDevelopment from '@/app/subServices/webDevelopment';
import EcommerceSolutions from '@/app/subServices/ecommerceSolution';
import RealEstateSolutions from '@/app/subServices/RealEstateSolutions';
import CustomApplications from '@/app/subServices/CustomApplications';
import DesktopApplication from '@/app/subServices/DesktopApplication';
import MobileApplication from '@/app/subServices/MobileApplication';
import WebApplications from '@/app/subServices/WebApplications';
import SoftwareSolutions from '@/app/subServices/SoftwareSolutions';
import SearchEngineAdvertising from '@/app/subServices/SEA';
import SocialMediaMarketing from '@/app/subServices/socialMediaMarketing';
import SEOServices from '@/app/subServices/SEOServices';
import GraphicDesign from '@/app/subServices/GraphicDesign';
import DigitalMarketingSolution from '@/app/subServices/DigitalMarketingSolutions';
import WebDesignDevelopment from '@/app/subServices/WebDesign&Development';
import PaidDigitalAdvertising from '@/app/subServices/PaidDigitalAdvertising';
import SoftwareServices from '@/app/subServices/SoftwareServices';

// Array of services and their contents
const services = [
  { title: 'Email Marketing', slug: 'email-marketing', content: emailMarketingContent },
  { title: 'Software Development', slug: 'software-development', content: softwareDevelopmentContent },
  { title: 'Mobile App Development', slug: 'mobile-app-development', content: mobileAppDevelopment },
  { title: 'Application Services', slug: 'application-services', content: applicationServices },
  { title: 'UI/UX Design', slug: 'ui-ux-design', content: UIUXDesign },
  { title: 'IT Consulting', slug: 'it-consulting', content: ITConsulting },
  { title: 'ERP', slug: 'erp', content: ERP },
  { title: 'CRM Solutions', slug: 'crm-solutions', content: CRMSolutions },
  { title: 'Social Media Brand Management', slug: 'social-media-brand-management', content: socialMediaBrandManagement },
  { title: 'Social Media Management', slug: 'social-media-management', content: socialMediaManagement },
  { title: 'Social Media Ads', slug: 'social-media-ads', content: socialMediaAds },
  { title: 'Meta Ads', slug: 'meta-ads', content: metaAds },
  { title: 'Bing Ads', slug: 'bing-ads', content: bingAds },
  { title: 'Google Ads', slug: 'google-ads', content: googleAds },
  { title: 'Real Estate Landing Page', slug: 'real-estate-landing-page', content: realEstateLandingPage },
  { title: 'Ecommerce Website', slug: 'ecommerce-website', content: ecommerceWebsite },
  { title: 'Wordpress Website', slug: 'wordpress-website', content: wordpressWebsite },
  { title: 'Custom Website', slug: 'custom-website', content: customWebsite },
  { title: 'SEO Audit', slug: 'seo-audit', content: seoAudit },
  { title: 'Ecommerce SEO', slug: 'ecommerce-seo', content: ecommerceSEO },
  { title: 'Bing Business Profile', slug: 'bing-business-profile', content: bingBusinessProfile },
  { title: 'Google Business Profile', slug: 'google-my-business', content: googleBusinessProfile },
  { title: 'On-Page SEO', slug: 'on-page-seo', content: onpageSeo },
  { title: 'Off-Page SEO', slug: 'off-page-seo', content: offpageSeo },
  { title: 'Technical SEO', slug: 'technical-seo', content: technicalSeo },
  { title: 'Local SEO', slug: 'local-seo', content: LocalSeo },
  { title: 'Web Development', slug: 'web-development', content: WebDevelopment },
  { title: 'Ecommerce Solutions', slug: 'ecommerce-solutions', content: EcommerceSolutions },
  { title: 'Real Estate Solutions', slug: 'real-estate-solutions', content: RealEstateSolutions },
  { title: 'Custom Applications', slug: 'custom-applications', content: CustomApplications },
  { title: 'Desktop Application', slug: 'desktop-application', content: DesktopApplication },
  { title: 'Mobile Application', slug: 'mobile-application', content: MobileApplication },
  { title: 'Web Applications', slug: 'web-applications', content: WebApplications },
  { title: 'Software Solutions', slug: 'software-solutions', content: SoftwareSolutions },
  { title: 'Search Engine Advertising', slug: 'search-engine-advertising', content: SearchEngineAdvertising },
  { title: 'Social Media Marketing', slug: 'social-media-marketing', content: SocialMediaMarketing },
  { title: 'SEO Services', slug: 'seo-services', content: SEOServices },
  { title: 'Graphic Design', slug: 'graphic-design', content: GraphicDesign },
  { title: 'Digital Marketing Solutions', slug: 'digital-marketing-solutions', content: DigitalMarketingSolution },
  { title: 'Web Design & Development', slug: 'web-design-development', content: WebDesignDevelopment },
  { title: 'Paid Digital Advertising', slug: 'paid-digital-advertising', content: PaidDigitalAdvertising },
  { title: 'Software Services', slug: 'software-services', content: SoftwareServices },
];

// Service detail component
export default function ServiceDetail({ params }: { params: { slug: string } }) {
  const router = useRouter(); // Use next/navigation router

  // Find the service by slug
  const service = services.find((s) => s.slug === params.slug);

  // If service not found, return error message
  if (!service) {
    return <div className="text-center text-2xl my-10">Service not found</div>;
  }

  return (
    <div className="bg-secondery min-h-screen text-white">
      <div className="container max-w-[1310px] px-2.5 mx-auto py-6">
        {/* Back to previous page or fallback to Services */}
        <button
          onClick={() => router.back()} // Use router.back() to navigate to the previous page
          className="border border-border px-3 hover:bg-white hover:text-black py-1.5 text-sm rounded-full inline-block"
        >
          ← Back to Previous Page
        </button>

        {/* Service content */}
        <div className="mt-2 mb-2" dangerouslySetInnerHTML={{ __html: service.content || '' }} />
      </div>
    </div>
  );
}
