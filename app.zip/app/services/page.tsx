"use client"

import { BsCheck2Circle } from "react-icons/bs";
import Link from "next/link"
import Button from "@/components/Button"

const serviceCategories = [
  {
    title: "SEO Services",
    items: [
      { name: "On-Page SEO", link: "/services/on-page-seo" },
      { name: "Off-Page SEO", link: "/services/off-page-seo" },
      { name: "Technical SEO", link: "/services/technical-seo" },
      { name: "Local SEO", link: "/services/local-seo" },
      { name: "Google My Business", link: "/services/google-my-business" },
      { name: "Bing Business Profile", link: "/services/bing-business-profile" },
      { name: "E-Commerce SEO", link: "/services/ecommerce-seo" },
      { name: "SEO Audit", link: "/services/seo-audit" },
    ],
    detailLink: "/services/seo-services",
  },
  {
    title: "Software Services",
    items: [
      { name: "Mobile App Development", link: "/services/mobile-app-development" },
      { name: "Software Development", link: "/services/software-development" },
      { name: "Application Services", link: "/services/application-services" },
      { name: "Web Development", link: "/services/web-development" },
      { name: "IT Consulting", link: "/services/it-consulting" },
    ],
    detailLink: "/services/software-services",
  },
  {
    title: "Paid Digital Advertising",
    items: [
      { name: "Google Ads", link: "/services/google-ads" },
      { name: "Bing Ads", link: "/services/bing-ads" },
      { name: "Meta Ads", link: "/services/meta-ads" },
      { name: "Social Media Ads", link: "/services/social-media-ads" },
    ],
    detailLink: "/services/paid-digital-advertising",
  },
  {
    title: "Web Design & Development",
    items: [
      { name: "Custom Website", link: "/services/custom-website" },
      { name: "WordPress Website", link: "/services/wordpress-website" },
      { name: "E-commerce Website", link: "/services/ecommerce-website" },
      { name: "Real Estate Landing Page", link: "/services/real-estate-landing-page" },
    ],
    detailLink: "/services/web-design-development",
  },
  {
    title: "Digital Marketing Solutions",
    items: [
      { name: "Search Engine Advertising", link: "/services/search-engine-advertising" },
      { name: "Social Media Marketing", link: "/services/social-media-marketing" },
      { name: "UI/UX Design", link: "/services/ui-ux-design" },
      { name: "SEO Services", link: "/services/seo-services" },
      { name: "Graphic Design", link: "/services/graphic-design" },
      { name: "Email marketing", link: "/services/email-marketing" },
    ],
    detailLink: "/services/digital-marketing-solutions",
  },
  {
    title: "Software Solutions",
    items: [
      { name: "E-Commerce Solutions", link: "/services/ecommerce-solutions" },
      { name: "Real Estate Solutions", link: "/services/real-estate-solutions" },
      { name: "Custom Applications", link: "/services/custom-applications" },
      { name: "Desktop Applications", link: "/services/desktop-application" },
      { name: "Mobile Applications", link: "/services/mobile-application" },
      { name: "Web Applications", link: "/services/web-applications" },
      { name: "CRM", link: "/services/crm-solutions/" },
      { name: "ERP", link: "/services/erp/" },
    ],
    detailLink: "/services/software-solutions",
  },
]

export default function ServicesPage() {
  return (
    <div className="min-h-screen w-full  text-white">
      <main className="container max-w-[1310px] mx-auto xl:px-2 px-4 py-6 xl:py-16">
        <div className="mb-12">
        <div className="flex items-end space-x-2 text-primary">
        <svg xmlnsXlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 4.15 1.83" className="w-24 h-10 fill-current">
          <path d="M0.1,0.57C0.25,0.5,0.39,0.4,0.54,0.32C0.69,0.25,0.85,0.2,1.01,0.19c0.3-0.02,0.57,0.11,0.69,0.39 c0.12,0.27,0.14,0.57,0.39,0.76c0.22,0.17,0.5,0.21,0.77,0.22c0.16,0,0.33-0.01,0.49-0.03C3.43,1.51,3.52,1.5,3.61,1.48 c0.08-0.01,0.17-0.02,0.24-0.06c0.04-0.02,0.02-0.07-0.02-0.07C3.75,1.34,3.68,1.37,3.61,1.38C3.53,1.4,3.46,1.42,3.38,1.43 C3.23,1.46,3.07,1.47,2.91,1.47c-0.29,0-0.63-0.04-0.84-0.26c-0.23-0.23-0.2-0.59-0.39-0.84C1.52,0.18,1.26,0.1,1.01,0.11 C0.85,0.12,0.69,0.17,0.54,0.24c-0.16,0.08-0.34,0.17-0.47,0.3C0.06,0.55,0.08,0.58,0.1,0.57L0.1,0.57z"></path>
          <polygon points="4.06,1.39 3.81,1.24 3.55,1.09 3.78,1.41 3.61,1.76 3.84,1.57"></polygon>
        </svg>
        <span>Services</span>
      </div>
      <h1 className="xl:text-3xl xl:mb-12 my-4 text-2xl font-bold">Discover Exceptional Services at Pixelizio</h1>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {serviceCategories.map((category) => (
            <div
              key={category.title}
              className="group rounded-xl bg-header p-8 transition-all duration-500 ease-in-out
                         shadow-[2px_2px_5px_0_rgba(0,0,0,0.5)] overflow-hidden
                         border border-transparent
                         hover:scale-105 hover:shadow-[0_8px_15px_rgba(0,0,0,0.2)]
                         hover:border-[#4B3F3F] md:mb-0"
            >
              <h2 className="mb-10 text-xl font-semibold">{category.title}</h2>
              <ul className={`grid gap-x-7 gap-y-4 ${category.items.length > 6 ? "grid-cols-2" : "grid-cols-1"}`}>
                {category.items.map((item) => (
                  <li key={item.name} className="flex items-center gap-4 text-sm text-gray-300 group">
                    <BsCheck2Circle  className="h-4 w-4 text-white group-hover:text-primary" />
                    <Link href={item.link} className="hover:text-white transition-colors">
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
              <Link href={category.detailLink}>
                <Button variant="outline" size="xSmall"
                  className="text-white py-1 border mt-10 border-white bg-transparent text-sm group-hover:bg-white group-hover:text-black"
                >
                  Service Details
                </Button>
              </Link>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}